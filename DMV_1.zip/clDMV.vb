Option Strict Off
Option Explicit On
Friend Class Base
	
	Public m_BasePermission As Short
	
	
	Property BasePermission() As Short
		Get
			On Error GoTo Get_BasePermission_ErrorHandler
			
			BasePermission = m_BasePermission
			
			Exit Property
Get_BasePermission_ErrorHandler: 
			sMsg = "Error Information..." & vbCrLf & vbCrLf
			sMsg = sMsg & "Function: Get_BasePermission " & vbCrLf
			sMsg = sMsg & "Description: " & Err.Description & vbCrLf
			sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
			MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
			Resume Next
			
		End Get
		Set(ByVal Value As Short)
			On Error GoTo Let_BasePermission_ErrorHandler
			
			m_BasePermission = Value
			
			Exit Property
Let_BasePermission_ErrorHandler: 
			sMsg = "Error Information..." & vbCrLf & vbCrLf
			sMsg = sMsg & "Function: Let_BasePermission " & vbCrLf
			sMsg = sMsg & "Description: " & Err.Description & vbCrLf
			sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
			MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
			Resume Next
			
		End Set
	End Property
End Class