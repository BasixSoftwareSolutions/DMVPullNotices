Option Strict Off
Option Explicit On
'Imports VB = Microsoft.VisualBasic
Module Module1
	Public oConn As ADODB.Connection
	Public sConn As String
	Public sSQL As String
	Public cmd As ADODB.Command
	Public rs As ADODB.Recordset
	Public sMsg As String
	Public chk As Short
	Public tmp_user_id As String
	Public tmp_password As String
	Public tempUserId As String
	Public tmpSystem As String
	Public searchJobClass As String
	Public searchSeq As String
	Public searchExam As String
	Public searchSession As String
	Public searchPool As String
	Public searchSpecialty As String
	Public searchReqNo As String
	Public gblNotes As Object
	Public thereAreNotes As Boolean
	Public deptOrder As Short
	Public jobClassOrder As Short
	Public LoginSucceeded As Boolean
	Public systemVersion As String
	Public systemSection As String
	Public SearchCompany As String
	Public SearchEmployeeId As String
	Public SearchJobSequence As Short
	Public EditOk As Boolean
    Public EditSwitch As String
    Public FutureOk As Boolean
	Public searchTopicId As String
	Public searchTabId As String
	Public tabEditLevel() As Object
	Public typeOfSearch As String
	Public BatchJob As Boolean
	Public AttendanceScreenLoaded As Boolean
	Public EmployeeRecordsLoaded As Boolean
	Public TimeSheetAppId, ReturnValue As Object
	Public EmployeesFirstName As String
	Public UsersEmployeeId As String
	Public UsersCompany As String
	Public UsersLast4SSNDOBYear As String
	Public Connector As String
	Public OraclePassword As String
	Public SearchPositionNumber As String
    Public ArrayOFHistory(,) As Object
    Public arrayOfResults(,) As Object
	Public typeOfEdit As String
	Public MassChangeUserId As String
	Public MassChanging As Boolean
	Public fieldName As String
	Public fieldFreindlyName As String
	Public fieldTableName As String
	Public fieldLength As String
	Public fieldId As Short
	Public fieldType As String
	Public topicLoaded As String
	Public JobTableFlsaCode As String
	Public frmEasySearch As System.Windows.Forms.Form
	Public ValidUpdate As Boolean
	Public LastUpdate As String
	Public DMVPassword As String
    'Global Const FILE_PATH = "\\OCTANT03.OCTAINT.NET\apps$\DMV\Production"
    Public Const FILE_PATH As String = "\\OCTANT03\apps$\DMV\Production"
    Public Const DOC_PATH As String = "\\OCTANT03\apps$\DMV"


    Public Sub Main()
        On Error GoTo Main_ErrorHandler

        Dim sConn As String = ""
        systemVersion = "PRODUCTION"
        systemSection = "DMV System"
        tmp_user_id = "InHouseApp_User"
        tmp_password = "Oct@!2345"

        'Connect to Oracle server begin
        oConn = New ADODB.Connection

        oConn.CommandTimeout = 0
        'oConn.ConnectionString = " PROVIDER=SQLOLEDB" & ";SERVER=ORMSQL17" & ";UID=" & tmp_user_id & ";PWD=" & tmp_password & ";DATABASE=DMV"
        oConn.ConnectionString = "Driver={SQL Server};Server=ORMSQL17;Database=DMV;Uid=" & tmp_user_id & ";Pwd=" & tmp_password & ";"
        With oConn
            .ConnectionString = sConn
            .CursorLocation = ADODB.CursorLocationEnum.adUseClient
            .Open()
        End With

        If oConn.State <> ADODB.ObjectStateEnum.adStateOpen Then
            MsgBox("Connection could not be found. Contact your systems administrator.", MsgBoxStyle.Critical, "Connection error")
        End If

        'Run automatic import function if command line = "AutoImport"
        Dim args = Environment.GetCommandLineArgs()

        If IsArray(args) Then
            Dim i As Integer
            For i = LBound(args) To UBound(args)
                If args(i) = "AutoImport" Then
                    Call ImportDMVFile()
                    End
                End If
            Next
        End If

        Application.Run(MDIForm1.DefInstance)

        Exit Sub

Main_ErrorHandler:

        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: Main " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Exit Sub

    End Sub

    Public Sub UpdateControl(ByRef WindowsControl As String, ByRef NetworkControl As String)
		On Error Resume Next
		
		Dim WindowsControlDate As Date
		Dim NetworkControlDate As Date
		Dim RegisterName As String
		
		
		WindowsControlDate = FileDateTime(WindowsControl)
		NetworkControlDate = FileDateTime(NetworkControl)
		
		If WindowsControlDate = CDate("12:00:00 AM") And NetworkControlDate = CDate("12:00:00 AM") Then
			Beep()
			Call MsgBox("Missing Control " & WindowsControl, MsgBoxStyle.Information, "Alert")
		End If
		
		If WindowsControlDate < NetworkControlDate Then
			Call FileCopy(NetworkControl, WindowsControl)
			RegisterName = "REGSVR32 " & WindowsControl & " /s"
			Shell(RegisterName)
		End If
		
	End Sub
	
	ReadOnly Property GetOralceDate() As Object
		Get
			On Error GoTo ExitDate
			
			sSQL = "SELECT SYSDATE FROM dual"
			Dim rsDate As New ADODB.Recordset
			rsDate.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenForwardOnly)
			
			If rsDate.RecordCount <> 0 Then rs.MoveLast()
			If rsDate.RecordCount > 0 Then
                GetOralceDate = rsDate.Fields(0).Value.ToString("MM-dd-yyyy hh:mm:ss ampm")
            Else
                GetOralceDate = Today.ToString("MM-dd-yyyy hh:mm:ss ampm")
            End If
			Exit Property

            rsDate = Nothing
ExitDate:
            GetOralceDate = Today.ToString("MM-dd-yyyy hh:mm:ss ampm")

        End Get
	End Property
	
	ReadOnly Property RetrieveFieldFrom(ByVal inSelect As Object, ByVal inFrom As Object, ByVal inWhere As Object) As String
		Get
			On Error GoTo RetrieveError
			
			Dim rst As ADODB.Recordset
			
            If IsDBNull(inSelect) Or inSelect = "" Then
                RetrieveFieldFrom = ""
                Exit Property
            End If
            If IsDBNull(inFrom) Or inFrom = "" Then
                RetrieveFieldFrom = ""
                Exit Property
            End If
            If IsDBNull(inWhere) Or inWhere = "" Then
                RetrieveFieldFrom = ""
                Exit Property
            End If
			
            sSQL = "SELECT " & inSelect & " FROM " & inFrom & " WHERE " & inWhere
			
			rst = New ADODB.Recordset
			rst.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)
			
			If rst.RecordCount <> 0 Then rst.MoveLast()
			If rst.RecordCount > 0 Then
                If IsDBNull(rst.Fields(0).Value) Then
                    RetrieveFieldFrom = ""
                Else
                    RetrieveFieldFrom = rst.Fields(0).Value
                End If
			Else
				RetrieveFieldFrom = ""
			End If
            rst = Nothing
			Exit Property
			
RetrieveError: 
			Exit Property
			RetrieveFieldFrom = ""
			
		End Get
	End Property
	
	ReadOnly Property RemoveSpaces(ByVal inStuff As Object) As String
		Get
			On Error GoTo Get_RemoveSpaces_ErrorHandler
			
            Select Case True
                Case IsDBNull(inStuff)
                    RemoveSpaces = ""
                Case Trim(inStuff) = ""
                    RemoveSpaces = ""
                Case Else
                    RemoveSpaces = Trim(inStuff)
            End Select
			
			Exit Property
Get_RemoveSpaces_ErrorHandler: 
			sMsg = "Error Information..." & vbCrLf & vbCrLf
			sMsg = sMsg & "Function: Get_RemoveSpaces " & vbCrLf
			sMsg = sMsg & "Description: " & Err.Description & vbCrLf
            sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
            MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
            Resume Next

        End Get
    End Property

    ReadOnly Property VerifyNumber(ByVal inStuff As Object) As Double
        Get

            On Error GoTo Get_VerifyNumber_ErrorHandler

            On Error GoTo ExitMe
            Dim TNumber As Double
            Select Case True
                Case IsDBNull(inStuff)
                    VerifyNumber = 0
                Case CDbl(Trim(inStuff)) = 0
                    VerifyNumber = 0
                Case Else
                    VerifyNumber = inStuff
                    Exit Property
            End Select
ExitMe:
            VerifyNumber = 0

            Exit Property
Get_VerifyNumber_ErrorHandler:
            sMsg = "Error Information..." & vbCrLf & vbCrLf
            sMsg = sMsg & "Function: Get_VerifyNumber " & vbCrLf
            sMsg = sMsg & "Description: " & Err.Description & vbCrLf
            sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
            MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
            Resume Next

        End Get
    End Property

    Public Sub StandardResultSet()
        On Error GoTo StandardResultSet_ErrorHandler

        If oConn.State <> ADODB.ObjectStateEnum.adStateOpen Then
            MsgBox("Connection could not be found. Contact your systems administrator.", MsgBoxStyle.Critical, "Connection error")
        End If
        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)
        If rs.RecordCount <> 0 Then rs.MoveLast()

        Exit Sub
StandardResultSet_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: StandardResultSet " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
End Module