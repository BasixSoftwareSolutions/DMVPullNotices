﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.Drawing
'Imports System.Drawing.Printing

Public Class frmMain
    Private OptView() As RadioButton
    Private OptMajorMinor() As RadioButton
    Private OptFutureSearch() As RadioButton
    Private cmdExcel() As Button
    Private txtInput() As MaskedTextBox
    Private ListCompany() As ComboBox
    Private lblInput() As Label
    Private lblRecordCount() As Label
    Private txtHR() As TextBox
    Private txtDMV() As TextBox
    Dim ArrayOfEasyResults() As Array
    Private aryMESSAGES(,) As Object
    Dim WhereClause As String
    Dim OrderBy As String
    Dim oBase As Base
    Dim holdFName As String
    Dim holdLName As String
    Dim holdBadge As String
    Dim holdPosNo As String
    Dim MeLoaded As Boolean
    Dim tmp_user_id As String = "dmv"
    Dim tmp_password As String = "orange1"
    Dim sConn As String = "Data Source=ORMSQL17;Initial Catalog=DMV;UID=" & tmp_user_id & ";PWD=" & tmp_password & ""
    'Private Printer As Object


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        LoadcmbSearch()
        Me.Width = (MDIForm1.DefInstance.ClientRectangle.Width) - 250
        SizeForm()
        txtInput1.Select()

    End Sub

    Public Sub New()
        InitializeComponent()
        OptView = New RadioButton() {optView1, optView2, optView3}
        OptMajorMinor = New RadioButton() {optMajorMinor1, optMajorMinor2, optMajorMinor3}
        OptFutureSearch = New RadioButton() {optFutureSearch1, optFutureSearch2, optFutureSearch3, optFutureSearch4}
        txtInput = New MaskedTextBox() {txtInput1, txtInput2}
        ListCompany = New ComboBox() {ListCompany1, ListCompany2, ListCompany3}
        lblInput = New Label() {lblInput1, lblInput2}
        lblRecordCount = New Label() {lblRecordCount1, lblRecordCount2, lblRecordCount3}
        cmdExcel = New Button() {cmdExcel1, cmdExcel2}
        txtHR = New TextBox() {txtHR1, txtHR2, txtHR3, txtHR4, txtHR5, txtHR6}
        txtDMV = New TextBox() {txtDMV1, txtDMV2, txtDMV3, txtDMV4, txtDMV5, txtDMV6, txtDMV7, txtDMV8, txtDMV9, txtDMV10, txtDMV11, txtDMV12, txtDMV13, txtDMV14}
    End Sub

    Private Sub FormatDataGridColumns(sMode As String)

        grdSearch.DataSource = Nothing
        grdSearch.Rows.Clear()
        grdSearch.Columns.Clear()
        grdSearch.AutoGenerateColumns = False

        Select Case sMode
            Case "Search", "UnSigned"
                'Set Columns Count
                grdSearch.ColumnCount = 14

                'Add Columns
                grdSearch.Columns(0).Name = "BADGE_NO"
                grdSearch.Columns(0).HeaderText = "BADGE NO"
                grdSearch.Columns(0).DataPropertyName = "BADGE_NO"
                grdSearch.Columns(0).Width = 50

                grdSearch.Columns(1).Name = "HIRED_DATE"
                grdSearch.Columns(1).HeaderText = "HIRED DATE"
                grdSearch.Columns(1).DataPropertyName = "HIRED_DATE"
                grdSearch.Columns(1).Width = 100

                grdSearch.Columns(2).Name = "LAST_NAME"
                grdSearch.Columns(2).HeaderText = "LAST NAME"
                grdSearch.Columns(2).DataPropertyName = "LAST_NAME"
                grdSearch.Columns(2).Width = 100

                grdSearch.Columns(3).Name = "FIRST_NAME"
                grdSearch.Columns(3).HeaderText = "FIRST NAME"
                grdSearch.Columns(3).DataPropertyName = "FIRST_NAME"
                grdSearch.Columns(3).Width = 100

                grdSearch.Columns(4).Name = "DATE_OF_BIRTH"
                grdSearch.Columns(4).HeaderText = "DATE OF BIRTH"
                grdSearch.Columns(4).DataPropertyName = "DATE_OF_BIRTH"
                grdSearch.Columns(4).Width = 100

                grdSearch.Columns(5).Name = "SEX"
                grdSearch.Columns(5).HeaderText = "SEX"
                grdSearch.Columns(5).DataPropertyName = "SEX"
                grdSearch.Columns(5).Width = 30

                grdSearch.Columns(6).Name = "CDL_EXPIRATION"
                grdSearch.Columns(6).HeaderText = "CDL EXPIRATION"
                grdSearch.Columns(6).DataPropertyName = "CDL_EXPIRATION"
                grdSearch.Columns(6).Width = 100

                grdSearch.Columns(7).Name = "DRIVERS_LICENSE"
                grdSearch.Columns(7).HeaderText = "DRIVERS LICENSE"
                grdSearch.Columns(7).DataPropertyName = "DRIVERS_LICENSE"
                grdSearch.Columns(7).Width = 100

                grdSearch.Columns(8).Name = "LICENSE_CLASS"
                grdSearch.Columns(8).HeaderText = "LICENSE CLASS"
                grdSearch.Columns(8).DataPropertyName = "LICENSE_CLASS"
                grdSearch.Columns(8).Width = 100

                grdSearch.Columns(9).Name = "OP_CERT_DATE"
                grdSearch.Columns(9).HeaderText = "OP CERT DATE"
                grdSearch.Columns(9).DataPropertyName = "OP_CERT_DATE"
                grdSearch.Columns(9).Width = 100

                grdSearch.Columns(10).Name = "UNION_CODE"
                grdSearch.Columns(10).HeaderText = "UNION CODE"
                grdSearch.Columns(10).DataPropertyName = "UNION_CODE"
                grdSearch.Columns(10).Width = 50

                grdSearch.Columns(11).Name = "LOCATION"
                grdSearch.Columns(11).HeaderText = "LOCATION"
                grdSearch.Columns(11).DataPropertyName = "LOCATION"
                grdSearch.Columns(11).Width = 75

                grdSearch.Columns(12).Name = "LOCATION_CODE"
                grdSearch.Columns(12).HeaderText = "LOCATION CODE"
                grdSearch.Columns(12).DataPropertyName = "LOCATION_CODE"
                grdSearch.Columns(12).Width = 50

                grdSearch.Columns(13).Name = "EMP_STATUS"
                grdSearch.Columns(13).HeaderText = "EMP STATUS"
                grdSearch.Columns(13).DataPropertyName = "EMP_STATUS"
                grdSearch.Columns(13).Width = 50

            Case "Stuff"
                'Set Columns Count
                grdSearch.ColumnCount = 14

                'Add Columns
                grdSearch.Columns(0).Name = "BADGE_NO"
                grdSearch.Columns(0).HeaderText = "BADGE NO"
                grdSearch.Columns(0).DataPropertyName = "BADGE_NO"
                grdSearch.Columns(0).Width = 50

                grdSearch.Columns(1).Name = "HIRED_DATE"
                grdSearch.Columns(1).HeaderText = "HIRED DATE"
                grdSearch.Columns(1).DataPropertyName = "HIRED_DATE"
                grdSearch.Columns(1).Width = 100

                grdSearch.Columns(2).Name = "LAST_NAME"
                grdSearch.Columns(2).HeaderText = "LAST NAME"
                grdSearch.Columns(2).DataPropertyName = "LAST_NAME"
                grdSearch.Columns(2).Width = 100

                grdSearch.Columns(3).Name = "FIRST_NAME"
                grdSearch.Columns(3).HeaderText = "FIRST NAME"
                grdSearch.Columns(3).DataPropertyName = "FIRST_NAME"
                grdSearch.Columns(3).Width = 100

                grdSearch.Columns(4).Name = "DRIVERS_LICENSE"
                grdSearch.Columns(4).HeaderText = "DRIVERS LICENSE"
                grdSearch.Columns(4).DataPropertyName = "DRIVERS_LICENSE"
                grdSearch.Columns(4).Width = 100

                grdSearch.Columns(5).Name = "FLAG_NAME"
                grdSearch.Columns(5).HeaderText = "FLAG NAME"
                grdSearch.Columns(5).DataPropertyName = "FLAG_NAME"
                grdSearch.Columns(5).Width = 50

                grdSearch.Columns(6).Name = "MESSAGE"
                grdSearch.Columns(6).HeaderText = "MESSAGE"
                grdSearch.Columns(6).DataPropertyName = "MESSAGE"
                grdSearch.Columns(6).Width = 100

                grdSearch.Columns(7).Name = "DEPARTMENT"
                grdSearch.Columns(7).HeaderText = "DEPARTMENT"
                grdSearch.Columns(7).DataPropertyName = "DEPARTMENT"
                grdSearch.Columns(7).Width = 100

                grdSearch.Columns(8).Name = "COMMENTS"
                grdSearch.Columns(8).HeaderText = "COMMENTS"
                grdSearch.Columns(8).DataPropertyName = "COMMENTS"
                grdSearch.Columns(8).Width = 100

                grdSearch.Columns(9).Name = "RECORD_DATE"
                grdSearch.Columns(9).HeaderText = "RECORD DATE"
                grdSearch.Columns(9).DataPropertyName = "RECORD_DATE"
                grdSearch.Columns(9).Width = 30

            Case "Expired"
                'Set Columns Count
                grdSearch.ColumnCount = 13

                'Add Columns
                grdSearch.Columns(0).Name = "BADGE_NO"
                grdSearch.Columns(0).HeaderText = "BADGE NO"
                grdSearch.Columns(0).DataPropertyName = "BADGE_NO"
                grdSearch.Columns(0).Width = 50

                grdSearch.Columns(1).Name = "LAST_NAME"
                grdSearch.Columns(1).HeaderText = "LAST NAME"
                grdSearch.Columns(1).DataPropertyName = "LAST_NAME"
                grdSearch.Columns(1).Width = 100

                grdSearch.Columns(2).Name = "FIRST_NAME"
                grdSearch.Columns(2).HeaderText = "FIRST NAME"
                grdSearch.Columns(2).DataPropertyName = "FIRST_NAME"
                grdSearch.Columns(2).Width = 100

                grdSearch.Columns(3).Name = "DRIVERS_LICENSE"
                grdSearch.Columns(3).HeaderText = "DRIVERS LICENSE"
                grdSearch.Columns(3).DataPropertyName = "DRIVERS_LICENSE"
                grdSearch.Columns(3).Width = 100

                grdSearch.Columns(4).Name = "MESSAGE"
                grdSearch.Columns(4).HeaderText = "MESSAGE"
                grdSearch.Columns(4).DataPropertyName = "MESSAGE"
                grdSearch.Columns(4).Width = 200

                grdSearch.Columns(5).Name = "MESSAGE_DATE"
                grdSearch.Columns(5).HeaderText = "MESSAGE DATE"
                grdSearch.Columns(5).DataPropertyName = "MESSAGE_DATE"
                grdSearch.Columns(5).Width = 100

                grdSearch.Columns(6).Name = "JOB_TITLE"
                grdSearch.Columns(6).HeaderText = "JOB TITLE"
                grdSearch.Columns(6).DataPropertyName = "JOB_TITLE"
                grdSearch.Columns(6).Width = 75

                grdSearch.Columns(7).Name = "LOCATION"
                grdSearch.Columns(7).HeaderText = "LOCATION"
                grdSearch.Columns(7).DataPropertyName = "LOCATION"
                grdSearch.Columns(7).Width = 100

                grdSearch.Columns(8).Name = "RECORD_DATE"
                grdSearch.Columns(8).HeaderText = "RECORD DATE"
                grdSearch.Columns(8).DataPropertyName = "RECORD_DATE"
                grdSearch.Columns(8).Width = 100

            Case "Suspention"
                'Set Columns Count
                grdSearch.ColumnCount = 13

                'Add Columns
                grdSearch.Columns(0).Name = "BADGE_NO"
                grdSearch.Columns(0).HeaderText = "BADGE NO"
                grdSearch.Columns(0).DataPropertyName = "BADGE_NO"
                grdSearch.Columns(0).Width = 50

                grdSearch.Columns(1).Name = "EMP_NAME"
                grdSearch.Columns(1).HeaderText = "EMPLOYEE NAME"
                grdSearch.Columns(1).DataPropertyName = "EMP_NAME"
                grdSearch.Columns(1).Width = 150

                grdSearch.Columns(2).Name = "DRIVERS_LICENSE"
                grdSearch.Columns(2).HeaderText = "DRIVERS LICENSE"
                grdSearch.Columns(2).DataPropertyName = "DRIVERS_LICENSE"
                grdSearch.Columns(2).Width = 100

                grdSearch.Columns(3).Name = "SUSPENTION_ACTION"
                grdSearch.Columns(3).HeaderText = "SUSPENTION ACTION"
                grdSearch.Columns(3).DataPropertyName = "SUSPENTION_ACTION"
                grdSearch.Columns(3).Width = 125

                grdSearch.Columns(4).Name = "LOCATION"
                grdSearch.Columns(4).HeaderText = "LOCATION"
                grdSearch.Columns(4).DataPropertyName = "LOCATION"
                grdSearch.Columns(4).Width = 100

                grdSearch.Columns(5).Name = "SUSPENTION_DATE"
                grdSearch.Columns(5).HeaderText = "SUSPENTION DATE"
                grdSearch.Columns(5).DataPropertyName = "SUSPENTION_DATE"
                grdSearch.Columns(5).Width = 100

                grdSearch.Columns(6).Name = "SUSPENTION_EFF_DATE"
                grdSearch.Columns(6).HeaderText = "SUSPENTION EFF DATE"
                grdSearch.Columns(6).DataPropertyName = "SUSPENTION_EFF_DATE"
                grdSearch.Columns(6).Width = 100

                grdSearch.Columns(7).Name = "SUSPENTION_AUTHOR_ACTION"
                grdSearch.Columns(7).HeaderText = "SUSPENTION AUTHOR ACTION"
                grdSearch.Columns(7).DataPropertyName = "SUSPENTION_AUTHOR_ACTION"
                grdSearch.Columns(7).Width = 150

                grdSearch.Columns(8).Name = "SUSPENTION_THRU_DATE"
                grdSearch.Columns(8).HeaderText = "SUSPENTION THRU DATE"
                grdSearch.Columns(8).DataPropertyName = "SUSPENTION_THRU_DATE"
                grdSearch.Columns(8).Width = 100

                grdSearch.Columns(9).Name = "SUSPENTION_REASON"
                grdSearch.Columns(9).HeaderText = "SUSPENTION REASON"
                grdSearch.Columns(9).DataPropertyName = "SUSPENTION_REASON"
                grdSearch.Columns(9).Width = 100

                grdSearch.Columns(10).Name = "SUSPENTION_SERVICE_TYPE"
                grdSearch.Columns(10).HeaderText = "SUSPENTION SERVICE TYPE"
                grdSearch.Columns(10).DataPropertyName = "SUSPENTION_SERVICE_TYPE"
                grdSearch.Columns(10).Width = 100

                grdSearch.Columns(11).Name = "SUSPENTION_SERVICE_DATE"
                grdSearch.Columns(11).HeaderText = "SUSPENTION SERVICE DATE"
                grdSearch.Columns(11).DataPropertyName = "SUSPENTION_SERVICE_DATE"
                grdSearch.Columns(11).Width = 75

                grdSearch.Columns(12).Name = "RECORD_DATE"
                grdSearch.Columns(12).HeaderText = "RECORD DATE"
                grdSearch.Columns(12).DataPropertyName = "RECORD_DATE"
                grdSearch.Columns(12).Width = 100

            Case "Violation"
                'Set Columns Count
                grdSearch.ColumnCount = 18

                'Add Columns
                grdSearch.Columns(0).Name = "BADGE_NO"
                grdSearch.Columns(0).HeaderText = "BADGE NO"
                grdSearch.Columns(0).DataPropertyName = "BADGE_NO"
                grdSearch.Columns(0).Width = 50

                grdSearch.Columns(1).Name = "EMP_NAME"
                grdSearch.Columns(1).HeaderText = "EMPLOYEE NAME"
                grdSearch.Columns(1).DataPropertyName = "EMP_NAME"
                grdSearch.Columns(1).Width = 150

                grdSearch.Columns(2).Name = "DRIVERS_LICENSE"
                grdSearch.Columns(2).HeaderText = "DRIVERS LICENSE"
                grdSearch.Columns(2).DataPropertyName = "DRIVERS_LICENSE"
                grdSearch.Columns(2).Width = 100

                grdSearch.Columns(3).Name = "LOCATION"
                grdSearch.Columns(3).HeaderText = "LOCATION"
                grdSearch.Columns(3).DataPropertyName = "LOCATION"
                grdSearch.Columns(3).Width = 50

                grdSearch.Columns(4).Name = "ITEM"
                grdSearch.Columns(4).HeaderText = "ITEM"
                grdSearch.Columns(4).DataPropertyName = "ITEM"
                grdSearch.Columns(4).Width = 50

                grdSearch.Columns(5).Name = "VIOLATION_DATE"
                grdSearch.Columns(5).HeaderText = "VIOLATION DATE"
                grdSearch.Columns(5).DataPropertyName = "VIOLATION_DATE"
                grdSearch.Columns(5).Width = 100

                grdSearch.Columns(6).Name = "CONVICTION_DATE"
                grdSearch.Columns(6).HeaderText = "CONVICTION DATE"
                grdSearch.Columns(6).DataPropertyName = "CONVICTION_DATE"
                grdSearch.Columns(6).Width = 100

                grdSearch.Columns(7).Name = "SEC_VIO_OR_ACC_LOC"
                grdSearch.Columns(7).HeaderText = "SEC VIO/ACC LOC"
                grdSearch.Columns(7).DataPropertyName = "SEC_VIO_OR_ACC_LOC"
                grdSearch.Columns(7).Width = 150

                grdSearch.Columns(8).Name = "STATUTE"
                grdSearch.Columns(8).HeaderText = "STATUTE"
                grdSearch.Columns(8).DataPropertyName = "STATUTE"
                grdSearch.Columns(8).Width = 60

                grdSearch.Columns(9).Name = "PNT_CNT"
                grdSearch.Columns(9).HeaderText = "PNT CNT"
                grdSearch.Columns(9).DataPropertyName = "PNT_CNT"
                grdSearch.Columns(9).Width = 60

                grdSearch.Columns(10).Name = "CURR_PNT_CNT"
                grdSearch.Columns(10).HeaderText = "CURR PNT CNT"
                grdSearch.Columns(10).DataPropertyName = "CURR_PNT_CNT"
                grdSearch.Columns(10).Width = 50

                grdSearch.Columns(11).Name = "VEH_LIC_NO"
                grdSearch.Columns(11).HeaderText = "VEH LIC NO"
                grdSearch.Columns(11).DataPropertyName = "VEH_LIC_NO"
                grdSearch.Columns(11).Width = 75

                grdSearch.Columns(12).Name = "ACTION_TAKEN"
                grdSearch.Columns(12).HeaderText = "ACTION TAKEN"
                grdSearch.Columns(12).DataPropertyName = "ACTION_TAKEN"
                grdSearch.Columns(12).Width = 150

                grdSearch.Columns(13).Name = "RESOLVED_BY"
                grdSearch.Columns(13).HeaderText = "RESOLVED BY"
                grdSearch.Columns(13).DataPropertyName = "RESOLVED_BY"
                grdSearch.Columns(13).Width = 100

                grdSearch.Columns(14).Name = "DATE_RESOLVED"
                grdSearch.Columns(14).HeaderText = "DATE RESOLVED"
                grdSearch.Columns(14).DataPropertyName = "DATE_RESOLVED"
                grdSearch.Columns(14).Width = 100

                grdSearch.Columns(15).Name = "LAST_UPDATE_BY"
                grdSearch.Columns(15).HeaderText = "LAST UPDATE BY"
                grdSearch.Columns(15).DataPropertyName = "LAST_UPDATE_BY"
                grdSearch.Columns(15).Width = 100

                grdSearch.Columns(16).Name = "LAST_UPDATE"
                grdSearch.Columns(16).HeaderText = "LAST UPDATE"
                grdSearch.Columns(16).DataPropertyName = "LAST_UPDATE"
                grdSearch.Columns(16).Width = 100

                grdSearch.Columns(17).Name = "RECORD_DATE"
                grdSearch.Columns(17).HeaderText = "RECORD DATE"
                grdSearch.Columns(17).DataPropertyName = "RECORD_DATE"
                grdSearch.Columns(17).Width = 100

        End Select

    End Sub

    Private Sub cmdGo_Click(sender As Object, e As EventArgs) Handles cmdGo.Click

        'Clear all data
        Call ClearAll()

        'Set variables
        HoldInputs()
        SearchEmployeeId = txtInput(0).Text
        Me.lblRecordCount(0).Text = ""
        Me.Text = "Searching....Please wait."
        Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
        WhereClause = ""
        Me.lblRecordCount(0).Text = ""

        'Check for base permission
        If (oBase Is Nothing) Then ' Admin, can view any section
            If Trim(ListCompany(0).Text) <> "" Then
                If Trim(ListCompany(0).Text) = "Maint" Then
                    WhereClause = WhereClause & "(union_code='MN' OR union_code='TCU') AND "
                ElseIf Trim(ListCompany(0).Text) = "Annex" Then
                    WhereClause = WhereClause & "location_desc='Garden Grove Location 2' AND "
                Else
                    WhereClause = WhereClause & "location_code='" & GetBaseNumber(ListCompany(0).Text) & "' AND "
                End If
            End If
        Else    'Non-Admin, limited to permission granted
            If oBase.BasePermission = 44 Then
                WhereClause = WhereClause & "(union_code='MN' OR A.union_code='TCU') AND "
            ElseIf oBase.BasePermission = 88 Then
                WhereClause = WhereClause & "location_desc='Garden Grove Location 2' AND "
            Else
                WhereClause = WhereClause & "location_code='" & oBase.BasePermission & "' AND "
            End If
        End If

        'Search Parameter
        Select Case True
            Case OptView(0).Checked = True Or OptView(1).Checked = True
                Call NameView(txtInput(0).Text, txtInput(1).Text)
            Case OptView(2).Checked
                BadgeView(txtInput(0).Text)
            Case OptView(3).Checked
                POSView(txtInput(0).Text)
        End Select

        'Strip off the last " AND" section of where clause
        If WhereClause <> "" Then WhereClause = WhereClause.Substring(0, Len(WhereClause) - 5)

        'Construct SQL statement
        If Me.frmViews.SelectedIndex = 0 Then
            sSQL = "SELECT DISTINCT EMPLOYEE_ID AS BADGE_NO, " _
                    & "HIRED_DATE AS HIRED_DATE, " _
                    & "LAST_NAME AS LAST_NAME, " _
                    & "FIRST_NAME AS FIRST_NAME, " _
                    & "Street AS STREET, " _
                    & "City AS CITY, " _
                    & "STATE, " _
                    & "ZIP, " _
                    & "DATE_OF_BIRTH AS DATE_OF_BIRTH, " _
                    & "SEX, " _
                    & "DRIVERS_LICENSE_EXPIRATION AS CDL_EXPIRATION, " _
                    & "DRIVERS_LICENSE AS DRIVERS_LICENSE, " _
                    & "LICENSE_CLASS AS LICENSE_CLASS, " _
                    & "EM_OPERATOR_CERTIFICATION_DATE AS OP_CERT_DATE, " _
                    & "union_code AS UNION_CODE, " _
                    & "location_desc AS LOCATION, " _
                    & "location_code AS LOCATION_CODE, " _
                    & "employment_status AS EMP_STATUS " _
                    & "FROM vwHR_C_EMPLOYEES " _
                    & "Where " & WhereClause & "" _
                    & " AND employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout)" _
                    & " AND (employment_status LIKE 'A%' or employment_status LIKE 'L%') " _
                    & " ORDER BY " & OrderBy
        End If

        Dim oConn As New SqlConnection(sConn)
        Dim dataadapter As New SqlDataAdapter(sSQL, oConn)
        Dim ds As New DataSet()
        oConn.Open()
        dataadapter.Fill(ds)
        oConn.Close()

        Call FormatDataGridColumns("Search")
        grdSearch.DataSource = ds.Tables(0)

        Me.lblRecordCount(0).Text = grdSearch.RowCount.ToString & " Records Found"
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text = "Search"
        Exit Sub

viewError:
        Beep()

        Call MsgBox("Search Failed..." & Chr(10) & Err.Description, vbCritical, "Error")
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text = "Search"
        Exit Sub

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : HoldInputs
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Set the form
    '---------------------------------------------------------------------------------------
    '
    Private Sub HoldInputs()
        On Error Resume Next

        Select Case True
            Case OptView(0).Text Or OptView(1).Text
                holdLName = txtInput(0).Text
                holdFName = txtInput(1).Text
            Case OptView(2).Text
                holdBadge = txtInput(0).Text
            Case OptView(4).Text
                holdPosNo = txtInput(0).Text
        End Select

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : GetBaseNumber
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Get the base number
    '---------------------------------------------------------------------------------------
    '
    Private Function GetBaseNumber(sBase As String) As Integer
        On Error GoTo GetBaseNumber_ErrorHandler

        'Search is limited to some users
        Select Case sBase
            Case Is = "GG"
                GetBaseNumber = 4
            Case Is = "SA"
                GetBaseNumber = 1
            Case Is = "AN"
                GetBaseNumber = 6
            Case Is = "Admin"
                GetBaseNumber = 0
            Case Is = "Maint"
                GetBaseNumber = 44
            Case Is = "Annex"
                GetBaseNumber = 88
        End Select

        Exit Function
GetBaseNumber_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetBaseNumber " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, vbInformation, "DMV System")
        Resume Next

    End Function

    '---------------------------------------------------------------------------------------
    ' Procedure : NameView
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Search by name
    '---------------------------------------------------------------------------------------
    '
    Public Sub NameView(inLastName As String, inFirstName As String)
        On Error GoTo NameView_ErrorHandler

        'Use "Like" or "Soundex" search option
        If chkSoundLike.Checked = 0 Then
            If inLastName <> "" Then
                WhereClause = WhereClause & "last_name Like '" & inLastName & "%' AND "
            End If
            If inFirstName <> "" Then
                WhereClause = WhereClause & "first_name Like '" & inFirstName & "%' AND "
            End If
        Else
            If inLastName <> "" Then
                WhereClause = WhereClause & "SOUNDEX(last_name) = SOUNDEX('" & inLastName & "') AND "
            End If
            If inFirstName <> "" Then
                WhereClause = WhereClause & "SOUNDEX(first_name) = SOUNDEX('" & inFirstName & "') AND "
            End If
        End If

        'Set order by option
        If OptView(0).Checked Then
            OrderBy = "last_name, first_name"
        Else
            OrderBy = "first_name, last_name"
        End If

        Exit Sub
NameView_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: NameView " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, vbInformation, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : BadgeView
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Search by Badge Number
    '---------------------------------------------------------------------------------------
    '
    Public Sub BadgeView(inBadge As String)
        On Error GoTo BadgeView_ErrorHandler

        'Set the search by Badge format
        If inBadge <> "" Then
            WhereClause = WhereClause & " employee_id = '" & inBadge & "' AND "
        End If

        OrderBy = "employee_id"

        Exit Sub
BadgeView_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: BadgeView " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, vbInformation, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : POSView
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Search by Job Class
    '---------------------------------------------------------------------------------------
    '
    Public Sub POSView(inPos As String)
        On Error GoTo POSView_ErrorHandler

        If inPos <> "" Then
            Dim testBadge As String
            WhereClause = WhereClause & " C.job_class LIKE '" & inPos & "' AND "
        End If

        OrderBy = "C.position_no"

        Exit Sub
POSView_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: POSView " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, vbInformation, "DMV System")
        Resume Next

    End Sub

    Private Sub SetOptView(ByRef iIndex As Integer)
        '---------------------------------------------------------------------------------------
        ' Procedure : SetOptView
        ' DateTime  : 03/21/2007
        ' Author    : aalvidrez
        ' Purpose   : Set the form based on which button was selected
        '---------------------------------------------------------------------------------------
        '
        On Error GoTo SetOptView_ErrorHandler

        'Which button was selected
        Select Case iIndex
            Case Is = 0  'Search be last name
                chkSoundLike.Visible = True
                lblInput(0).Text = "Last Name"
                lblInput(1).Text = "First Name"
                txtInput(0).Mask = ">CCCCCCCCCCCCCCC"
                txtInput(1).Visible = True
                txtInput(0).Text = holdLName
                txtInput(1).Text = holdFName
                txtInput(0).Select()
            Case Is = 1  'Search be first name
                chkSoundLike.Visible = True
                lblInput(0).Text = "Last Name"
                lblInput(1).Text = "First Name"
                txtInput(1).Mask = ">CCCCCCCCCCCCCCC"
                txtInput(1).Visible = True
                txtInput(0).Text = holdLName
                txtInput(1).Text = holdFName
                txtInput(1).Select()
            Case Is = 2 'Search by badge
                chkSoundLike.Visible = False
                chkSoundLike.Checked = False
                txtInput(0).Mask = "CCCCC"
                lblInput(0).Text = "Badge #"
                lblInput(1).Text = ""
                txtInput(1).Visible = False
                txtInput(0).Text = holdBadge
                holdBadge = txtInput(0).Text
            Case Is = 3 'Search by Job Class (Not used)
                chkSoundLike.Visible = False
                chkSoundLike.Checked = False
                txtInput(0).Mask = "CCCCCC"
                lblInput(0).Text = "Job Class"
                lblInput(1).Text = ""
                txtInput(1).Visible = False
                txtInput(0).Text = holdPosNo
            Case Is = 4
                chkSoundLike.Visible = False
                chkSoundLike.Checked = False
                lblInput(1).Text = ""
                txtInput(1).Visible = False
        End Select

        If MeLoaded Then txtInput(0).Select()

        Exit Sub
SetOptView_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: SetOptView " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, vbInformation, "DMV System")
        Resume Next

    End Sub

    Private Sub optView1_CheckedChanged(sender As Object, e As EventArgs) Handles optView1.Click

        Call SetOptView(0)

    End Sub

    Private Sub optView2_CheckedChanged(sender As Object, e As EventArgs) Handles optView2.Click

        Call SetOptView(1)

    End Sub

    Private Sub optView3_CheckedChanged(sender As Object, e As EventArgs) Handles optView3.Click

        Call SetOptView(2)

    End Sub

    Private Sub cmdUnsigned_Click(sender As Object, e As EventArgs) Handles cmdUnsigned.Click
        '---------------------------------------------------------------------------------------
        ' Procedure : cmdUnsigned
        ' DateTime  : 03/21/2010
        ' thor    : aalvidrez
        ' Purpose   : Returns records needing signatures
        '---------------------------------------------------------------------------------------
        '
        On Error GoTo cmdUnsigned_Error

        'Set variables
        HoldInputs()
        SearchEmployeeId = txtInput(0).Text
        Me.Text = "Searching...Please Wait"
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        WhereClause = ""
        Me.lblRecordCount(0).Text = ""

        'Check for base permission
        If (oBase Is Nothing) Then ' min, can view any section
            If Trim(ListCompany(0).Text) <> "" Then
                If Trim(ListCompany(0).Text) = "Maint" Then
                    WhereClause = WhereClause & "(A.union_code='MN' OR A.union_code='TCU') "
                ElseIf Trim(ListCompany(0).Text) = "Annex" Then
                    WhereClause = WhereClause & "A.location_desc='Garden Grove Location 2' "
                Else
                    WhereClause = WhereClause & "A.location_code='" & GetBaseNumber(ListCompany(0).Text) & "'  "
                End If
            End If
        Else 'Non-min, limited to permission granted
            If oBase.BasePermission = 44 Then
                WhereClause = WhereClause & "(A.union_code='MN' OR A.union_code='TCU')  "
            ElseIf oBase.BasePermission = 88 Then
                WhereClause = WhereClause & "A.location_desc='Garden Grove Location 2'  "
            Else
                WhereClause = WhereClause & "A.location_code='" & oBase.BasePermission & "'  "
            End If
        End If

        If WhereClause <> "" Then
            WhereClause = WhereClause & " AND "
        End If

        'Search Parameter
        Select Case True
            Case OptView(0).Checked = True Or OptView(1).Checked = True
                Call NameView(txtInput(0).Text, txtInput(1).Text)
            Case OptView(2).Checked
                BadgeView(txtInput(0).Text)
            Case OptView(3).Checked
                POSView(txtInput(0).Text)
        End Select

        'Strip off the last " AND" section of where clause
        If WhereClause.Substring(WhereClause.Length - 5, 5) = " AND " Then
            WhereClause = WhereClause.Substring(0, Len(WhereClause) - 5)
        End If

        If WhereClause = "" Then
            WhereClause = WhereClause & "A.employee_id=F.employee_id "
        Else
            WhereClause = WhereClause & " AND A.employee_id=F.employee_id "
        End If
        WhereClause = WhereClause & " AND A.employee_id=S.employee_id "
        WhereClause = WhereClause & " AND A.employee_id NOT IN(SELECT employee_id FROM HR_DMV_OPTOUT) "
        WhereClause = WhereClause & " AND (S.signature IS NULL OR S.created_date < F.record_date) "

        'Construct SQL statement
        Select Case frmViews.SelectedIndex
            Case Is = 0
                sSQL = "SELECT DISTINCT A.EMPLOYEE_ID AS BADGE_NO, " _
                    & "A.LAST_NAME AS LAST_NAME, " _
                    & "A.FIRST_NAME AS FIRST_NAME, " _
                    & "dbo.DecryptData(A.Street) AS STREET, " _
                    & "dbo.DecryptData(A.City) AS CITY, " _
                    & "A.STATE AS STATE, " _
                    & "A.ZIP AS ZIP, " _
                    & "A.HIRED_DATE AS HIRED_DATE, " _
                    & "A.DATE_OF_BIRTH AS DATE_OF_BIRTH, " _
                    & "A.SEX, " _
                    & "A.DRIVERS_LICENSE_EXPIRATION AS CDL_EXPIRATION, " _
                    & "dbo.DecryptData(A.DRIVERS_LICENSE) AS DRIVERS_LICENSE, " _
                    & "A.LICENSE_CLASS AS LICENSE_CLASS, " _
                    & "A.EM_OPERATOR_CERTIFICATION_DATE AS OP_CERT_DATE, " _
                    & "A.union_code AS UNION_CODE, " _
                    & "A.location_desc AS LOCATION, " _
                    & "A.location_code AS LOCATION_CODE, " _
                    & "A.employment_status AS EMP_STATUS " _
                    & "FROM dbo.HR_C_EMPLOYEES A, dbo.HR_DMV_EMPLOYEES F, dbo.HR_DMV_SIGNATURES S " _
                    & "WHERE " & WhereClause & "" _
                    & "AND (A.employment_status LIKE 'A%' or A.employment_status LIKE 'L%') " _
                    & " ORDER BY " & OrderBy
        End Select

        Dim sql As String = sSQL
        Dim oConn As New SqlConnection(sConn)
        Dim dataadapter As New SqlDataAdapter(sql, oConn)
        Dim ds As New DataSet()
        oConn.Open()

        dataadapter.Fill(ds)
        oConn.Close()

        FormatDataGridColumns("UnSigned")

        grdSearch.DataSource = ds.Tables(0)

        Me.lblRecordCount(0).Text = grdSearch.RowCount.ToString & " Records Found"
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text = "Search"
        Exit Sub

cmdUnsigned_Error:
        Beep()
        Call MsgBox("Search Failed..." & Chr(10) & Err.Description, MsgBoxStyle.Critical, "Error")
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Me.Text = "Search"
        Exit Sub
    End Sub

    Private Sub chkSoundLike_CheckedChanged(sender As Object, e As EventArgs) Handles chkSoundLike.CheckedChanged

        If chkSoundLike.Checked Then
            Me.chkSoundLike.ForeColor = Color.Red
        Else
            Me.chkSoundLike.ForeColor = Color.Black
        End If
    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmbSearch_DropDown
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Populate the drop down box
    '---------------------------------------------------------------------------------------
    '
    Private Sub LoadcmbSearch()
        On Error GoTo cmbSearch_DropDown_ErrorHandler

        'Check for listed items
        If cmbSearch.Items.Count > 0 Then Exit Sub

        cmbSearch.DisplayMember = "flag_name"
        cmbSearch.ValueMember = "flag"
        Dim tb As New DataTable
        tb.Columns.Add("flag_name", GetType(String))
        tb.Columns.Add("flag", GetType(Integer))

        'Populate combobox
        sSQL = "SELECT flag,flag_name " & " FROM dbo.hr_dmv_flag_info " & " WHERE display_on_screen='Yes' " & " ORDER BY flag_name"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("flag_name").Value, rs.Fields("flag").Value)
                rs.MoveNext()
            Loop
        End If
        cmbSearch.DataSource = tb

        Exit Sub
cmbSearch_DropDown_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmbSearch_DropDown " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub cmdMajorMinorSearch_Click(sender As Object, e As EventArgs) Handles cmdMajorMinorSearch.Click

        'Clear all data
        Call ClearAll()

        If cmbSearch.Text = "Violations Summary" Then
            LoadViolationsSummary()
        Else
            If cmbSearch.Text = "Suspensions Summary" Then
                LoadSuspensionsSummary()
            Else
                LoadStuff()
            End If
        End If
    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : LoadStuff
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Return records
    '---------------------------------------------------------------------------------------
    '
    Private Sub LoadStuff()
        On Error GoTo LoadStuff_ErrorHandler

        'Set variables
        SearchEmployeeId = "2"
        grdSearch.DataSource = Nothing
        Me.Text = "Searching...Please Wait"
        Dim WClause As String = ""
        Me.lblRecordCount(1).Text = ""

        If SearchEmployeeId <> "" Then
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        End If

        SearchEmployeeId = "0"

        'Admin with full search ability
        If (oBase Is Nothing) Then
            If Trim(ListCompany(1).Text) <> "" Then
                If Trim(ListCompany(1).Text) = "Maint" Then
                    WClause = "(B.union_code='MN' OR B.union_code='TCU') AND "
                ElseIf Trim(ListCompany(1).Text) = "Annex" Then
                    WClause = "B.location_desc='Garden Grove Location 2' AND "
                Else
                    WClause = "B.Location_Code='" & GetBaseNumber(ListCompany(1).Text) & "' AND B.union_code<>'MN' AND B.union_code<>'TCU' AND "
                End If
            End If
        Else
            'Limited search ability
            If oBase.BasePermission = 44 Then
                WClause = "(B.Union_Code='MN' OR B.union_code='TCU') AND "
            ElseIf oBase.BasePermission = 88 Then
                WClause = "B.location_desc='Garden Grove Location 2' AND "
            Else
                WClause = "B.Location_Code='" & oBase.BasePermission & "' AND B.union_code<>'MN' AND B.union_code<>'TCU' AND "
            End If
        End If

        'Major/Minor restrictions
        Select Case True
            Case OptMajorMinor(0).Checked = True
            Case OptMajorMinor(1).Checked = True
                WClause = WClause & "C.major_minor='Major' AND "
            Case OptMajorMinor(2).Checked = True
                WClause = WClause & "C.major_minor='Minor' AND "
        End Select

        Select Case cmbSearch.Text
            Case Is = "", "(all)"
            Case Else
                WClause = WClause & "C.flag_name='" & cmbSearch.Text & "' AND "
        End Select

        'Employee status
        Select Case Trim(listStatus2.Text)
            Case Is = ""
            Case Is = "Active & Leave"
                WClause = WClause & "(B.employment_status LIKE 'A%' Or B.employment_status LIKE 'L%') AND "
            Case Is = "Terms & Retires"
                WClause = WClause & "B.employment_status LIKE 'T%' AND "
            Case Else
                WClause = WClause & "B.employment_status='" & listStatus2.Text.Substring(0, 1) & "' AND "
        End Select

        If WClause = "" Then
            MsgBox("Please select a filter.", MsgBoxStyle.Information, "Stop")
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Sub
        Else
            WClause = WClause.Substring(0, Len(WClause) - 5)
        End If

        'Display message
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Me.Refresh()

        'Construct SQL statement
        sSQL = "SELECT DISTINCT A.employee_id AS BADGE_NO," _
                & " B.hired_date AS HIRED_DATE," _
                & " rtrim(B.last_name) AS LAST_NAME," _
                & " rtrim(B.first_name) AS FIRST_NAME," _
                & " dbo.DecryptData(B.drivers_license) AS DRIVERS_LICENSE," _
                & " C.flag_name AS FLAG_NAME," _
                & " A.message AS MESSAGE," _
                & " dbo.DecryptData(B.street) AS STREET," _
                & " dbo.DecryptData(B.city) AS CITY," _
                & " B.state AS STATE," _
                & " B.zip AS ZIP," _
                & " B.Location_Code AS DEPARTMENT," _
                & " V.comments AS COMMENTS," _
                & " F.record_date AS RECORD_DATE" _
                & " FROM dbo.hr_dmv_employee_flags A," _
                & " dbo.hr_c_employees B, dbo.hr_dmv_flag_info C, " _
                & " dbo.hr_dmv_employees F, dbo.hr_dmv_last_comment_v V " _
                & " WHERE A.employee_id=B.employee_id " _
                & " AND A.employee_id=F.employee_id " _
                & " AND A.flag=C.flag " _
                & " AND A.employee_id=V.employee_id " _
                & " AND " _
                & WClause _
                & " AND A.employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout)" _
                & " ORDER BY 2"

        Dim sql As String = sSQL
        Dim oConn As New SqlConnection(sConn)
        Dim dataadapter As New SqlDataAdapter(sql, oConn)
        Dim ds As New DataSet()
        oConn.Open()
        dataadapter.Fill(ds)
        oConn.Close()

        FormatDataGridColumns("Stuff")
        grdSearch.DataSource = ds.Tables(0)

        Me.lblRecordCount(1).Text = grdSearch.RowCount.ToString & " Records Found"
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text = "Search"
        Exit Sub

LoadStuff_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: LoadStuff " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdExpired_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Check for Expired License or Medical card
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdExpired_Click(sender As Object, e As EventArgs) Handles cmdExpired.Click
        On Error GoTo cmdExpired_Click_ErrorHandler

        Dim FromDate As Date
        Dim ToDate As Date
        Dim DivClause As String = ""
        Dim DateClause As String = ""
        Dim WClause As String = ""
        Dim GetMessage As String = ""
        Dim sFormat As String = "MM/dd/yyyy"

        'Clear all data
        Call ClearAll()

        'Setup the form and set variables
        SearchEmployeeId = "2"
        FromDate = Date.Now.ToString(sFormat)
        ToDate = FromDate
        grdSearch.DataSource = Nothing
        grdSearch.AutoGenerateColumns = False

        Me.Text = "Searching...Please Wait"
        Me.lblRecordCount(2).Text = ""

        'Chcek date range
        Select Case Trim(txtExpiredDays.Text)
            Case Is = "", "0"
            Case Else
                ToDate = System.DateTime.FromOADate(FromDate.ToOADate + VerifyNumber(txtExpiredDays.Text)).ToString(sFormat)
        End Select

        Select Case Trim(txtExpiredDays.Text)
            Case Is = "", "0"
                FromDate = System.DateTime.FromOADate(ToDate.ToOADate - 10000).ToString(sFormat)
        End Select

        'Check for License or Medical
        Select Case True
            Case OptFutureSearch(0).Checked = True
                DateClause = " AND A.license_expiry_date BETWEEN CONVERT(varchar(10), '" & FromDate.ToString(sFormat) & "', 101) AND CONVERT(varchar(10), '" & ToDate.ToString(sFormat) & "', 101)"
                GetMessage = "'Drivers License Expires on '+ CONVERT(varchar(10), A.license_expiry_date, 101)"
            Case OptFutureSearch(1).Checked = True
                DateClause = " AND A.medical_card_date BETWEEN CONVERT(varchar(10), '" & FromDate.ToString(sFormat) & "', 101) AND CONVERT(varchar(10), '" & ToDate.ToString(sFormat) & "', 101)"
                GetMessage = "'Medical Card Expires on '+ CONVERT(varchar(10), A.medical_card_date, 101)"
            Case OptFutureSearch(2).Checked = True
                DateClause = " AND C.VTT_EXP_DATE BETWEEN CONVERT(varchar(10), '" & FromDate.ToString(sFormat) & "', 101) AND CONVERT(varchar(10), '" & ToDate.ToString(sFormat) & "', 101)"
                GetMessage = "'VTT Expires on '+ CONVERT(varchar(10), c.vtt_exp_date, 101)"
            Case OptFutureSearch(3).Checked = True
                DateClause = " AND DATEADD(d, 365, A.record_date) BETWEEN CONVERT(varchar(10), '" & FromDate.ToString(sFormat) & "', 101) AND CONVERT(varchar(10), '" & ToDate.ToString(sFormat) & "', 101)"
                GetMessage = "'DMV Record Expires on '+ CONVERT( varchar(10), DATEADD(d, 365, A.record_date), 101)"
            Case Else
                DateClause = " AND (A.license_expiry_date BETWEEN CONVERT(varchar(10), '" & FromDate.ToString(sFormat) & "', 101) AND CONVERT(varchar(10), '" & ToDate.ToString(sFormat) & "', 101) AND A.medical_card_date BETWEEN CONVERT(varchar(10), '" & FromDate.ToString(sFormat) & "', 101) AND CONVERT(varchar(10), '" & ToDate.ToString(sFormat) & "', 101))"
                GetMessage = "'Drivers License Expires on '+ CONVERT(varchar(10), A.license_expiry_date, 101)+ ' & Medical Card Expires on '+ CONVERT(varchar(10), A.medical_card_date, 101)"
        End Select

        'Get base
        If Trim(ListCompany(2).Text) <> "" Then
            If Trim(ListCompany(2).Text) = "Maint" Then
                DivClause = " AND (B.union_code='MN' OR B.union_code='TCU')"
            ElseIf Trim(ListCompany(2).Text) = "Annex" Then
                DivClause = " AND B.location_desc='Garden Grove Location 2'"
            Else
                DivClause = " AND B.Location_code='" & GetBaseNumber(Trim(ListCompany(2).Text)) & "'"
            End If
        Else
            DivClause = ""
        End If

        'Display Searching image and message
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Erase aryMESSAGES

        Select Case True
            Case OptFutureSearch(0).Checked = True
                ' Search for drivers license expiry
                sSQL = "SELECT DISTINCT A.employee_id AS BADGE_NO, " _
                        & "B.last_name AS LAST_NAME, " _
                        & "B.first_name AS FIRST_NAME, " _
                        & "dbo.DecryptData(B.drivers_license) AS DRIVERS_LICENSE, " _
                        & GetMessage & " AS MESSAGE, " _
                        & "dbo.DecryptData(B.street) AS STREET, " _
                        & "dbo.DecryptData(B.city) AS CITY, " _
                        & "B.state AS STATE, " _
                        & "B.zip AS ZIP, " _
                        & "A.license_expiry_date AS MESSAGE_DATE, " _
                        & "B.job_title AS JOB_TITLE, " _
                        & "B.location_desc AS LOCATION, " _
                        & "A.record_date AS RECORD_DATE " _
                        & "FROM dbo.hr_dmv_employees A, " _
                        & "dbo.hr_c_employees B " _
                        & "WHERE A.EMPLOYEE_ID = B.EMPLOYEE_ID " _
                        & "AND A.employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout) " _
                        & "AND (B.employment_status LIKE 'A%' or B.employment_status LIKE 'L%') " _
                        & WClause & DateClause & DivClause & " " _
                        & "ORDER BY 2"

            Case OptFutureSearch(1).Checked = True
                ' Search for medical date expiry
                sSQL = "SELECT DISTINCT A.employee_id AS BADGE_NO, " _
                       & "B.last_name AS LAST_NAME, " _
                       & "B.first_name AS FIRST_NAME, " _
                       & "dbo.DecryptData(B.drivers_license) AS DRIVERS_LICENSE, " _
                       & GetMessage & " AS MESSAGE, " _
                       & "dbo.DecryptData(B.street) AS STREET, " _
                       & "dbo.DecryptData(B.city) AS CITY, " _
                       & "B.state AS STATE, " _
                       & "B.zip AS ZIP, " _
                       & "A.medical_card_date AS MESSAGE_DATE, " _
                       & "B.job_title AS JOB_TITLE, " _
                       & "B.location_desc AS LOCATION, " _
                       & "A.record_date AS RECORD_DATE " _
                       & "FROM dbo.hr_dmv_employees A, " _
                       & "dbo.hr_c_employees B " _
                       & "WHERE A.EMPLOYEE_ID = B.EMPLOYEE_ID " _
                       & "AND A.employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout) " _
                       & "AND (B.employment_status LIKE 'A%' or B.employment_status LIKE 'L%') " _
                       & WClause & DateClause & DivClause & " " _
                       & "ORDER BY 2"
            Case OptFutureSearch(2).Checked = True
                ' Search for VTT date expiry
                sSQL = "SELECT DISTINCT A.employee_id AS BADGE_NO, " _
                       & "B.last_name AS LAST_NAME, " _
                       & "B.first_name AS FIRST_NAME, " _
                       & "dbo.DecryptData(B.drivers_license) AS DRIVERS_LICENSE, " _
                       & GetMessage & " AS MESSAGE, " _
                       & "dbo.DecryptData(B.street) AS STREET, " _
                       & "dbo.DecryptData(B.city) AS CITY, " _
                       & "B.state AS STATE, " _
                       & "B.zip AS ZIP, " _
                       & "A.medical_card_date AS MESSAGE_DATE, " _
                       & "B.job_title AS JOB_TITLE, " _
                       & "B.location_desc AS LOCATION, " _
                       & "A.record_date AS RECORD_DATE " _
                       & "FROM dbo.hr_dmv_employees A, " _
                       & "dbo.hr_c_employees B, " _
                       & "dbo.hr_dmv_miscellaneous C " _
                       & "WHERE A.EMPLOYEE_ID = B.EMPLOYEE_ID " _
                       & "AND A.EMPLOYEE_ID = C.EMPLOYEE_ID " _
                       & "AND A.employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout) " _
                       & "AND (B.employment_status LIKE 'A%' or B.employment_status LIKE 'L%') " _
                       & WClause & DateClause & DivClause & " " _
                       & "ORDER BY 2"
            Case OptFutureSearch(3).Checked = True
                ' Search for Record date expiry
                sSQL = "SELECT DISTINCT A.employee_id AS BADGE_NO, " _
                       & "B.last_name AS LAST_NAME, " _
                       & "B.first_name AS FIRST_NAME, " _
                       & "dbo.DecryptData(B.drivers_license) AS DRIVERS_LICENSE, " _
                       & GetMessage & " AS MESSAGE, " _
                       & "dbo.DecryptData(B.street) AS STREET, " _
                       & "dbo.DecryptData(B.city) AS CITY, " _
                       & "B.state AS STATE, " _
                       & "B.zip AS ZIP, " _
                       & "A.medical_card_date AS MESSAGE_DATE, " _
                       & "B.job_title AS JOB_TITLE, " _
                       & "B.location_desc AS LOCATION, " _
                       & "A.record_date AS RECORD_DATE " _
                       & "FROM dbo.hr_dmv_employees A, " _
                       & "dbo.hr_c_employees B " _
                       & "WHERE A.EMPLOYEE_ID = B.EMPLOYEE_ID " _
                       & "AND A.employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout) " _
                       & "AND (B.employment_status LIKE 'A%' or B.employment_status LIKE 'L%') " _
                       & WClause & DateClause & DivClause & " " _
                       & "ORDER BY 2"
        End Select

        Dim oConn As New SqlConnection(sConn)
        Dim dataadapter As New SqlDataAdapter(sSQL, oConn)
        Dim ds As New DataSet()
        oConn.Open()
        dataadapter.Fill(ds)
        oConn.Close()

        FormatDataGridColumns("Expired")
        grdSearch.DataSource = ds.Tables(0)

        Me.lblRecordCount(2).Text = IIf(grdSearch.RowCount < 1, "No", grdSearch.RowCount.ToString("###,###")) & " Records Found"
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text = "Search"

        Exit Sub
cmdExpired_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdExpired_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : LoadSuspensionsSummary
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   :
    '---------------------------------------------------------------------------------------
    '
    Private Sub LoadSuspensionsSummary()

        On Error GoTo LoadSuspensionsSummary_ErrorHandler

        Dim WClause As String = ""
        Dim sFormat As String = "MM/dd/yyyy"

        SearchEmployeeId = "2"
        grdSearch.DataSource = Nothing
        Me.Text = "Searching...Please Wait"
        Me.lblRecordCount(2).Text = ""

        If SearchEmployeeId <> "" Then
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        End If

        SearchEmployeeId = "0"

        If (oBase Is Nothing) Then
            If Trim(ListCompany(1).Text) <> "" Then
                If Trim(ListCompany(1).Text) = "Maint" Then
                    WClause = "(A.union_code='MN' OR A.union_code='TCU') AND "
                ElseIf Trim(ListCompany(1).Text) = "Annex" Then
                    WClause = "A.location_desc='Garedn Grove Location 2' AND "
                Else
                    WClause = "A.Location_Code='" & GetBaseNumber(ListCompany(1).Text) & "' AND A.union_code<>'MN' AND A.union_code<>'TCU' AND "
                End If
            End If
        Else
            If oBase.BasePermission = 44 Then
                WClause = "(A.union_code='MN' OR A.union_code='TCU') AND "
            ElseIf oBase.BasePermission = 88 Then
                WClause = "A.location_desc='Garden Grove Location 2' AND "
            Else
                WClause = "A.Location_Code='" & oBase.BasePermission & "' AND A.union_code<>'MN' AND A.union_code<>'TCU' AND "
            End If
        End If

        Select Case Trim(listStatus2.Text)
            Case Is = ""
            Case Is = "Active & Leave"
                WClause = WClause & " (A.employment_status LIKE 'A%' or A.employment_status LIKE 'L%') AND "
            Case Is = "Terms & Retires"
                WClause = WClause & " A.employment_status LIKE 'T%' AND "
            Case Else
                WClause = WClause & " A.employment_status='" & listStatus2.Text.Substring(0, 1) & "' AND "
        End Select

        If Me.txtOrderDate.Visible And IsDate(Me.txtOrderDate.Text) Then
            WClause = WClause & " E.Susp_Order_Date >= '" & Me.txtOrderDate.Text(sFormat) & "' AND "
        End If

        sSQL = "SELECT DISTINCT A.Employee_Id AS BADGE_NO, " _
                & " D.DMV_Employee_Name AS EMP_NAME, " _
                & " dbo.DecryptData(D.Drivers_License_No) AS DRIVERS_LICENSE, " _
                & " E.Susp_CC_Action AS SUSPENTION_ACTION, " _
                & " A.Location_code AS LOCATION, " _
                & " E.Susp_Order_Date AS SUSPENTION_DATE, " _
                & " E.Susp_Effective_Date SUSPENTION_EFF_DATE, " _
                & " E.Susp_Author_Action SUSPENTION_AUTHOR_ACTION, " _
                & " E.Susp_Thru_date AS SUSPENTION_THRU_DATE, " _
                & " E.Susp_Reason_For_Action AS SUSPENTION_REASON, " _
                & " E.Susp_Service_Type SUSPENTION_SERVICE_TYPE, " _
                & " E.Susp_Service_Date AS SUSPENTION_SERVICE_DATE, " _
                & " D.record_date AS RECORD_DATE " _
                & " FROM dbo.HR_C_Employees A, " _
                & " dbo.hr_DMV_Employees D, " _
                & " dbo.hr_DMV_Department_Actions E " _
                & " WHERE A.Employee_Id = D.Employee_Id " _
                & " AND A.Employee_Id = E.Employee_Id AND " _
                & WClause & "" _
                & " A.employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout) "

        sSQL = sSQL & " ORDER BY 2;"

        Dim oConn As New SqlConnection(sConn)
        Dim dataadapter As New SqlDataAdapter(sSQL, oConn)
        Dim ds As New DataSet()
        oConn.Open()
        dataadapter.Fill(ds)
        oConn.Close()

        FormatDataGridColumns("Suspention")
        grdSearch.DataSource = ds.Tables(0)

        Me.lblRecordCount(1).Text = IIf(grdSearch.RowCount < 1, "No", grdSearch.RowCount.ToString("###,###")) & " Records Found"
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text = "Search"

        Exit Sub
LoadSuspensionsSummary_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: LoadSuspensionsSummary " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : LoadViolationsSummary
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the Violation Summary data
    '---------------------------------------------------------------------------------------
    '
    Private Sub LoadViolationsSummary()
        On Error GoTo LoadViolationsSummary_ErrorHandler

        Dim WClause As String = ""
        Dim sFormat As String = "MM/dd/yyyy"

        'Clear grids and set variables
        SearchEmployeeId = "2"
        grdSearch.DataSource = Nothing
        Me.Text = "Searching...Please Wait"
        Me.lblRecordCount(2).Text = ""

        If SearchEmployeeId <> "" Then
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        End If

        SearchEmployeeId = "0"

        'Admin with unlimited rights
        If (oBase Is Nothing) Then
            If Trim(ListCompany(1).Text) <> "" Then
                If Trim(ListCompany(1).Text) = "Maint" Then
                    WClause = "(A.union_code='MN' OR A.union_code='TCU') AND "
                ElseIf Trim(ListCompany(1).Text) = "Annex" Then
                    WClause = "A.location_desc='Garden Grove Location 2' AND "
                Else
                    WClause = "A.Location_Code='" & GetBaseNumber(ListCompany(1).Text) & "' AND A.union_code<>'MN' AND A.union_code<>'TCU' AND "
                End If
            End If
        Else 'Limited access to locations
            If oBase.BasePermission = 44 Then
                WClause = "(A.union_code='MN' OR A.union_code='TCU') AND "
            ElseIf oBase.BasePermission = 88 Then
                WClause = "A.location_desc='Garden Grove Location 2' AND "
            Else
                WClause = "A.Location_Code='" & oBase.BasePermission & "' AND A.union_code<>'MN' AND A.union_code<>'TCU' AND "
            End If
        End If

        If Me.txtOrderDate.Visible And IsDate(Me.txtOrderDate.Text) Then
            WClause = WClause & " E.Conviction_Date >= '" & Me.txtOrderDate.Text(sFormat) & "' AND "
        End If

        'Construct SQL statement
        sSQL = "SELECT DISTINCT A.employee_id AS BADGE_NO, " _
                & " D.DMV_Employee_Name AS EMP_NAME, " _
                & " dbo.DecryptData(D.Drivers_License_No) AS DRIVERS_LICENSE, " _
                & " A.Location_code AS LOCATION, " _
                & " E.Item AS ITEM, " _
                & " E.Viol_Date AS VIOLATION_DATE, " _
                & " E.Conviction_Date AS CONVICTION_DATE, " _
                & " E.Section_A  +  ','  +  E.Section_B AS SEC_VIO_OR_ACC_LOC, " _
                & " E.Statute AS STATUTE, " _
                & " D.Point_Count_1 AS PNT_CNT, " _
                & " D.Point_Count_2 CURR_PNT_CNT, " _
                & " E.Veh_Lic_No AS VEH_LIC_NO, " _
                & " F.Action_Taken AS ACTION_TAKEN, " _
                & " F.To_Be_Resolved_By RESOLVED_BY, " _
                & " F.Resolved_Date DATE_RESOLVED, " _
                & " F.Last_Updated_By LAST_UPDATE_BY, " _
                & " CONVERT(varchar(10), F.Last_Update_Date, 101) AS LAST_UPDATE, " _
                & " D.record_date AS RECORD_DATE" _
                & " FROM dbo.HR_C_Employees A, " _
                & " dbo.hr_DMV_Employees D, " _
                & " dbo.hr_DMV_Violations E, " _
                & " dbo.hr_DMV_Comments F " _
                & " Where A.Employee_Id = D.Employee_Id " _
                & " AND A.Employee_Id = E.Employee_Id " _
                & " AND E.Employee_Id = F.Employee_Id " _
                & " AND E.Viol_Date = F.Key_Date " _
                & " AND A.employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout) AND " _
                & WClause & "" _
                & " (A.employment_status LIKE 'A%' or A.employment_status LIKE 'L%') "

        'Add Order By clause
        sSQL = sSQL & " ORDER BY A.Employee_Id "

        Dim oConn As New SqlConnection(sConn)
        Dim dataadapter As New SqlDataAdapter(sSQL, oConn)
        Dim ds As New DataSet()
        oConn.Open()
        dataadapter.Fill(ds)
        oConn.Close()

        FormatDataGridColumns("Violation")
        grdSearch.DataSource = ds.Tables(0)

        Me.lblRecordCount(2).Text = IIf(grdSearch.RowCount < 1, "No", grdSearch.RowCount.ToString("###,###")) & " Records Found"
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text = "Search"

        Exit Sub
LoadViolationsSummary_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: LoadViolationsSummary " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub cmdExcel2_Click(sender As Object, e As EventArgs) Handles cmdExcel2.Click

        ExportToExcel()

    End Sub

    Private Sub cmdExcel1_Click(sender As Object, e As EventArgs) Handles cmdExcel1.Click

        ExportToExcel()

    End Sub

    Private Sub ExportToExcel()

        ' Creating a Excel object.
        Dim excel As Microsoft.Office.Interop.Excel._Application = New Microsoft.Office.Interop.Excel.Application()
        Dim workbook As Microsoft.Office.Interop.Excel._Workbook = excel.Workbooks.Add(Type.Missing)
        Dim worksheet As Microsoft.Office.Interop.Excel._Worksheet = Nothing

        Try

            worksheet = workbook.ActiveSheet

            worksheet.Name = "ExportedFromDatGrid"

            Dim cellRowIndex As Integer = 1
            Dim cellColumnIndex As Integer = 1

            'Loop through each row and read value from each column.
            For i As Integer = 0 To grdSearch.Rows.Count - 2
                For j As Integer = 0 To grdSearch.Columns.Count - 1
                    ' Excel index starts from 1,1. As first Row would have the Column headers, adding a condition check.
                    If cellRowIndex = 1 Then
                        worksheet.Cells(cellRowIndex, cellColumnIndex) = grdSearch.Columns(j).HeaderText
                    ElseIf Not IsNothing(grdSearch.Rows(i).Cells(j).Value) Then 'Added to avoid reading empty cells
                        worksheet.Cells(cellRowIndex, cellColumnIndex) = grdSearch.Rows(i).Cells(j).Value.ToString()
                    End If
                    cellColumnIndex += 1
                Next
                cellColumnIndex = 1
                cellRowIndex += 1

            Next

            'Getting the location and file name of the excel to save from user.
            Dim saveDialog As New SaveFileDialog()
            saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*"
            saveDialog.FilterIndex = 2

            If saveDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                workbook.SaveAs(saveDialog.FileName)
                MessageBox.Show("Export Successful")
            End If

        Catch ex As System.Exception

            MessageBox.Show(ex.Message)
        Finally
            excel.Quit()
            workbook = Nothing
            excel = Nothing
        End Try

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : LoadMessages
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the messages into grid
    '---------------------------------------------------------------------------------------
    '
    Private Sub LoadMessages(ByVal sEmpID As String)
        On Error GoTo LoadMessages_ErrorHandler

        'Clear the grid
        grdFlags.Rows.Clear()
        grdFlags.AutoGenerateColumns = False

        sSQL = "SELECT DISTINCT * FROM vwGetFlagRecords " _
                & "WHERE EMPLOYEE_ID = '" & sEmpID & "' " _
                & "ORDER BY [MAJOR/MINOR]"

        StandardResultSet()

        If rs.RecordCount = 0 Then
            Me.lblFlagRecords.Text = "No Flag Records Found"
            Exit Sub
        End If

        Dim i As Integer = 0
        rs.MoveFirst()
        While Not rs.EOF
            grdFlags.Rows.Add()
            grdFlags.Rows(i).Cells("MESSAGE").Value = rs.Fields("MESSAGE").Value
            grdFlags.Rows(i).Cells("Flag_Name").Value = rs.Fields("FLAG NAME").Value
            grdFlags.Rows(i).Cells("Major_Minor").Value = rs.Fields("MAJOR/MINOR").Value
            i += 1
            rs.MoveNext()
        End While

        lblFlagRecords.Visible = True
        Me.lblFlagRecords.Text = IIf(i < 1, "No", i.ToString("###,###")) & " Flag Records Found"

        Exit Sub
LoadMessages_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: LoadMessages " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub SizeForm()
        On Error GoTo ExitMe
        Dim dHeightAvailable As Double

        'Set the form size and location based on srenn size and resolution
        Me.Top = MDIForm1.DefInstance.EnCrypt1.Height + 42
        Me.Left = 0
        Me.Height = (MDIForm1.DefInstance.ClientRectangle.Height) - 85
        grdSearch.Top = frmViews.Top + frmViews.Height + 10
        grdSearch.Height = 475
        lblFlagRecords.Top = grdSearch.Top + grdSearch.Height
        grdFlags.Top = lblFlagRecords.Top + lblFlagRecords.Height
        grdFlags.Height = Me.Height - (grdFlags.Top + 45)
        tabInformation.Height = (Me.Height - tabInformation.Top) - 75
        dHeightAvailable = ((tabInformation.Height - (lblViolations.Height + lblMisc.Height + lblSuspensions.Height)) / 3) - 12
        lblViolations.Top = 10
        grdViolations.Top = lblViolations.Top + lblViolations.Height
        grdViolations.Height = dHeightAvailable
        lblSuspensions.Top = grdViolations.Top + grdViolations.Height
        grdSuspensions.Top = lblSuspensions.Top + lblSuspensions.Height
        grdSuspensions.Height = dHeightAvailable
        lblMisc.Top = grdSuspensions.Top + grdSuspensions.Height
        grdMisc.Top = lblMisc.Top + lblMisc.Height
        grdMisc.Height = dHeightAvailable

ExitMe: System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : GetHRInfo
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Fetch the DMV data and populate the datagrid
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetHRInfo(ByVal sEmpID As String)
        On Error Resume Next

        Dim i As Short

        'Clear the textboxs first
        For i = 0 To 5
            txtHR(i).Text = ""
        Next

        sSQL = "SELECT employee_id, " _
                & " last_name + ', ' + first_name + ' ' + ISNULL(mid_name, '') as employee_name, " _
                & " employment_status as status, " _
                & " location_Desc, " _
                & " Location_Code, " _
                & " JOB_TITLE " _
                & " FROM dbo.HR_C_EMPLOYEES " _
                & " WHERE employee_id='" & sEmpID & "' " _
                & " AND employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout)"

        'Get the data
        StandardResultSet()

        txtHR(0).Text = RemoveSpaces(rs.Fields("employee_id").Value)
        txtHR(1).Text = RemoveSpaces(rs.Fields("employee_name").Value)
        txtHR(2).Text = RemoveSpaces(rs.Fields("status").Value)
        txtHR(3).Text = RemoveSpaces(rs.Fields("JOB_TITLE").Value)
        txtHR(4).Text = RemoveSpaces(rs.Fields("Location_Code").Value)
        txtHR(5).Text = RemoveSpaces(rs.Fields("location_Desc").Value)

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : GetDMVInfo
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Fetch the DMV data and populate the datagrid
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetDMVInfo(ByVal sEmpID As String)
        On Error Resume Next

        Dim i As Short
        Dim sFormat As String = "MM/dd/yyyy"
        Dim dSigRecordDate As Date
        Dim dEmpRecordDate As Date

        'Clear the textboxs first
        For i = 0 To 13
            txtDMV(i).Text = ""
        Next

        sSQL = "SELECT F.*, " _
                & "[dbo].[DecryptData](DRIVERS_LICENSE_NO) AS CDL, " _
                & "S.signature, " _
                & "S.created_date, " _
                & "S.record_date as sig_record_date, " _
                & "F.record_date as emp_record_date " _
                & "FROM dbo.HR_DMV_EMPLOYEES AS F INNER JOIN dbo.HR_DMV_SIGNATURES AS S ON F.EMPLOYEE_ID = S.EMPLOYEE_ID  " _
                & "WHERE F.employee_id='" & sEmpID & "'"

        'Get the data
        StandardResultSet()

        fmDMVInfo.Text = "DMV Information (" & RemoveSpaces(rs.Fields("DMV_EMPLOYEE_NAME").Value) & ")"
        txtDMV(0).Text = RemoveSpaces(rs.Fields("CDL").Value)
        'txtDMV(1).Text = RemoveSpaces(rs.Fields("EXTENSION").Value)
        txtDMV(2).Text = CDate(rs.Fields("MEDICAL_CARD_DATE").Value).ToString(sFormat)
        txtDMV(3).Text = CDate(rs.Fields("LICENSE_EXPIRY_DATE").Value).ToString(sFormat)
        txtDMV(4).Text = CDate(rs.Fields("BIRTH_DATE").Value).ToString(sFormat)
        txtDMV(5).Text = RemoveSpaces(rs.Fields("WEIGHT").Value)
        txtDMV(6).Text = RemoveSpaces(rs.Fields("HEIGHT").Value)
        txtDMV(7).Text = RemoveSpaces(rs.Fields("LICENSE_CLASS").Value)
        txtDMV(8).Text = RemoveSpaces(rs.Fields("COMMERCIAL").Value)
        txtDMV(9).Text = RemoveSpaces(rs.Fields("POINT_COUNT_1").Value) & "." & RemoveSpaces(rs.Fields("POINT_COUNT_2").Value)
        txtDMV(10).Text = CDate(rs.Fields("RECORD_DATE").Value).ToString(sFormat)
        dSigRecordDate = CDate(rs.Fields("sig_record_date").Value).ToString(sFormat)
        dEmpRecordDate = CDate(rs.Fields("emp_record_date").Value).ToString(sFormat)
        txtDMV(11).Text = RemoveSpaces(rs.Fields("SEX").Value)
        txtDMV(12).Text = RemoveSpaces(rs.Fields("HAIR").Value)
        txtDMV(13).Text = RemoveSpaces(rs.Fields("EYES").Value)

        If CDate(txtDMV(2).Text) <= Date.Now.ToString(sFormat) Then
            lblMedicalCard.ForeColor = Color.Red
        Else
            lblMedicalCard.ForeColor = Color.Black
        End If

        If CDate(txtDMV(3).Text) <= Date.Now.ToString(sFormat) Then
            lblCDLExpDate.ForeColor = Color.Red
        Else
            lblCDLExpDate.ForeColor = Color.Black
        End If

        Me.txtSignature.Text = ""

        'Set the VTT Expiration Date
        sSQL = "Select VTT_EXP_DATE " _
                & "FROM [dbo].[HR_DMV_MISCELLANEOUS] " _
                & "WHERE [EMPLOYEE_ID] = '" & sEmpID & "' " _
                & "And [MISC_COMMENT] Like 'VERI OF TRNST TRNG DOC EXP%'"

        'Get the data
        StandardResultSet()

        txtDMV(1).Text = RemoveSpaces(rs.Fields("VTT_EXP_DATE").Value)
        If CDate(txtDMV(1).Text) <= Date.Now.ToString(sFormat) Then
            lblVTTExpDate.ForeColor = Color.Red
        Else
            lblVTTExpDate.ForeColor = Color.Black
        End If

        sSQL = "SELECT * FROM dbo.HR_DMV_SIGNATURES WHERE EMPLOYEE_ID = '" & sEmpID & "'"
        StandardResultSet()

        If (rs.Fields("SIGNATURE").Value Is DBNull.Value) Or dSigRecordDate <> dEmpRecordDate Then
            txtSignature.Text = "This record requires immediate signature!"
            txtSignature.BackColor = Color.Yellow
            txtSignature.ForeColor = Color.Red
        Else
            txtSignature.Text = "This record signed " & rs.Fields("CREATED_DATE").Value & " by " & rs.Fields("SIGNATURE").Value
            txtSignature.BackColor = Color.PaleGreen
            txtSignature.ForeColor = Color.Black
        End If

        lblExpiredMessage.Visible = (DateDiff("d", dEmpRecordDate, Now()) > 365)

    End Sub

    Private Sub cmdSignature_Click(sender As Object, e As EventArgs) Handles cmdSignature.Click
        '---------------------------------------------------------------------------------------
        ' Procedure : cmdSignRecord_Click
        ' DateTime  : 03/18/2010
        ' Author    : aalvidrez
        ' Purpose   : Sign records
        '---------------------------------------------------------------------------------------
        '
        On Error GoTo cmdSignRecord_Click_ErrorHandler

        Dim vReturn As Object

        If (SearchEmployeeId Is DBNull.Value) Or SearchEmployeeId = "" Then
            MsgBox("You must first select an Employee", MsgBoxStyle.Information, "No Employee Selected")
            Exit Sub
        End If

        vReturn = MsgBox("I have reviewed this record for compliance with VC Section 1808.1", MsgBoxStyle.Information + MsgBoxStyle.YesNoCancel, "Sign Record")
        If vReturn = MsgBoxResult.Yes Then

            sSQL = ""
            sSQL = "SELECT TOP 1 ID, dbo.hr_dmv_signatures.signature, "
            sSQL = sSQL & "dbo.hr_dmv_signatures.EMPLOYEE_ID, "
            sSQL = sSQL & "dbo.hr_dmv_signatures.record_date, "
            sSQL = sSQL & "dbo.hr_dmv_signatures.created_date "
            sSQL = sSQL & "FROM dbo.hr_dmv_signatures "
            sSQL = sSQL & "WHERE dbo.hr_dmv_signatures.employee_id = '" & SearchEmployeeId & "'"

            If oConn.State <> ADODB.ObjectStateEnum.adStateOpen Then
                MsgBox("Connection could not be found. Contact your systems administrator.", MsgBoxStyle.Critical, "Connection error")
            End If

            rs = New ADODB.Recordset
            rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)

            If rs.RecordCount > 0 Then 'Record exist so update data
                rs.MoveFirst()
                rs.Fields("EMPLOYEE_ID").Value = SearchEmployeeId
                rs.Fields("signature").Value = LCase(Environ("USERNAME"))
                rs.Fields("record_date").Value = txtDMV11.Text
                rs.Fields("created_date").Value = Date.Now.ToString("yyyy-MM-dd hh:mm:ss")
                rs.Update()
            Else 'Record does not exist. Create new
                sSQL = "INSERT INTO dbo.hr_dmv_signatures " & "(employee_id,record_date,signature) " & "VALUES (" & SearchEmployeeId & ", '" & txtDMV11.Text("MM/dd/yyyy") & "', '" & LCase(Environ("USERNAME")) & "')"

                cmd = New ADODB.Command
                With cmd
                    .let_ActiveConnection(oConn)
                    .CommandType = ADODB.CommandTypeEnum.adCmdText
                    .CommandText = sSQL
                End With
                cmd.Execute()
            End If

            rs.Close()
            MsgBox("Record for " & txtHR2.Text & " has been updated.", MsgBoxStyle.Information, "Record update")
            Call GetDMVInfo(SearchEmployeeId)
        Else
            Exit Sub
        End If

        Exit Sub

cmdSignRecord_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: Command2_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Exit Sub
    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : GetViolations
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Fetch the Violation data
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetViolations(ByVal sEmpID As String)
        On Error GoTo GetViolations_ErrorHandler

        'Clear the grid
        grdViolations.Rows.Clear()
        grdViolations.AutoGenerateColumns = False

        sSQL = "SELECT DISTINCT" _
                & " [EMPLOYEE_ID]," _
                & " [ITEM]," _
                & " [VIOlATION DATE]," _
                & " [CONVICTION DATE]," _
                & " [SECTION]," _
                & " [STATUTE]," _
                & " [DOCKET/FILE NO]," _
                & " [COURT/ACC RPT NO]," _
                & " [VEHICLE LIC NO]," _
                & " [COMMENTS]" _
                & " FROM vwGetViolationRecords " _
                & " WHERE EMPLOYEE_ID ='" & sEmpID & "' "
        '& " ORDER BY SEQUENCE"

        StandardResultSet()

        If rs.RecordCount = 0 Then
            Me.lblViolations.Text = "No Violation Records Found"
            Exit Sub
        End If

        Dim k As Integer = 0

        rs.MoveFirst()
        While Not rs.EOF
            grdViolations.Rows.Add()
            grdViolations.Rows(k).Cells("ITEM").Value = rs.Fields("ITEM").Value
            grdViolations.Rows(k).Cells("VIOlATION_DATE").Value = rs.Fields("VIOlATION DATE").Value
            grdViolations.Rows(k).Cells("CONVICTION_DATE").Value = rs.Fields("CONVICTION DATE").Value
            grdViolations.Rows(k).Cells("SECTION").Value = rs.Fields("SECTION").Value
            grdViolations.Rows(k).Cells("STATUTE").Value = rs.Fields("STATUTE").Value
            grdViolations.Rows(k).Cells("DOCKET_FILE_NO").Value = rs.Fields("DOCKET/FILE NO").Value
            grdViolations.Rows(k).Cells("COURT_ACC_RPT_NO").Value = rs.Fields("COURT/ACC RPT NO").Value
            grdViolations.Rows(k).Cells("VEHICLE_LIC_NO").Value = rs.Fields("VEHICLE LIC NO").Value
            grdViolations.Rows(k).Cells("COMMENTS_1").Value = rs.Fields("COMMENTS").Value
            k += 1
            rs.MoveNext()
        End While

        Me.lblViolations.Text = IIf(k < 1, "No", k & " Violation Records Found")

        Exit Sub
GetViolations_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetViolations " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Exit Sub

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : GetSuspensions
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Fetch the Susupention data from the database
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetSuspensions(ByVal sEmpID As String)
        On Error GoTo GetSuspensions_ErrorHandler

        'Clear the grid
        grdSuspensions.Rows.Clear()
        grdSuspensions.AutoGenerateColumns = False

        sSQL = "SELECT * FROM vwGetSuspensionRecords " _
                & "WHERE EMPLOYEE_ID ='" & sEmpID & "' " _
                & "ORDER BY SEQUENCE"

        StandardResultSet()

        If rs.RecordCount = 0 Then
            Me.lblSuspensions.Text = "No Suspension Records Found"
            Exit Sub
        End If

        Dim k As Integer = 0

        rs.MoveFirst()
        While Not rs.EOF
            grdSuspensions.Rows.Add()
            grdSuspensions.Rows(k).Cells("CC_ACTION").Value = rs.Fields("CC ACTION").Value
            grdSuspensions.Rows(k).Cells("ORDER_DATE").Value = rs.Fields("ORDER DATE").Value
            grdSuspensions.Rows(k).Cells("EFFECTIVE_DATE").Value = rs.Fields("EFFECTIVE DATE").Value
            grdSuspensions.Rows(k).Cells("AUTHOR_ACTION").Value = rs.Fields("AUTHOR ACTION").Value
            grdSuspensions.Rows(k).Cells("THRU_DATE").Value = rs.Fields("THRU DATE").Value
            grdSuspensions.Rows(k).Cells("REASON_FOR_ACTION").Value = rs.Fields("REASON FOR ACTION").Value
            grdSuspensions.Rows(k).Cells("SERVICE_TYPE").Value = rs.Fields("SERVICE TYPE").Value
            grdSuspensions.Rows(k).Cells("SERVICE_DATE").Value = rs.Fields("SERVICE DATE").Value
            grdSuspensions.Rows(k).Cells("FILE_TYPE").Value = rs.Fields("FILE TYPE").Value
            grdSuspensions.Rows(k).Cells("ACTION_TAKEN").Value = rs.Fields("ACTION TAKEN").Value
            grdSuspensions.Rows(k).Cells("TO_BE_RESOLVED_BY").Value = rs.Fields("TO BE RESOLVED BY").Value
            grdSuspensions.Rows(k).Cells("RESOLVED_DATE").Value = rs.Fields("RESOLVED DATE").Value
            grdSuspensions.Rows(k).Cells("LAST_UPDATED_BY_1").Value = rs.Fields("LAST UPDATED BY").Value
            grdSuspensions.Rows(k).Cells("LAST_UPDATED").Value = rs.Fields("LAST UPDATED").Value
            grdSuspensions.Rows(k).Cells("SEQUENCE_1").Value = rs.Fields("SEQUENCE").Value
            grdSuspensions.Rows(k).Cells("EMPLOYEE_ID_2").Value = rs.Fields("EMPLOYEE_ID").Value
            k += 1
            rs.MoveNext()
        End While

        Me.lblSuspensions.Text = IIf(k < 1, "No", k & " Suspension Records Found")

        Exit Sub
GetSuspensions_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetSuspensions " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Exit Sub

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : GetMiscellaneous
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Fetch the Miscallaneous data from the database
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetMiscellaneous(ByVal sEmpID As String)
        On Error GoTo GetMiscellaneous_ErrorHandler

        'Clear the grid
        grdMisc.Rows.Clear()
        grdMisc.AutoGenerateColumns = False

        sSQL = "SELECT [COMMENTS],  " _
                & "[CREATED BY], " _
                & "[CREATION DATE], " _
                & "[LAST UPDATED BY], " _
                & "[LAST UPDATED DATE], " _
                & "[SEQUENCE], " _
                & "[EMPLOYEE_ID] " _
                & "FROM vwGetMiscRecords " _
                & "WHERE EMPLOYEE_ID ='" & sEmpID & "' " _
                & "ORDER BY SEQUENCE"

        StandardResultSet()

        If rs.RecordCount = 0 Then
            Me.lblMisc.Text = "No Miscellaneou Records Found"
            Exit Sub
        End If

        Dim k As Integer = 0
        rs.MoveFirst()
        While Not rs.EOF
            grdMisc.Rows.Add()
            grdMisc.Rows(k).Cells("COMMENTS").Value = rs.Fields("COMMENTS").Value
            grdMisc.Rows(k).Cells("CREATED_BY").Value = rs.Fields("CREATED BY").Value
            grdMisc.Rows(k).Cells("CREATION_DATE").Value = rs.Fields("CREATION DATE").Value
            grdMisc.Rows(k).Cells("LAST_UPDATED_BY").Value = rs.Fields("LAST UPDATED BY").Value
            grdMisc.Rows(k).Cells("LAST_UPDATED_DATE").Value = rs.Fields("LAST UPDATED DATE").Value
            grdMisc.Rows(k).Cells("SEQUENCE").Value = rs.Fields("SEQUENCE").Value
            grdMisc.Rows(k).Cells("EMPLOYEE_ID_1").Value = rs.Fields("EMPLOYEE_ID").Value
            k += 1
            rs.MoveNext()
        End While

        Me.lblMisc.Text = IIf(k < 1, "No", k & " Miscellaneous Records Found")

        Exit Sub
GetMiscellaneous_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetMiscellaneous " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Exit Sub

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : GetAKA
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Fetch the AKA information
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetAKA(ByVal sEmpID As String)
        On Error GoTo GetAKA_ErrorHandler

        'Clear the grid
        grdAKA.Rows.Clear()
        grdAKA.DataSource = Nothing

        sSQL = "SELECT * FROM vwGetAKARecords" _
                & " WHERE EMPLOYEE_ID ='" & sEmpID & "'" _
                & " ORDER BY SEQUENCE"

        StandardResultSet()

        If rs.RecordCount = 0 Then
            Me.lblAKA.Text = "No AKA Records Found"
            Exit Sub
        End If

        Dim k As Integer = 0
        rs.MoveFirst()
        While Not rs.EOF
            grdAKA.Rows.Add()
            grdAKA.Rows(k).Cells("AKA_NAME").Value = rs.Fields("AKA NAME").Value
            grdAKA.Rows(k).Cells("CREATED_BY_4").Value = rs.Fields("CREATED BY").Value
            grdAKA.Rows(k).Cells("CREATION_DATE_4").Value = rs.Fields("CREATED DATE").Value
            grdAKA.Rows(k).Cells("LAST_UPDATED_BY_4").Value = rs.Fields("LAST UPDATED BY").Value
            grdAKA.Rows(k).Cells("LAST_UPDATED_DATE_4").Value = rs.Fields("LAST UPDATE DATE").Value
            grdAKA.Rows(k).Cells("SEQUENCE_4").Value = rs.Fields("SEQUENCE").Value
            grdAKA.Rows(k).Cells("EMPLOYEE_ID_4").Value = rs.Fields("EMPLOYEE_ID").Value
            k += 1
            rs.MoveNext()
        End While

        Me.lblAKA.Text = IIf(k < 1, "No", k & " AKA Records Found")

        Exit Sub
GetAKA_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetAKA " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : GetADDRESSES
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Fetch the address information
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetADDRESSES(ByVal sEmpID As String)
        On Error GoTo GetADDRESSES_ErrorHandler

        'Clear the grid
        'grdAddress.Rows.Clear()
        'grdAddress.DataSource = Nothing

        sSQL = "SELECT * FROM vwGetAddressRecords " _
                & " WHERE EMPLOYEE_ID ='" & sEmpID & "' " _
                & " ORDER BY SEQUENCE  "

        StandardResultSet()

        'If rs.RecordCount = 0 Then
        'Me.lblAddress.Text = "No Address Records Found"
        'Exit Sub
        'End If

        Dim k As Integer = 0
        rs.MoveFirst()
        While Not rs.EOF
            'grdAddress.Rows.Add()
            'grdAddress.Rows(k).Cells("ADDRESS").Value = rs.Fields("ADDRESS").Value
            'grdAddress.Rows(k).Cells("CREATED_BY_5").Value = rs.Fields("CREATED BY").Value
            'grdAddress.Rows(k).Cells("CREATION_DATE_5").Value = rs.Fields("CREATED DATE").Value
            'grdAddress.Rows(k).Cells("SEQUENCE_5").Value = rs.Fields("SEQUENCE").Value
            'grdAddress.Rows(k).Cells("EMPLOYEE_ID_5").Value = rs.Fields("EMPLOYEE_ID").Value
            k += 1
            rs.MoveNext()
        End While

        'Me.lblAddress.Text = IIf(k < 1, "No", k & " Address Records Found")

        Exit Sub
GetADDRESSES_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetADDRESSES " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub cmdAddComment_Click(sender As Object, e As EventArgs) Handles cmdAddComment.Click
        '---------------------------------------------------------------------------------------
        ' Procedure : AddComment
        ' DateTime  : 03/21/2007
        ' Author    : aalvidrez
        ' Purpose   : Add a comment to the current record
        '---------------------------------------------------------------------------------------
        '
        On Error GoTo AddComment_ErrorHandler

        'Check for current record
        If SearchEmployeeId = "" Then
            MsgBox("Please select an employee first!", MsgBoxStyle.Information, "Stop")
            Exit Sub
        End If

        'Check for current comment
        If Trim(txtComments.Text) = "" Then
            MsgBox("Please enter a comment!", MsgBoxStyle.Information, "Stop")
            txtComments.Focus()
            Exit Sub
        End If

        'Check for special characters
        If InStr(txtComments.Text, "'") > 0 Then
            MsgBox("Please remove any special characters from comment!", MsgBoxStyle.Information, "Stop")
            txtComments.Focus()
            Exit Sub
        End If

        'Insert record
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        sSQL = "INSERT INTO dbo.hr_dmv_user_comments " _
                & "(company,employee_id,comments,created_by) VALUES (" _
                & "'" & "OCTA" & "','" _
                & SearchEmployeeId & "','" _
                & txtComments.Text & "','" _
                & LCase(Environ("USERNAME")) & "')"

        cmd = New ADODB.Command
        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdText
            .CommandText = sSQL
        End With
        cmd.Execute()

        GetComments(SearchEmployeeId)
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

        Exit Sub
AddComment_ErrorHandler:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: AddComment " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub cmdDeleteComment_Click(sender As Object, e As EventArgs) Handles cmdDeleteComment.Click
        '---------------------------------------------------------------------------------------
        ' Procedure : DeleteComment
        ' DateTime  : 03/21/2007
        ' Author    : aalvidrez
        ' Purpose   : Delete the current comment
        '---------------------------------------------------------------------------------------
        '
        On Error GoTo DeleteComment_ErrorHandler

        sSQL = grdComments.Rows.GetRowCount(DataGridViewElementStates.Selected)

        If grdComments.RowCount <= 0 Then 'Or grdComments.SelectedRows <= 0
            MsgBox("Please select a comment to delete!", MsgBoxStyle.Information, "Stop")
            grdComments.Focus()
            Exit Sub
        End If

        If MsgBox("Delete selected comment?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm") = MsgBoxResult.No Then Exit Sub
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

        sSQL = "DELETE " & " FROM dbo.hr_dmv_user_comments " & " WHERE company='OCTA' " & " AND employee_id='" & SearchEmployeeId & "'" & " AND sequence_nbr=" & grdComments.Item(3, grdComments.CurrentRow.Index).Value & ""

        cmd = New ADODB.Command
        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdText
            .CommandText = sSQL
        End With
        cmd.Execute()

        GetComments(SearchEmployeeId)
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        MsgBox("Comment deleted", MsgBoxStyle.Information, "Deleted")

        Exit Sub
DeleteComment_ErrorHandler:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: DeleteComment " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : GetComments
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Ftech the Comment data from the database
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetComments(ByVal sEmpID As String)
        On Error GoTo GetComments_ErrorHandler

        grdComments.Rows.Clear()
        grdComments.DataSource = Nothing

        sSQL = "SELECT * FROM dbo.vwGetCommentRecords " _
                & "WHERE EMPLOYEE_ID ='" & sEmpID & "' " _
                & "ORDER BY SEQUENCE DESC"

        StandardResultSet()

        If rs.RecordCount = 0 Then
            Me.lblComments.Text = "No Comment Records Found"
            Exit Sub
        End If

        Dim k As Integer = 0
        rs.MoveFirst()
        While Not rs.EOF
            grdComments.Rows.Add()
            grdComments.Rows(k).Cells("COMMENT_6").Value = rs.Fields("COMMENTS").Value
            grdComments.Rows(k).Cells("COMMENT_DATE_6").Value = rs.Fields("COMMENT DATE").Value
            grdComments.Rows(k).Cells("CREATED_BY_6").Value = rs.Fields("CREATED BY").Value
            grdComments.Rows(k).Cells("SEQUENCE_6").Value = rs.Fields("SEQUENCE").Value
            grdComments.Rows(k).Cells("EMPLOYEE_ID_6").Value = rs.Fields("EMPLOYEE_ID").Value
            k += 1
            rs.MoveNext()
        End While

        Me.lblComments.Text = IIf(k < 1, "No", k & " Comment Records Found")

        Exit Sub
GetComments_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetComments " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : SetComment
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Only allow the creator of the comment to edit the current comment
    '---------------------------------------------------------------------------------------
    '
    Private Sub grdComments_SelectionChanged(sender As Object, e As EventArgs) Handles grdComments.SelectionChanged
 		On Error Resume Next

        'Format the comment
        txtComments.Text = RemoveSpaces(grdComments.Item(0, grdComments.CurrentRow.Index).Value)

        'Compare the current user with the "Created By" field
        If LCase(RemoveSpaces(grdComments.Item(2, grdComments.CurrentRow.Index).Value)) <> LCase(Environ("USERNAME")) Then
            cmdDeleteComment.Enabled = False
        Else
            cmdDeleteComment.Enabled = True
        End If

        Exit Sub
grid_RowColChange_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: grid_RowColChange " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub optView1_CheckedChanged_1(sender As Object, e As EventArgs) Handles optView3.CheckedChanged

        txtInput1.Select()

    End Sub

    Private Sub optView2_CheckedChanged_1(sender As Object, e As EventArgs) Handles optView2.CheckedChanged

        txtInput1.Select()

    End Sub

    Private Sub optView3_CheckedChanged_1(sender As Object, e As EventArgs) Handles optView3.CheckedChanged

        txtInput2.Select()

    End Sub


    Private Sub frmViews_TabIndexChanged(sender As Object, e As EventArgs) Handles frmViews.TabIndexChanged

        'Dsiplay the appropraite grid
        Select Case frmViews.TabIndex
            Case Is = 0
                Me.AcceptButton = cmdGo
            Case Is = 1
                Me.AcceptButton = cmdMajorMinorSearch
            Case Is = 2
                Me.AcceptButton = cmdExpired
        End Select

    End Sub

    Private Sub cmdPrintScreen_Click(sender As Object, e As EventArgs) Handles cmdPrintScreen.Click
        '---------------------------------------------------------------------------------------
        ' Procedure : cmdPrintScreen_Click
        ' DateTime  : 03/21/2007
        ' Author    : aalvidrez
        ' Purpose   : Printout current record
        '---------------------------------------------------------------------------------------
        '
        On Error GoTo cmdPrintScreen_Click_ErrorHandler

        Dim Outstring As String
        Dim tdate As Date
        Dim r As Short
        Dim Dump As String = ""
        Dim x As Short
        Dim TValue As String
        Dim TCaption As String
        Dim Tabber As String = ""
        Dim Printer As New PCPrint
        Dim sStr As String = ""

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        tdate = Date.Now.ToShortDateString
        Dim txtBox As New TextBox
        sStr = sStr & "-------------------------------------------------------------------------------------------------------------------------------------" & vbCrLf
        sStr = sStr & "Department HR/DMV System: Record Date: " & txtDMV11.Text & " Printed by: " & LCase(Environ("USERNAME")) & " on " & Date.Now.ToString("MM/dd/yyyy hh:mm") & vbCrLf
        sStr = sStr & "------------------------------------------------------------------------------------------------------------------------------------" & vbCrLf
        sStr = sStr & vbCrLf
        sStr = sStr & vbCrLf
        sStr = sStr & "Badge: " & Trim(txtHR1.Text) & vbCrLf
        sStr = sStr & "DMV Name: " & Replace(Replace(Trim(Replace(fmDMVInfo.Text, "DMV Information", "")), "(", ""), ")", "") & vbCrLf
        sStr = sStr & "Status: " & Trim(txtHR3.Text) & vbCrLf
        sStr = sStr & "Job Title: " & Trim(txtHR4.Text) & vbCrLf
        sStr = sStr & "Location: " & (Trim(txtHR5.Text) & "-" & Trim(txtHR6.Text)) & vbCrLf
        sStr = sStr & vbCrLf
        sStr = sStr & "DL Number: " & vbTab & Trim(txtDMV1.Text) & vbCrLf
        sStr = sStr & "Extension: " & vbTab & Trim(txtDMV2.Text) & vbCrLf
        sStr = sStr & "Medical Card: " & vbTab & Trim(txtDMV3.Text) & vbCrLf
        sStr = sStr & "Expire Date: " & vbTab & Trim(txtDMV4.Text) & vbCrLf
        sStr = sStr & "Birth Date: " & vbTab & Trim(txtDMV5.Text) & vbCrLf
        sStr = sStr & "Class: " & vbTab & Trim(txtDMV8.Text) & vbCrLf
        sStr = sStr & "Weight/Height: " & vbTab & Trim(txtDMV6.Text) & "/" & Trim(txtDMV7.Text) & vbCrLf
        sStr = sStr & vbCrLf
        sStr = sStr & "Commercial: " & vbTab & txtDMV9.Text & vbCrLf
        sStr = sStr & "Point Count: " & vbTab & txtDMV10.Text & vbCrLf
        sStr = sStr & "Record Date: " & vbTab & txtDMV11.Text & vbCrLf
        sStr = sStr & "Gender: " & vbTab & txtDMV12.Text & vbCrLf
        sStr = sStr & "Hair/Eyes: " & vbTab & txtDMV13.Text & "/" & txtDMV14.Text & vbCrLf
        sStr = sStr & vbCrLf
        sStr = sStr & "VIOLATIONS (" & grdViolations.RowCount.ToString & ")" & vbCrLf
        sStr = sStr & "-------------------------------------------------------" & vbCrLf

        'Get Violation data from datagrid
        If grdViolations.RowCount > 0 Then
            For x = 1 To grdViolations.ColumnCount - 1
                TCaption = grdViolations.Columns(x).Name
                TCaption = TCaption.Substring(0, IIf(Len(TCaption) <= 12, Len(TCaption), 12))
                TCaption = TCaption & Space(12 - Len(TCaption))
                Dump = Dump & TCaption & "  "
            Next
            sStr = sStr & Dump & vbCrLf
            'Printer.FontUnderline = False

            For Each row As DataGridViewRow In grdViolations.Rows
                Dump = ""
                For x = 1 To grdViolations.ColumnCount - 1
                    If IsDBNull(row.Cells(x).Value) Then
                        TValue = ""
                    Else
                        TValue = RemoveSpaces(CStr(row.Cells(x).Value).Substring(0, IIf(Len(CStr(row.Cells(x).Value)) <= 10, Len(CStr(row.Cells(x).Value)), 10)))
                        TValue = TValue & Space(12 - Len(TValue))
                    End If
                    Dump = Dump & TValue & "  "
                Next
                sStr = sStr & Dump & vbCrLf
            Next
        Else
            sStr = sStr & "(NONE)" & vbCrLf
        End If

        'Get Suspention data from datagrid
        sStr = sStr & vbCrLf
        sStr = sStr & "SUSPENSIONS " & "(" & grdSuspensions.RowCount & ")" & vbCrLf
        sStr = sStr & "-------------------------------------------------------" & vbCrLf
        Dump = ""
        If grdSuspensions.RowCount > 0 Then
            For x = 1 To grdSuspensions.ColumnCount - 1
                TCaption = grdSuspensions.Columns(x).HeaderText
                TCaption = TCaption.Substring(0, IIf(Len(TCaption) <= 10, Len(TCaption), 10))
                TCaption = TCaption & Space(10 - Len(TCaption))
                Dump = Dump & TCaption & "  "
            Next
            sStr = sStr & Dump & vbCrLf

            For Each row As DataGridViewRow In grdSuspensions.Rows
                Dump = ""
                For x = 1 To grdSuspensions.ColumnCount - 1
                    If IsDBNull(row.Cells(x).Value) Then
                        TValue = ""
                    Else
                        TValue = RemoveSpaces(CStr(row.Cells(x).Value).Substring(0, IIf(Len(CStr(row.Cells(x).Value)) <= 10, Len(CStr(row.Cells(x).Value)), 10)))
                        TValue = TValue & Space(12 - Len(TValue))
                    End If
                    Dump = Dump & TValue & "  "
                Next
                sStr = sStr & Dump & vbCrLf
            Next
        Else
            sStr = sStr & "(NONE)" & vbCrLf
        End If

        'Get Miscellaneous data from datagrid
        sStr = sStr & vbCrLf
        sStr = sStr & "MISCELLANEOUS " & "(" & grdMisc.RowCount & ")" & vbCrLf
        sStr = sStr & "-------------------------------------------------------" & vbCrLf
        If grdMisc.RowCount > 0 Then
            For Each row As DataGridViewRow In grdMisc.Rows
                TValue = RemoveSpaces(CStr(row.Cells(0).Value).ToString)
                sStr = sStr & TValue & vbCrLf
            Next
        Else
            sStr = sStr & "(NONE)" & vbCrLf
        End If

        Printer.TextToPrint = (sStr)
        Printer.Print()

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

        Exit Sub
cmdPrintScreen_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdPrintScreen_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub grdViolations_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdViolations.CellClick

        If e.ColumnIndex = 0 Then
            frmViewViolatioDetails.Show()
            Application.DoEvents()
            frmViewViolatioDetails.txtEmpID.Text = txtHR1.Text.ToString
            frmViewViolatioDetails.txtDocketNo.Text = grdViolations.Rows(e.RowIndex).Cells(6).Value
            frmViewViolatioDetails.LoadViolationGrid()
        End If

    End Sub

    Private Sub grdSearch_SelectionChanged(sender As Object, e As EventArgs) Handles grdSearch.SelectionChanged

        On Error GoTo BailOnError

        grdFlags.DataSource = Nothing

        If grdSearch.Item(0, grdSearch.CurrentRow.Index).Value = "" Then
            MsgBox("No Badge Number selected. " & vbCrLf & "Try again", vbInformation, "Select Record")
            Exit Sub
        End If
        SearchEmployeeId = grdSearch.Item(0, grdSearch.CurrentRow.Index).Value
        LoadMessages(SearchEmployeeId)
        GetHRInfo(SearchEmployeeId)
        GetDMVInfo(SearchEmployeeId)
        GetViolations(SearchEmployeeId)
        GetSuspensions(SearchEmployeeId)
        GetMiscellaneous(SearchEmployeeId)
        GetAKA(SearchEmployeeId)
        GetComments(SearchEmployeeId)

BailOnError:

    End Sub

    Private Sub ClearAll()
        Dim i As Integer

        grdFlags.Rows.Clear()
        For i = 0 To 5
            txtHR(i).Text = ""
        Next
        For i = 0 To 13
            txtDMV(i).Text = ""
        Next
        grdViolations.Rows.Clear()
        grdSuspensions.Rows.Clear()
        grdMisc.Rows.Clear()
        grdAKA.Rows.Clear()
        grdComments.Rows.Clear()

    End Sub

    Private Sub frmMain_Resize(sender As Object, e As EventArgs) Handles Me.Resize

        SizeForm()

    End Sub
End Class
