Option Strict Off
Option Explicit On
Friend Class frmDMVPassword
    Inherits System.Windows.Forms.Form
    Private cmdPasswordButton() As Button

#Region "Windows Form Designer generated code "
    Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        cmdPasswordButton = New Button() {cmdPasswordButton1, cmdPasswordButton2, cmdPasswordButton3}
    End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents text_Renamed As System.Windows.Forms.TextBox
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents cmdPasswordButton3 As System.Windows.Forms.Button
    Public WithEvents cmdPasswordButton2 As System.Windows.Forms.Button
    Public WithEvents cmdPasswordButton1 As System.Windows.Forms.Button
    'Public WithEvents Command1 As ButtonArray
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDMVPassword))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.text_Renamed = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmdPasswordButton3 = New System.Windows.Forms.Button()
        Me.cmdPasswordButton2 = New System.Windows.Forms.Button()
        Me.cmdPasswordButton1 = New System.Windows.Forms.Button()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.text_Renamed)
        Me.Frame1.Controls.Add(Me.Label2)
        Me.Frame1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(4, 8)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(173, 73)
        Me.Frame1.TabIndex = 4
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "DMV System"
        '
        'text_Renamed
        '
        Me.text_Renamed.AcceptsReturn = True
        Me.text_Renamed.BackColor = System.Drawing.SystemColors.Window
        Me.text_Renamed.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.text_Renamed.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.text_Renamed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.text_Renamed.Location = New System.Drawing.Point(66, 29)
        Me.text_Renamed.MaxLength = 0
        Me.text_Renamed.Name = "text_Renamed"
        Me.text_Renamed.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.text_Renamed.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.text_Renamed.Size = New System.Drawing.Size(95, 20)
        Me.text_Renamed.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(8, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(66, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Password"
        '
        'cmdPasswordButton3
        '
        Me.cmdPasswordButton3.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPasswordButton3.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPasswordButton3.Enabled = False
        Me.cmdPasswordButton3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPasswordButton3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPasswordButton3.Location = New System.Drawing.Point(182, 60)
        Me.cmdPasswordButton3.Name = "cmdPasswordButton3"
        Me.cmdPasswordButton3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPasswordButton3.Size = New System.Drawing.Size(73, 21)
        Me.cmdPasswordButton3.TabIndex = 3
        Me.cmdPasswordButton3.Text = "Change"
        Me.cmdPasswordButton3.UseVisualStyleBackColor = False
        '
        'cmdPasswordButton2
        '
        Me.cmdPasswordButton2.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPasswordButton2.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPasswordButton2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdPasswordButton2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPasswordButton2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPasswordButton2.Location = New System.Drawing.Point(182, 37)
        Me.cmdPasswordButton2.Name = "cmdPasswordButton2"
        Me.cmdPasswordButton2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPasswordButton2.Size = New System.Drawing.Size(73, 21)
        Me.cmdPasswordButton2.TabIndex = 2
        Me.cmdPasswordButton2.Text = "Cancel"
        Me.cmdPasswordButton2.UseVisualStyleBackColor = False
        '
        'cmdPasswordButton1
        '
        Me.cmdPasswordButton1.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPasswordButton1.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPasswordButton1.Enabled = False
        Me.cmdPasswordButton1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPasswordButton1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPasswordButton1.Location = New System.Drawing.Point(182, 14)
        Me.cmdPasswordButton1.Name = "cmdPasswordButton1"
        Me.cmdPasswordButton1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPasswordButton1.Size = New System.Drawing.Size(73, 21)
        Me.cmdPasswordButton1.TabIndex = 1
        Me.cmdPasswordButton1.Text = "Login"
        Me.cmdPasswordButton1.UseVisualStyleBackColor = False
        '
        'frmDMVPassword
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(264, 94)
        Me.ControlBox = False
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.cmdPasswordButton3)
        Me.Controls.Add(Me.cmdPasswordButton2)
        Me.Controls.Add(Me.cmdPasswordButton1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmDMVPassword"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login"
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmDMVPassword
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmDMVPassword
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmDMVPassword()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region

    Private OldPassword As String

    '---------------------------------------------------------------------------------------
    ' Procedure : Command1_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Reset users password
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdPasswordButton_Click(index As Integer)

        On Error GoTo Command1_Click_ErrorHandler

        'Set the variable
        ValidUpdate = False

        Select Case Index
            Case Is = 0 'Login
                If Trim(text_Renamed.Text) = "" Then 'Password blank, do not allow
                    MsgBox("Please enter a Password", MsgBoxStyle.Information, "Stop")
                    text_Renamed.Focus()
                    Exit Sub
                End If
                'Validate the password
                If LCase(Trim(text_Renamed.Text)) = LCase(Trim(OldPassword)) Then
                    ValidUpdate = True
                    Me.Close()
                Else
                    MsgBox("Invalid Password.", MsgBoxStyle.Information, "Stop")
                    text_Renamed.Focus()
                End If
            Case Is = 2 'Change
                'Open form to change password
                frmDMVPasswordChange.DefInstance.ShowDialog()
                OldPassword = MDIForm1.DefInstance.GetDMVPassword
                text_Renamed.Text = MDIForm1.DefInstance.GetDMVPassword
                text_Renamed.Focus()
            Case Else 'Cancel
                Me.Close()
        End Select

        Exit Sub
Command1_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: Command1_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : Form_Load
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the form
    '---------------------------------------------------------------------------------------
    '
    Private Sub frmDMVPassword_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        On Error Resume Next

        'Fetch the password
        OldPassword = MDIForm1.DefInstance.GetDMVPassword
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        text_Renamed.Select()
        Me.AcceptButton = Me.cmdPasswordButton1

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : text_Change
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Validate the password
    '---------------------------------------------------------------------------------------
    '
    Private Sub text_Renamed_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles text_Renamed.TextChanged
        On Error Resume Next

        If LTrim(LCase(OldPassword)) = LTrim(LCase(text_Renamed.Text)) Then
            cmdPasswordButton(0).Enabled = True
            cmdPasswordButton(2).Enabled = True
        Else
            cmdPasswordButton(0).Enabled = False
            cmdPasswordButton(2).Enabled = False
        End If

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : text_GotFocus
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Highlight the textbox that has the focus
    '---------------------------------------------------------------------------------------
    '
    Private Sub text_Renamed_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles text_Renamed.Enter
        On Error Resume Next

        text_Renamed.SelectionStart = 0
        text_Renamed.SelectionLength = Len(text_Renamed.Text)

    End Sub

    Private Sub cmdPasswordButton1_Click(sender As Object, e As EventArgs) Handles cmdPasswordButton1.Click

        cmdPasswordButton_Click(0)

    End Sub

    Private Sub cmdPasswordButton2_Click(sender As Object, e As EventArgs) Handles cmdPasswordButton2.Click

        cmdPasswordButton_Click(1)
    End Sub

    Private Sub cmdPasswordButton3_Click(sender As Object, e As EventArgs) Handles cmdPasswordButton3.Click

        cmdPasswordButton_Click(2)

    End Sub
End Class