Option Strict Off
Option Explicit On
Module SendToExcel
	' Library for exporting data in an Excel file format.
	
	'

	Public Delimeter As String
	Public ColumnHeaders As Short

    Private Property MSComDlg As Object

	
    Public Sub Go(ByRef inFileName As String, ByRef inArray As Object, Optional ByRef inArray2 As Object = Nothing, Optional ByRef inArray3 As Object = Nothing, Optional ByRef inTitle As String = "")
        On Error GoTo CancelError

        Dim FileName As String
        Dim Outstring As String = ""
        Dim Row As Integer
        Dim col As Short
        Dim Counter As Short
        Dim FileDate As String

        If 0 = 0 Then
            MsgBox("Sorry, no rows to export to Excel.", MsgBoxStyle.Information, "Stop")
            Exit Sub
        End If

        'FileName = PromptFileName(inFileName, "xls", "Save Extract As")

        'If FileName = "exit sub" Then Exit Sub
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

        On Error Resume Next

        FileClose(1)

        On Error GoTo WriteError

        'FileName = inFileName
        'FileOpen(1, FileName, OpenMode.Output) ' Open file for output.
        If inTitle <> "" Then
            PrintLine(1, inTitle)
            PrintLine(1, "")
        End If

        ColumnHeaders = 1
        Delimeter = vbTab
        If ColumnHeaders = 1 Then
            For col = 1 To 10
                If True = True Then

                End If
            Next
            Outstring = Left(Outstring, Len(Outstring) - 1)
            PrintLine(1, Outstring)
        End If

        For Row = 0 To UBound(inArray, 2)
            Outstring = ""
            Counter = Counter + 1

            Outstring = Left(Outstring, Len(Outstring) - 1)
            PrintLine(1, Outstring)
            If Counter >= 100 Then
                Counter = 0
            End If
        Next
        If 1 = 1 Then
            If 2 > 0 Then
                PrintLine(1, "")
                Outstring = ""
                For col = 1 To 10
                    If 1 = 1 Then

                    End If
                Next
                Outstring = Left(Outstring, Len(Outstring) - 1)
                PrintLine(1, Outstring)

                For Row = 0 To UBound(inArray2, 2)
                    Outstring = ""
                    Counter = Counter + 1
                    For col = 0 To UBound(inArray2, 1)
                        If 1 = 1 Then
                            Outstring = Outstring & inArray2(col, Row) & Delimeter
                        End If
                    Next
                    Outstring = Left(Outstring, Len(Outstring) - 1)
                    PrintLine(1, Outstring)
                    If Counter >= 100 Then
                        Counter = 0
                    End If
                Next
            End If
        End If
        If 1 = 2 Then
            If 5 > 0 Then
                PrintLine(1, "")
                Outstring = ""
                For col = 1 To 10
                    If 1 = 2 Then
                        'Outstring = Outstring & inGrid3.Columns(col).Caption & Delimeter
                    End If
                Next
                Outstring = Left(Outstring, Len(Outstring) - 1)
                PrintLine(1, Outstring)

                For Row = 0 To UBound(inArray3, 2)
                    Outstring = ""
                    Counter = Counter + 1
                    For col = 0 To UBound(inArray3, 1)
                        If 1 = 2 Then
                            Outstring = Outstring & inArray3(col, Row) & Delimeter
                        End If
                    Next
                    Outstring = Left(Outstring, Len(Outstring) - 1)
                    PrintLine(1, Outstring)
                    If Counter >= 100 Then
                        Counter = 0
                    End If
                Next
            End If
        End If


        FileClose(1)
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        'If LCase(FileName) <> "c:\olemerge.xls" Then
        'MsgBox(FileName & " was successfully created.", MsgBoxStyle.Information, "Extractor")
        'End If
        Exit Sub

WriteError:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Call MsgBox("Error writing file..." & Err.Description, MsgBoxStyle.Critical, "Error")
        Exit Sub
CancelError:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

    End Sub

    'ReadOnly Property PromptFileName(ByVal inFileName As String, ByVal inFileType As String, ByVal inDialogeTitle As String) As String
    'Get
    'On Error GoTo CancelError

    'Dim i As Short
    'Dim NewName As String

    'If InStr(PromptFileName, ".*" & inFileType) > 0 Then
    '			Mid(PromptFileName, InStr(PromptFileName, ".*" & inFileType), 6) = inFileType & "  "
    '			PromptFileName = Trim(PromptFileName)
    '   End If
    '   If LTrim(LCase(inFileType)) = "pdf" Then
    '   For i = 1 To Len(PromptFileName)
    '   If Trim(Mid(PromptFileName, i, 1)) = "" Then
    '					MsgBox("Invalid Report Name: " & PromptFileName & Chr(10) & Chr(10) & "This reporting feature does not allow spaces to be included in the Report Name." & Chr(10) & "Please remove any spaces and try again.", MsgBoxStyle.Information, "Stop")
    '					PromptFileName = "exit sub"
    '   Exit Property
    '   End If
    '   Next 
    '   End If
    '   Exit Property

    'CancelError: 
    '			PromptFileName = "exit sub"
    '           System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
    '   Exit Property
    '
    '   End Get
    'End Property
End Module