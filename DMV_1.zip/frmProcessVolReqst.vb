Option Strict Off
Option Explicit On
'Imports VB = Microsoft.VisualBasic
Friend Class frmProcessVolReqst
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents cmdNoDMVRecord As System.Windows.Forms.Button
	Public WithEvents cmdListHREmployees As System.Windows.Forms.Button
	Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents cmdRemoveAll As System.Windows.Forms.Button
	Public WithEvents cmdSelectAll As System.Windows.Forms.Button
	Public WithEvents cmdRemoveAdd As System.Windows.Forms.Button
	Public WithEvents cmdAddEmployee As System.Windows.Forms.Button
	Public WithEvents lstAddEmployee As System.Windows.Forms.ListBox
	Public WithEvents lstEmployeeList As System.Windows.Forms.ListBox
	Public WithEvents cmdPUTEmpList As System.Windows.Forms.Button
	Public WithEvents cmdCreateExportEmpList As System.Windows.Forms.Button
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProcessVolReqst))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.cmdNoDMVRecord = New System.Windows.Forms.Button()
        Me.cmdListHREmployees = New System.Windows.Forms.Button()
        Me.cmdRemoveAll = New System.Windows.Forms.Button()
        Me.cmdSelectAll = New System.Windows.Forms.Button()
        Me.cmdRemoveAdd = New System.Windows.Forms.Button()
        Me.cmdAddEmployee = New System.Windows.Forms.Button()
        Me.lstAddEmployee = New System.Windows.Forms.ListBox()
        Me.lstEmployeeList = New System.Windows.Forms.ListBox()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmdPUTEmpList = New System.Windows.Forms.Button()
        Me.cmdCreateExportEmpList = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Frame2.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.Controls.Add(Me.cmdNoDMVRecord)
        Me.Frame2.Controls.Add(Me.cmdListHREmployees)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(16, 358)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(176, 86)
        Me.Frame2.TabIndex = 12
        Me.Frame2.TabStop = False
        Me.Frame2.Text = "View Records"
        '
        'cmdNoDMVRecord
        '
        Me.cmdNoDMVRecord.BackColor = System.Drawing.SystemColors.Control
        Me.cmdNoDMVRecord.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdNoDMVRecord.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdNoDMVRecord.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdNoDMVRecord.Location = New System.Drawing.Point(19, 47)
        Me.cmdNoDMVRecord.Name = "cmdNoDMVRecord"
        Me.cmdNoDMVRecord.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdNoDMVRecord.Size = New System.Drawing.Size(140, 26)
        Me.cmdNoDMVRecord.TabIndex = 14
        Me.cmdNoDMVRecord.Text = "Missing DMV Records"
        Me.cmdNoDMVRecord.UseVisualStyleBackColor = False
        '
        'cmdListHREmployees
        '
        Me.cmdListHREmployees.BackColor = System.Drawing.SystemColors.Control
        Me.cmdListHREmployees.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdListHREmployees.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdListHREmployees.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdListHREmployees.Location = New System.Drawing.Point(19, 18)
        Me.cmdListHREmployees.Name = "cmdListHREmployees"
        Me.cmdListHREmployees.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdListHREmployees.Size = New System.Drawing.Size(140, 26)
        Me.cmdListHREmployees.TabIndex = 13
        Me.cmdListHREmployees.Text = "List HR Employees"
        Me.cmdListHREmployees.UseVisualStyleBackColor = False
        '
        'cmdRemoveAll
        '
        Me.cmdRemoveAll.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemoveAll.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRemoveAll.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRemoveAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRemoveAll.Location = New System.Drawing.Point(284, 208)
        Me.cmdRemoveAll.Name = "cmdRemoveAll"
        Me.cmdRemoveAll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRemoveAll.Size = New System.Drawing.Size(49, 25)
        Me.cmdRemoveAll.TabIndex = 11
        Me.cmdRemoveAll.Text = "<< All"
        Me.cmdRemoveAll.UseVisualStyleBackColor = False
        '
        'cmdSelectAll
        '
        Me.cmdSelectAll.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSelectAll.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSelectAll.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSelectAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSelectAll.Location = New System.Drawing.Point(284, 184)
        Me.cmdSelectAll.Name = "cmdSelectAll"
        Me.cmdSelectAll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSelectAll.Size = New System.Drawing.Size(49, 25)
        Me.cmdSelectAll.TabIndex = 10
        Me.cmdSelectAll.Text = ">> All"
        Me.cmdSelectAll.UseVisualStyleBackColor = False
        '
        'cmdRemoveAdd
        '
        Me.cmdRemoveAdd.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemoveAdd.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRemoveAdd.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRemoveAdd.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRemoveAdd.Location = New System.Drawing.Point(288, 128)
        Me.cmdRemoveAdd.Name = "cmdRemoveAdd"
        Me.cmdRemoveAdd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRemoveAdd.Size = New System.Drawing.Size(41, 25)
        Me.cmdRemoveAdd.TabIndex = 9
        Me.cmdRemoveAdd.Text = "<<"
        Me.cmdRemoveAdd.UseVisualStyleBackColor = False
        '
        'cmdAddEmployee
        '
        Me.cmdAddEmployee.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddEmployee.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddEmployee.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddEmployee.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddEmployee.Location = New System.Drawing.Point(288, 104)
        Me.cmdAddEmployee.Name = "cmdAddEmployee"
        Me.cmdAddEmployee.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAddEmployee.Size = New System.Drawing.Size(41, 25)
        Me.cmdAddEmployee.TabIndex = 8
        Me.cmdAddEmployee.Text = ">>"
        Me.cmdAddEmployee.UseVisualStyleBackColor = False
        '
        'lstAddEmployee
        '
        Me.lstAddEmployee.BackColor = System.Drawing.SystemColors.Window
        Me.lstAddEmployee.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstAddEmployee.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstAddEmployee.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstAddEmployee.ItemHeight = 14
        Me.lstAddEmployee.Location = New System.Drawing.Point(344, 48)
        Me.lstAddEmployee.Name = "lstAddEmployee"
        Me.lstAddEmployee.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstAddEmployee.Size = New System.Drawing.Size(250, 298)
        Me.lstAddEmployee.TabIndex = 5
        '
        'lstEmployeeList
        '
        Me.lstEmployeeList.BackColor = System.Drawing.SystemColors.Window
        Me.lstEmployeeList.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstEmployeeList.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstEmployeeList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstEmployeeList.ItemHeight = 14
        Me.lstEmployeeList.Location = New System.Drawing.Point(16, 48)
        Me.lstEmployeeList.Name = "lstEmployeeList"
        Me.lstEmployeeList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstEmployeeList.Size = New System.Drawing.Size(250, 298)
        Me.lstEmployeeList.TabIndex = 4
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.cmdPUTEmpList)
        Me.Frame1.Controls.Add(Me.cmdCreateExportEmpList)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(344, 358)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(176, 86)
        Me.Frame1.TabIndex = 1
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Process Records"
        '
        'cmdPUTEmpList
        '
        Me.cmdPUTEmpList.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPUTEmpList.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPUTEmpList.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPUTEmpList.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPUTEmpList.Location = New System.Drawing.Point(18, 48)
        Me.cmdPUTEmpList.Name = "cmdPUTEmpList"
        Me.cmdPUTEmpList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPUTEmpList.Size = New System.Drawing.Size(140, 26)
        Me.cmdPUTEmpList.TabIndex = 3
        Me.cmdPUTEmpList.Text = "Put Employee List"
        Me.cmdPUTEmpList.UseVisualStyleBackColor = False
        '
        'cmdCreateExportEmpList
        '
        Me.cmdCreateExportEmpList.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCreateExportEmpList.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCreateExportEmpList.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCreateExportEmpList.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCreateExportEmpList.Location = New System.Drawing.Point(18, 19)
        Me.cmdCreateExportEmpList.Name = "cmdCreateExportEmpList"
        Me.cmdCreateExportEmpList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCreateExportEmpList.Size = New System.Drawing.Size(140, 26)
        Me.cmdCreateExportEmpList.TabIndex = 2
        Me.cmdCreateExportEmpList.Text = "Create Employee List"
        Me.cmdCreateExportEmpList.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(13, 457)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(63, 24)
        Me.cmdClose.TabIndex = 0
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(344, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(250, 17)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Export List"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(16, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(250, 17)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Employee List"
        '
        'frmProcessVolReqst
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(615, 497)
        Me.ControlBox = False
        Me.Controls.Add(Me.Frame2)
        Me.Controls.Add(Me.cmdRemoveAll)
        Me.Controls.Add(Me.cmdSelectAll)
        Me.Controls.Add(Me.cmdRemoveAdd)
        Me.Controls.Add(Me.cmdAddEmployee)
        Me.Controls.Add(Me.lstAddEmployee)
        Me.Controls.Add(Me.lstEmployeeList)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(4, 23)
        Me.Name = "frmProcessVolReqst"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Process Volume Reqst"
        Me.Frame2.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As frmProcessVolReqst
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmProcessVolReqst
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmProcessVolReqst()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	'---------------------------------------------------------------------------------------
	' Procedure : cmdAddEmployee_Click
	' DateTime  : 03/21/2007
	' Author    : aalvidrez
	' Purpose   : Add an employee to the "Add" list
	'---------------------------------------------------------------------------------------
	'
	Private Sub cmdAddEmployee_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAddEmployee.Click
		On Error GoTo cmdAddEmployee_Click_ErrorHandler
		
		'Make sure we have a current record
		If lstEmployeeList.Text <> "" Then
			lstAddEmployee.Items.Add(lstEmployeeList.Text)
		End If
		
		Exit Sub
cmdAddEmployee_Click_ErrorHandler: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: cmdAddEmployee_Click " & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click

        Me.Close()

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdCreateExportEmpList_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Export the Employee Pull Notice file
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdCreateExportEmpList_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCreateExportEmpList.Click
        Dim i As Object
        On Error GoTo cmdCreateExportEmpList_Click_ErrorHandler

        Dim sStr As String
        Dim iFileNo As Short

        iFileNo = FreeFile()
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

        'Create and open the file
        FileOpen(iFileNo, FILE_PATH & "\DMV_Export_Emp_List.dat", OpenMode.Output)

        'Write to the file (row by row from the list box)
        If lstAddEmployee.Items.Count >= 1 Then
            For i = 0 To lstAddEmployee.Items.Count - 1
                PrintLine(iFileNo, CStr(lstAddEmployee.Items(i)).Substring(Len(CStr(lstAddEmployee.Items(i))) - 8, 8) & CStr(lstAddEmployee.Items(i)).Substring(0, 3) & "67198                                                                ")
            Next i
        End If

        'Close the file
        FileClose(iFileNo)

        MsgBox("File Transfer Complete", MsgBoxStyle.Information, "Export File")

        System.Windows.Forms.Cursor.Current = Cursors.Default

        Exit Sub

cmdCreateExportEmpList_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdCreateExportEmpList_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub cmdGETEmpList_Click()
        On Error GoTo cmdGETEmpList_Click_Error

        Dim retval As String
        Dim iFileNo As Short

        MsgBox("Make sure you are connected via VPN to the DMV.", MsgBoxStyle.Information, "DMV System")

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        'Create and open the file
        iFileNo = FreeFile
        FileOpen(iFileNo, FILE_PATH & "\DMV_GET_EMP_LIST_VOL.ftp", OpenMode.Output)

        'Populate the file
        retval = InputBox("Enter the FTP Password", "Password...")
        If retval <> "" Then
            PrintLine(iFileNo, "open mvs.teale.ca.gov")
            PrintLine(iFileNo, "user mvxocta")
            PrintLine(iFileNo, retval)
            PrintLine(iFileNo, "ascii")
            PrintLine(iFileNo, "get 'mv.volreqst.r67198.out' " & FILE_PATH & "\DMVImport_Vol.dat")
            PrintLine(iFileNo, "close")
            PrintLine(iFileNo, "quit")
        End If

        FileClose(iFileNo)

        retval = CStr(Shell(FILE_PATH & "\DMV_GET_EMP_LIST_VOL.bat", AppWinStyle.NormalFocus))

cmdGETEmpList_Click_Exit:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdGETEmpList_Click_Error:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdGETEmpList_Click" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdGETEmpList_Click_Exit

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdListHREmployees_Click
    ' DateTime  : 09/05/2007
    ' Author    : aalvidrez
    ' Purpose   : Populate employee list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdListHREmployees_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdListHREmployees.Click

        'Clear the list
        lstEmployeeList.Items.Clear()

        sSQL = "SELECT last_name  + ', ' +  first_name  + ' - ' +  dbo.DecryptData(drivers_license) AS emp_name" & " From dbo.HR_C_EMPLOYEES" & " WHERE (employment_status LIKE 'A%' OR employment_status LIKE 'L%')" & " AND employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout)" & " AND LEN(dbo.DecryptData(dbo.HR_C_EMPLOYEES.Drivers_License)) = 8 " & " ORDER BY 1"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        'Populate the list
        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                lstEmployeeList.Items.Add(rs.Fields("emp_name").Value)
                rs.MoveNext()
            Loop
        End If

        rs.Close()

    End Sub

    Private Sub cmdNoDMVRecord_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdNoDMVRecord.Click
        'Clear the list
        lstEmployeeList.Items.Clear()

        sSQL = "SELECT last_name  + ', ' +  first_name  + ' - ' +  ISNULL(dbo.DecryptData(drivers_license), '') AS emp_name" & " From dbo.HR_C_EMPLOYEES" & " WHERE (employment_status LIKE 'A%' OR employment_status LIKE 'L%')" & " AND employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_employees)" & " AND employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout)" & " ORDER BY 1"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        'Populate the list
        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                lstEmployeeList.Items.Add(rs.Fields("emp_name").Value)
                rs.MoveNext()
            Loop
        End If

        rs.Close()

    End Sub

    Private Sub cmdPutEmpList_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPutEmpList.Click
        On Error GoTo cmdPutEmpList_Click_Error

        Dim retval As String
        Dim iFileNo As Short

        MsgBox("Make sure you are connected via VPN to the DMV.", MsgBoxStyle.Information, "DMV System")

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        'Create and open the file
        iFileNo = FreeFile
        FileOpen(iFileNo, FILE_PATH & "\DMV_PUT_EMP_LIST_VOL.ftp", OpenMode.Output)

        'Populate the file
        retval = InputBox("Enter the FTP Password", "Password...")
        If retval <> "" Then
            PrintLine(iFileNo, "open mvs.teale.ca.gov")
            PrintLine(iFileNo, "user mvxocta")
            PrintLine(iFileNo, retval)
            PrintLine(iFileNo, "ascii")
            PrintLine(iFileNo, "put " & FILE_PATH & "\DMV_Export_Emp_List.dat 'mv.volreqst.r67198.in'")
            PrintLine(iFileNo, "close")
            PrintLine(iFileNo, "quit")
        End If

        FileClose(iFileNo)

        retval = CStr(Shell(FILE_PATH & "\DMV_PUT_EMP_LIST_VOL.bat", AppWinStyle.NormalFocus))

cmdPutEmpList_Click_Exit:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdPutEmpList_Click_Error:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdPutEmpList_Click" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdPutEmpList_Click_Exit

    End Sub


    '---------------------------------------------------------------------------------------
    ' Procedure : cmdRemoveAdd_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Remove an employee from the "Add" list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdRemoveAdd_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRemoveAdd.Click
        On Error GoTo cmdRemoveAdd_Click_ErrorHandler

        'Make sure we have a current record
        If lstAddEmployee.Text <> "" Then
            lstAddEmployee.Items.RemoveAt((lstAddEmployee.SelectedIndex))
        End If

        Exit Sub
cmdRemoveAdd_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdRemoveAdd_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdRemoveAll_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Remove all employees from the "Add" list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdRemoveAll_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRemoveAll.Click
        Dim i As Object
        On Error GoTo cmdRemoveAll_Click_ErrorHandler

        'Make sure we have a current record
        For i = 0 To lstAddEmployee.Items.Count - 1
            lstAddEmployee.Items.RemoveAt(0)
        Next i

        Exit Sub
cmdRemoveAll_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdRemoveAll_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub


    '---------------------------------------------------------------------------------------
    ' Procedure : cmdSelectAll_Click
    ' DateTime  : 9/5/2007
    ' Author    : aalvidrez
    ' Purpose   : Add all employees to the "Add" list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdSelectAll_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSelectAll.Click
        Dim i As Object
        On Error GoTo cmdSelectAll_Click_ErrorHandler

        'Add all items
        For i = 0 To lstEmployeeList.Items.Count - 1
            lstAddEmployee.Items.Add(CStr(lstEmployeeList.Items(i)))
        Next i

        Exit Sub
cmdSelectAll_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdSelectAll_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
	
	
	Private Sub lstAddEmployee_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstAddEmployee.DoubleClick
		
		Call cmdRemoveAdd_Click(cmdRemoveAdd, New System.EventArgs())
		
	End Sub
	
	Private Sub lstEmployeeList_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstEmployeeList.DoubleClick
		
		Call cmdAddEmployee_Click(cmdAddEmployee, New System.EventArgs())
		
	End Sub
End Class