Option Strict Off
Option Explicit On
Imports Microsoft.VisualBasic.FileIO

'Imports VB = Microsoft.VisualBasic
Friend Class frmProcessDailyImport
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents cmdImportData As System.Windows.Forms.Button
	Public WithEvents cmdGETEmpList As System.Windows.Forms.Button
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents cmdTransferFile As System.Windows.Forms.Button
	Public WithEvents cmdMungeData As System.Windows.Forms.Button
	Public WithEvents cmdSetFlags As System.Windows.Forms.Button
	Public WithEvents _Image2_3 As System.Windows.Forms.PictureBox
	Public WithEvents _Image2_2 As System.Windows.Forms.PictureBox
	Public WithEvents _Image2_1 As System.Windows.Forms.PictureBox
	Public WithEvents _Image1_3 As System.Windows.Forms.PictureBox
	Public WithEvents _Image1_2 As System.Windows.Forms.PictureBox
	Public WithEvents _Image1_1 As System.Windows.Forms.PictureBox
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents _Line1_0 As System.Windows.Forms.Label
    'Public WithEvents Image1 As Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray
    'Public WithEvents Image2 As Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray
    'Public WithEvents Line1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProcessDailyImport))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmdImportData = New System.Windows.Forms.Button()
        Me.cmdGETEmpList = New System.Windows.Forms.Button()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.cmdTransferFile = New System.Windows.Forms.Button()
        Me.cmdMungeData = New System.Windows.Forms.Button()
        Me.cmdSetFlags = New System.Windows.Forms.Button()
        Me._Image2_3 = New System.Windows.Forms.PictureBox()
        Me._Image2_2 = New System.Windows.Forms.PictureBox()
        Me._Image2_1 = New System.Windows.Forms.PictureBox()
        Me._Image1_3 = New System.Windows.Forms.PictureBox()
        Me._Image1_2 = New System.Windows.Forms.PictureBox()
        Me._Image1_1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me._Line1_0 = New System.Windows.Forms.Label()
        Me.Frame1.SuspendLayout()
        Me.Frame2.SuspendLayout()
        CType(Me._Image2_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Image2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Image2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Image1_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Image1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Image1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.cmdImportData)
        Me.Frame1.Controls.Add(Me.cmdGETEmpList)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(11, 153)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(174, 93)
        Me.Frame1.TabIndex = 8
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Utilities"
        '
        'cmdImportData
        '
        Me.cmdImportData.BackColor = System.Drawing.SystemColors.Control
        Me.cmdImportData.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdImportData.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdImportData.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdImportData.Location = New System.Drawing.Point(31, 55)
        Me.cmdImportData.Name = "cmdImportData"
        Me.cmdImportData.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdImportData.Size = New System.Drawing.Size(107, 24)
        Me.cmdImportData.TabIndex = 10
        Me.cmdImportData.Text = "Import Data"
        Me.cmdImportData.UseVisualStyleBackColor = False
        '
        'cmdGETEmpList
        '
        Me.cmdGETEmpList.BackColor = System.Drawing.SystemColors.Control
        Me.cmdGETEmpList.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdGETEmpList.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdGETEmpList.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdGETEmpList.Location = New System.Drawing.Point(31, 21)
        Me.cmdGETEmpList.Name = "cmdGETEmpList"
        Me.cmdGETEmpList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdGETEmpList.Size = New System.Drawing.Size(107, 24)
        Me.cmdGETEmpList.TabIndex = 9
        Me.cmdGETEmpList.Text = "Get File Date"
        Me.cmdGETEmpList.UseVisualStyleBackColor = False
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.Controls.Add(Me.cmdTransferFile)
        Me.Frame2.Controls.Add(Me.cmdMungeData)
        Me.Frame2.Controls.Add(Me.cmdSetFlags)
        Me.Frame2.Controls.Add(Me._Image2_3)
        Me.Frame2.Controls.Add(Me._Image2_2)
        Me.Frame2.Controls.Add(Me._Image2_1)
        Me.Frame2.Controls.Add(Me._Image1_3)
        Me.Frame2.Controls.Add(Me._Image1_2)
        Me.Frame2.Controls.Add(Me._Image1_1)
        Me.Frame2.Controls.Add(Me.Label1)
        Me.Frame2.Controls.Add(Me.Label4)
        Me.Frame2.Controls.Add(Me.Label3)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(7, 14)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(176, 125)
        Me.Frame2.TabIndex = 4
        Me.Frame2.TabStop = False
        Me.Frame2.Text = "Process Data"
        '
        'cmdTransferFile
        '
        Me.cmdTransferFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdTransferFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdTransferFile.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTransferFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdTransferFile.Location = New System.Drawing.Point(33, 19)
        Me.cmdTransferFile.Name = "cmdTransferFile"
        Me.cmdTransferFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdTransferFile.Size = New System.Drawing.Size(107, 24)
        Me.cmdTransferFile.TabIndex = 0
        Me.cmdTransferFile.Text = "Transfer File to DB"
        Me.cmdTransferFile.UseVisualStyleBackColor = False
        '
        'cmdMungeData
        '
        Me.cmdMungeData.BackColor = System.Drawing.SystemColors.Control
        Me.cmdMungeData.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdMungeData.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMungeData.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdMungeData.Location = New System.Drawing.Point(33, 53)
        Me.cmdMungeData.Name = "cmdMungeData"
        Me.cmdMungeData.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdMungeData.Size = New System.Drawing.Size(107, 24)
        Me.cmdMungeData.TabIndex = 1
        Me.cmdMungeData.Text = "Munge Data"
        Me.cmdMungeData.UseVisualStyleBackColor = False
        '
        'cmdSetFlags
        '
        Me.cmdSetFlags.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSetFlags.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSetFlags.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSetFlags.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSetFlags.Location = New System.Drawing.Point(33, 88)
        Me.cmdSetFlags.Name = "cmdSetFlags"
        Me.cmdSetFlags.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSetFlags.Size = New System.Drawing.Size(107, 24)
        Me.cmdSetFlags.TabIndex = 2
        Me.cmdSetFlags.Text = "Set Flags"
        Me.cmdSetFlags.UseVisualStyleBackColor = False
        '
        '_Image2_3
        '
        Me._Image2_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image2_3.Image = CType(resources.GetObject("_Image2_3.Image"), System.Drawing.Image)
        Me._Image2_3.Location = New System.Drawing.Point(147, 89)
        Me._Image2_3.Name = "_Image2_3"
        Me._Image2_3.Size = New System.Drawing.Size(20, 20)
        Me._Image2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image2_3.TabIndex = 3
        Me._Image2_3.TabStop = False
        Me._Image2_3.Visible = False
        '
        '_Image2_2
        '
        Me._Image2_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image2_2.Image = CType(resources.GetObject("_Image2_2.Image"), System.Drawing.Image)
        Me._Image2_2.Location = New System.Drawing.Point(147, 55)
        Me._Image2_2.Name = "_Image2_2"
        Me._Image2_2.Size = New System.Drawing.Size(20, 20)
        Me._Image2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image2_2.TabIndex = 4
        Me._Image2_2.TabStop = False
        Me._Image2_2.Visible = False
        '
        '_Image2_1
        '
        Me._Image2_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image2_1.Image = CType(resources.GetObject("_Image2_1.Image"), System.Drawing.Image)
        Me._Image2_1.Location = New System.Drawing.Point(147, 20)
        Me._Image2_1.Name = "_Image2_1"
        Me._Image2_1.Size = New System.Drawing.Size(20, 20)
        Me._Image2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image2_1.TabIndex = 5
        Me._Image2_1.TabStop = False
        Me._Image2_1.Visible = False
        '
        '_Image1_3
        '
        Me._Image1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image1_3.Image = CType(resources.GetObject("_Image1_3.Image"), System.Drawing.Image)
        Me._Image1_3.Location = New System.Drawing.Point(146, 89)
        Me._Image1_3.Name = "_Image1_3"
        Me._Image1_3.Size = New System.Drawing.Size(22, 21)
        Me._Image1_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image1_3.TabIndex = 6
        Me._Image1_3.TabStop = False
        Me._Image1_3.Visible = False
        '
        '_Image1_2
        '
        Me._Image1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image1_2.Image = CType(resources.GetObject("_Image1_2.Image"), System.Drawing.Image)
        Me._Image1_2.Location = New System.Drawing.Point(146, 55)
        Me._Image1_2.Name = "_Image1_2"
        Me._Image1_2.Size = New System.Drawing.Size(22, 21)
        Me._Image1_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image1_2.TabIndex = 7
        Me._Image1_2.TabStop = False
        Me._Image1_2.Visible = False
        '
        '_Image1_1
        '
        Me._Image1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image1_1.Image = CType(resources.GetObject("_Image1_1.Image"), System.Drawing.Image)
        Me._Image1_1.Location = New System.Drawing.Point(146, 20)
        Me._Image1_1.Name = "_Image1_1"
        Me._Image1_1.Size = New System.Drawing.Size(22, 21)
        Me._Image1_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image1_1.TabIndex = 8
        Me._Image1_1.TabStop = False
        Me._Image1_1.Visible = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(12, 89)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(18, 26)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "3)"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(12, 55)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(18, 26)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "2)"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(13, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(18, 26)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "1)"
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(42, 261)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(105, 22)
        Me.cmdClose.TabIndex = 3
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        '_Line1_0
        '
        Me._Line1_0.BackColor = System.Drawing.SystemColors.WindowText
        Me._Line1_0.Location = New System.Drawing.Point(2, 257)
        Me._Line1_0.Name = "_Line1_0"
        Me._Line1_0.Size = New System.Drawing.Size(197, 1)
        Me._Line1_0.TabIndex = 9
        '
        'frmProcessDailyImport
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(195, 291)
        Me.ControlBox = False
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Frame2)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me._Line1_0)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(4, 23)
        Me.Name = "frmProcessDailyImport"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Daily Import"
        Me.Frame1.ResumeLayout(False)
        Me.Frame2.ResumeLayout(False)
        CType(Me._Image2_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Image2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Image2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Image1_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Image1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Image1_1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmProcessDailyImport
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmProcessDailyImport
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmProcessDailyImport()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		
		Me.Close()
		
	End Sub
	
	Private Sub cmdGETEmpList_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdGETEmpList.Click
		On Error GoTo cmdGETEmpList_Click_Error
		
		MsgBox("File Date is: " & FileDateTime(FILE_PATH & "\DMV.dat"), MsgBoxStyle.Information)
		
cmdGETEmpList_Click_Exit:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub
		
cmdGETEmpList_Click_Error:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdGETEmpList_Click" & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdGETEmpList_Click_Exit

    End Sub

    Private Sub cmdImportData_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdImportData.Click
        Dim sFileToGet As Object
        Dim sResponse As String
        Dim sFTP_Tool_Path As Object
        Dim sFilePath As Object
        Dim sFTP_Path As Object
        Dim sFTPPassword As Object
        Dim sFormat As String = "MM/dd/yyyy"
        Dim retval As String
        Dim iFileNo As Short
        Dim bIsSaturday As Boolean
        Dim dInputDate As Date
        On Error GoTo cmdImportData_Click_Error

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

        'Get the DMV FTP password
        sFTPPassword = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='FTPPassword'")
        sFTP_Path = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='FTP_Path'")
        sFilePath = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='DMVFilePath'")
        sFTP_Tool_Path = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='SecureFXPath'")
        sResponse = InputBox("What date would you like to import? (mm/dd/yyyy)", "Date to import", Date.Today.ToString(sFormat))

        If IsDate(sResponse) Then
            dInputDate = CDate(sResponse)
            dInputDate = dInputDate.ToString(sFormat)
            'Check to see if this is a Saturday. Saturdays have a different file format
            If DatePart(Microsoft.VisualBasic.DateInterval.Weekday, dInputDate) = FirstDayOfWeek.Saturday Then
                bIsSaturday = True
            Else
                bIsSaturday = False
            End If
        Else
            MsgBox("Invalid date. Please try again.", MsgBoxStyle.Critical, "Try again")
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Exit Sub
        End If

        sFileToGet = (dInputDate).Year.ToString("0000") & (dInputDate).Month.ToString("00") & (dInputDate).Day.ToString("00") & ".TXT"

        If bIsSaturday Then
            'sFileToGet = "DLINQ_OUTA198" & Year(dInputDate).ToString("0000") & Month(dInputDate).ToString("00") & VB.Day(dInputDate).ToString("00") & ".TXT"
            sFileToGet = "DLINQ_OUTA198" & sFileToGet
        Else
            'sFileToGet = "DLINQ_OUT198" & Year(dInputDate).ToString("0000") & Month(dInputDate).ToString("00") & VB.Day(dInputDate).ToString("00") & ".TXT"
            sFileToGet = "DLINQ_OUT198" & sFileToGet
        End If

        'Pause to make sure file transfer has been completed
        'Call ShellAndWait(sCoreFTPPath & "CoreFTP.exe -s -O -site DMV -d /dmv-ddt-router/FromDMV/" & sFileToGet & " -p " & sFilePath & " -FN DMVImport_Daily.dat", vbHide)
        'Call ShellAndWait(sCoreFTPPath & " /command ""open sftp://mvxocta:" & sSFTPPassword & "@SFT.DMV.CA.GOV/dmv-ddt-router/FromDMV/"" ""get " & sFileToGet & " " & sFilePath & """ ""exit""", vbHide)

        '*****New Ipswitch utility *******************
        'Create and open the file
        iFileNo = FreeFile
        FileOpen(iFileNo, FILE_PATH & "\GET_DMV_Import.bat", OpenMode.Output)

        'Populate the file
        PrintLine(iFileNo, "C:")
        PrintLine(iFileNo, "CD..")
        PrintLine(iFileNo, "CD..")
        PrintLine(iFileNo, sFTP_Tool_Path)

        'Print #iFileNo, "winscp.exe /console /log=""\\octant03\apps$\DMV\Production\DMV_FTP_Import.log"" /Command ""open ftp://mvxocta:" & sFTPPassword & "@sft.dmv.ca.gov:2121 -explicitssl""  ""cd dmv-ddt-router/FromDMV"" ""get " & sFileToGet & " " & sFilePath & """ ""Exit"""""
        'PrintLine(iFileNo, "winscp.exe /console /log=""\\octant03\apps$\DMV\Production\DMV_FTP_Import.log"" /Command ""open ftp://mvxocta:" & sFTPPassword & "@sft.dmv.ca.gov:2121 -explicitssl""  ""cd DMVData/FromDMV"" ""get " & sFileToGet & " " & sFilePath & """ ""Exit""""")
        'PrintLine(iFileNo, "SFXCL /Password " & sFTPPassword & " /log \\octant03\apps$\DMV\Production\DMV_FTP_Import.log /s DMV /DMVData/FromDMV/" & sFileToGet & " " & sFilePath & "")
        PrintLine(iFileNo, "SFXCL /s DMV /DMVData/FromDMV/" & sFileToGet & " " & sFilePath & "")
        PrintLine(iFileNo, "close")
        PrintLine(iFileNo, "quit")

        FileClose(iFileNo)
        Call Pause(3)
        System.Diagnostics.Process.Start(FILE_PATH & "\GET_DMV_Import.bat")
        'retval = CStr(Shell(FILE_PATH & "\GET_DMV_Import.bat", AppWinStyle.NormalFocus))
        '*****New Ipswitch utility *******************
        MsgBox("Done")

cmdImportData_Click_Exit:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdImportData_Click_Error:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdImportData_Click" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdImportData_Click_Exit

    End Sub

    Private Sub cmdMungeData_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdMungeData.Click
        Dim iReturnValue As Object = 0
        On Error GoTo cmdMungeData_Click_Error

        Dim prm As ADODB.Parameter
        Dim iRecordCount As Integer

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        cmd = New ADODB.Command

        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
            .CommandText = "dbo.dmv_load"
            prm = .CreateParameter("inLOAD_TYPE", ADODB.DataTypeEnum.adVarChar, ADODB.ParameterDirectionEnum.adParamInput, 14, "Daily")
            .Parameters.Append(prm)
            prm = .CreateParameter("ReturnCount", ADODB.DataTypeEnum.adInteger, ADODB.ParameterDirectionEnum.adParamOutput, 0)
            .Parameters.Append(prm)
        End With

        'Execute sproc
        cmd.Execute()
        iReturnValue = cmd.Parameters("ReturnCount").Value
        cmd = Nothing

        If iReturnValue = 0 Then
            MsgBox("No records processed", MsgBoxStyle.Information, "Process Data...")
            _Image2_2.Visible = True
        Else
            _Image1_2.Visible = True
        End If

cmdMungeData_Click_Exit:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdMungeData_Click_Error:
        _Image2_2.Visible = True
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdMungeData_Click" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdMungeData_Click_Exit

    End Sub

    Private Sub cmdSetFlags_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSetFlags.Click
        Dim iReturnValue As Object = 0
        On Error GoTo cmdSetFlags_Click_Error

        Dim prm As ADODB.Parameter
        Dim iRecordCount As Short

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        cmd = New ADODB.Command

        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
            .CommandText = "dbo.Dmv_Set_Flags"
        End With

        'Execute sproc
        cmd.Execute(iReturnValue)

        If iReturnValue = 0 Then
            MsgBox("No records processed", MsgBoxStyle.Information, "Process Data...")
            _Image2_3.Visible = True
        Else
            _Image1_3.Visible = True
        End If

cmdSetFlags_Click_Exit:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdSetFlags_Click_Error:
        _Image2_3.Visible = True
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdSetFlags" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdSetFlags_Click_Exit

    End Sub

    Private Sub cmdTransferFile_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdTransferFile.Click
        Dim iReturnValue As Object = 0
        On Error GoTo cmdTransferFile_Click_Error

        Dim retval As String
        Dim iFileSizeBefore As Integer
        Dim iFileSizeAfter As Integer

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

        '**4/18/2019 AA - Added routine to remove chr(152) characters from DMV file*******
        'Dim TextLine As String = ""
        'Dim sFilePath As String
        'Dim sFilePath2 As String
        'sFilePath = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='DMVFilePath'")
        'sFilePath2 = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='DMVFilePath2'")

        'If System.IO.File.Exists(sFilePath) = True Then
        'Dim objReader As New System.IO.StreamReader(sFilePath)
        'Dim objwriter As New System.IO.StreamWriter(sFilePath2)
        'Do While objReader.Peek() <> -1
        'TextLine = Replace(objReader.ReadLine(), vbNullChar, "X") & vbNewLine
        'objwriter.Write(TextLine)
        'Loop
        'objwriter.Close()
        'objReader.Close()
        'System.IO.File.Delete(sFilePath)
        'FileSystem.RenameFile(sFilePath2, "DMV.dat")
        'End If
        '******************************************************************************

        iFileSizeBefore = GetFileSize(FILE_PATH & "\DMV.dat")

        'Append last line to imported file from DMV
        Dim intFileHandle As Short
        Dim sStr As String
        sStr = "A  XXXXXXXX XXX XXX 0 010101                       00000 010101 00000   BOGUS, TEST RECORD"
        intFileHandle = FreeFile
        FileOpen(intFileHandle, FILE_PATH & "\DMV.dat", OpenMode.Append)
        PrintLine(intFileHandle, sStr)
        FileClose(intFileHandle)

        'Verify file was updated
        iFileSizeAfter = GetFileSize(FILE_PATH & "\DMV.dat")

        sStr = ""
        If iFileSizeBefore >= iFileSizeAfter Then
            MsgBox("Dummy record was NOT appended.", MsgBoxStyle.Critical, "Dummy record missing")
            Exit Sub
        End If

        cmd = New ADODB.Command

        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
            .CommandText = "dbo.DMV_Load_Import"
        End With

        'Execute sproc
        cmd.Execute(iReturnValue)

        If iReturnValue = 0 Then
            MsgBox("No records processed", MsgBoxStyle.Information, "Process Data...")
            _Image2_1.Visible = True
            _Image1_1.Visible = False
        Else
            If ValidateDataLoad Then
                _Image2_1.Visible = False
                _Image1_1.Visible = True
            Else
                MsgBox("Records were not processed. Try again.", MsgBoxStyle.Information, "Process Data...")
                _Image2_1.Visible = True
                _Image1_1.Visible = False
            End If
        End If

        _Image1_1.Visible = True

cmdTransferFile_Click_Exit:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdTransferFile_Click_Error:
        _Image2_1.Visible = True
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdTransferFile_Click" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdTransferFile_Click_Exit

    End Sub
	
	Private Function ValidateDataLoad() As Boolean
		Dim sFilePath As Object
		
		Dim FSO As Object
		Dim FileName As Scripting.File
		Dim TextStream As Scripting.TextStream
		Dim sText As String
		Dim sDMV_CDL As String
		Dim sDBLoad_CDL As String
		
		ValidateDataLoad = False

        sFilePath = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='DMVFilePath'")

        FSO = CreateObject("Scripting.FileSystemObject")

        If FSO.FileExists(FILE_PATH & "\DMV.dat") Then
            FileName = FSO.GetFile(FILE_PATH & "\DMV.dat")
        Else
            ValidateDataLoad = False
			Exit Function
		End If
		
		TextStream = FileName.OpenAsTextStream(Scripting.IOMode.ForReading, Scripting.Tristate.TristateUseDefault)
		sText = TextStream.ReadLine
		sDMV_CDL = Trim(Mid(sText, 3, 9))
		
		TextStream.Close()
        TextStream = Nothing
        FSO = Nothing

        sDBLoad_CDL = Trim(Mid(RetrieveFieldFrom("Text", "dbo.HR_DMV_Load", "RAW_LINE_NUMBER = 1"), 2, 9))
		
		If sDBLoad_CDL = sDMV_CDL Then
			ValidateDataLoad = True
		Else
			ValidateDataLoad = False
		End If
		
	End Function
End Class