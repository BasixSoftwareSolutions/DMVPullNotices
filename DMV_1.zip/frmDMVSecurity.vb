Option Strict Off
Option Explicit On
Friend Class frmDMVSecurity
    Inherits System.Windows.Forms.Form
    Private chkTabs() As CheckBox

#Region "Windows Form Designer generated code "
    Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        chkTabs = New CheckBox() {chkTabs1, chkTabs2}
    End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents optNo As System.Windows.Forms.RadioButton
	Public WithEvents optYes As System.Windows.Forms.RadioButton
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents cmdDelete As System.Windows.Forms.Button
	Public WithEvents cmdAddUser As System.Windows.Forms.Button
	Public WithEvents chkShowUsers As System.Windows.Forms.CheckBox
	Public WithEvents Command1 As System.Windows.Forms.Button
    Public WithEvents cmdTools2 As System.Windows.Forms.Button
    Public WithEvents cmdTools1 As System.Windows.Forms.Button
    Public WithEvents cmdSelectAll2 As System.Windows.Forms.Button
    Public WithEvents cmdSelectAll1 As System.Windows.Forms.Button
    Public WithEvents listDepartments As System.Windows.Forms.CheckedListBox
    Public WithEvents frameDept As System.Windows.Forms.GroupBox
    Public WithEvents cmdReset As System.Windows.Forms.Button
    Public WithEvents chkTabs2 As System.Windows.Forms.CheckBox
    Public WithEvents chkTabs1 As System.Windows.Forms.CheckBox
    Public WithEvents frameUsers As System.Windows.Forms.GroupBox
    Public WithEvents listUsers As System.Windows.Forms.ListBox
    Friend WithEvents ListDepartments1 As ListDepartments
    Friend WithEvents SCRIGHTSDMVCOSTCENTERSBindingSource As BindingSource
    Friend WithEvents SC_RIGHTS_DMV_COST_CENTERSTableAdapter As ListDepartmentsTableAdapters.SC_RIGHTS_DMV_COST_CENTERSTableAdapter
    Public WithEvents lblUsers As System.Windows.Forms.Label
    'Public WithEvents chkTabs As Microsoft.VisualBasic.Compatibility.VB6.CheckBoxArray
    'Public WithEvents cmdSelectAll As ButtonArray
    'Public WithEvents cmdTools As ButtonArray
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDMVSecurity))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.chkShowUsers = New System.Windows.Forms.CheckBox()
        Me.Command1 = New System.Windows.Forms.Button()
        Me.cmdTools1 = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.optNo = New System.Windows.Forms.RadioButton()
        Me.optYes = New System.Windows.Forms.RadioButton()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdAddUser = New System.Windows.Forms.Button()
        Me.cmdTools2 = New System.Windows.Forms.Button()
        Me.frameDept = New System.Windows.Forms.GroupBox()
        Me.cmdSelectAll2 = New System.Windows.Forms.Button()
        Me.cmdSelectAll1 = New System.Windows.Forms.Button()
        Me.listDepartments = New System.Windows.Forms.CheckedListBox()
        Me.frameUsers = New System.Windows.Forms.GroupBox()
        Me.cmdReset = New System.Windows.Forms.Button()
        Me.chkTabs2 = New System.Windows.Forms.CheckBox()
        Me.chkTabs1 = New System.Windows.Forms.CheckBox()
        Me.listUsers = New System.Windows.Forms.ListBox()
        Me.lblUsers = New System.Windows.Forms.Label()
        Me.SCRIGHTSDMVCOSTCENTERSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ListDepartments1 = New DMVSystem.ListDepartments()
        Me.SC_RIGHTS_DMV_COST_CENTERSTableAdapter = New DMVSystem.ListDepartmentsTableAdapters.SC_RIGHTS_DMV_COST_CENTERSTableAdapter()
        Me.Frame1.SuspendLayout()
        Me.frameDept.SuspendLayout()
        Me.frameUsers.SuspendLayout()
        CType(Me.SCRIGHTSDMVCOSTCENTERSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ListDepartments1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'chkShowUsers
        '
        Me.chkShowUsers.BackColor = System.Drawing.SystemColors.Control
        Me.chkShowUsers.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkShowUsers.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShowUsers.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkShowUsers.Location = New System.Drawing.Point(72, 1)
        Me.chkShowUsers.Name = "chkShowUsers"
        Me.chkShowUsers.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkShowUsers.Size = New System.Drawing.Size(107, 17)
        Me.chkShowUsers.TabIndex = 11
        Me.chkShowUsers.Text = "DMV Users Only"
        Me.ToolTip1.SetToolTip(Me.chkShowUsers, "List users who have access to DMV")
        Me.chkShowUsers.UseVisualStyleBackColor = False
        '
        'Command1
        '
        Me.Command1.BackColor = System.Drawing.SystemColors.Control
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Location = New System.Drawing.Point(189, 342)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command1.Size = New System.Drawing.Size(272, 23)
        Me.Command1.TabIndex = 10
        Me.Command1.Text = "Who can use this Security Screen ?"
        Me.ToolTip1.SetToolTip(Me.Command1, "Click to display which users can use this secuirty screen")
        Me.Command1.UseVisualStyleBackColor = False
        '
        'cmdTools1
        '
        Me.cmdTools1.BackColor = System.Drawing.SystemColors.Control
        Me.cmdTools1.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdTools1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdTools1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTools1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdTools1.Location = New System.Drawing.Point(372, 18)
        Me.cmdTools1.Name = "cmdTools1"
        Me.cmdTools1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdTools1.Size = New System.Drawing.Size(89, 25)
        Me.cmdTools1.TabIndex = 8
        Me.cmdTools1.Text = "&Save"
        Me.ToolTip1.SetToolTip(Me.cmdTools1, "Save Changes")
        Me.cmdTools1.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.optNo)
        Me.Frame1.Controls.Add(Me.optYes)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(192, 296)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(209, 41)
        Me.Frame1.TabIndex = 16
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Can Sign Records"
        '
        'optNo
        '
        Me.optNo.BackColor = System.Drawing.SystemColors.Control
        Me.optNo.Cursor = System.Windows.Forms.Cursors.Default
        Me.optNo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optNo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.optNo.Location = New System.Drawing.Point(152, 16)
        Me.optNo.Name = "optNo"
        Me.optNo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optNo.Size = New System.Drawing.Size(49, 17)
        Me.optNo.TabIndex = 18
        Me.optNo.TabStop = True
        Me.optNo.Text = "No"
        Me.optNo.UseVisualStyleBackColor = False
        '
        'optYes
        '
        Me.optYes.BackColor = System.Drawing.SystemColors.Control
        Me.optYes.Cursor = System.Windows.Forms.Cursors.Default
        Me.optYes.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optYes.ForeColor = System.Drawing.SystemColors.ControlText
        Me.optYes.Location = New System.Drawing.Point(96, 16)
        Me.optYes.Name = "optYes"
        Me.optYes.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optYes.Size = New System.Drawing.Size(65, 17)
        Me.optYes.TabIndex = 17
        Me.optYes.TabStop = True
        Me.optYes.Text = "Yes"
        Me.optYes.UseVisualStyleBackColor = False
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDelete.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDelete.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDelete.Location = New System.Drawing.Point(96, 342)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDelete.Size = New System.Drawing.Size(82, 23)
        Me.cmdDelete.TabIndex = 15
        Me.cmdDelete.Text = "&Delete User"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdAddUser
        '
        Me.cmdAddUser.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddUser.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddUser.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddUser.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddUser.Location = New System.Drawing.Point(8, 342)
        Me.cmdAddUser.Name = "cmdAddUser"
        Me.cmdAddUser.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAddUser.Size = New System.Drawing.Size(81, 23)
        Me.cmdAddUser.TabIndex = 14
        Me.cmdAddUser.Text = "&Add User"
        Me.cmdAddUser.UseVisualStyleBackColor = False
        '
        'cmdTools2
        '
        Me.cmdTools2.BackColor = System.Drawing.SystemColors.Control
        Me.cmdTools2.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdTools2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTools2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdTools2.Location = New System.Drawing.Point(372, 48)
        Me.cmdTools2.Name = "cmdTools2"
        Me.cmdTools2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdTools2.Size = New System.Drawing.Size(89, 25)
        Me.cmdTools2.TabIndex = 9
        Me.cmdTools2.Text = "&Close"
        Me.cmdTools2.UseVisualStyleBackColor = False
        '
        'frameDept
        '
        Me.frameDept.BackColor = System.Drawing.SystemColors.Control
        Me.frameDept.Controls.Add(Me.cmdSelectAll2)
        Me.frameDept.Controls.Add(Me.cmdSelectAll1)
        Me.frameDept.Controls.Add(Me.listDepartments)
        Me.frameDept.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameDept.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameDept.Location = New System.Drawing.Point(190, 126)
        Me.frameDept.Name = "frameDept"
        Me.frameDept.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameDept.Size = New System.Drawing.Size(271, 169)
        Me.frameDept.TabIndex = 6
        Me.frameDept.TabStop = False
        Me.frameDept.Text = "DMV Screen Base Access"
        '
        'cmdSelectAll2
        '
        Me.cmdSelectAll2.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSelectAll2.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSelectAll2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSelectAll2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSelectAll2.Location = New System.Drawing.Point(86, 138)
        Me.cmdSelectAll2.Name = "cmdSelectAll2"
        Me.cmdSelectAll2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSelectAll2.Size = New System.Drawing.Size(73, 25)
        Me.cmdSelectAll2.TabIndex = 13
        Me.cmdSelectAll2.Text = "Remove All"
        Me.cmdSelectAll2.UseVisualStyleBackColor = False
        '
        'cmdSelectAll1
        '
        Me.cmdSelectAll1.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSelectAll1.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSelectAll1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSelectAll1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSelectAll1.Location = New System.Drawing.Point(12, 138)
        Me.cmdSelectAll1.Name = "cmdSelectAll1"
        Me.cmdSelectAll1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSelectAll1.Size = New System.Drawing.Size(73, 25)
        Me.cmdSelectAll1.TabIndex = 12
        Me.cmdSelectAll1.Text = "Select All"
        Me.cmdSelectAll1.UseVisualStyleBackColor = False
        '
        'listDepartments
        '
        Me.listDepartments.BackColor = System.Drawing.SystemColors.Window
        Me.listDepartments.Cursor = System.Windows.Forms.Cursors.Default
        Me.listDepartments.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.listDepartments.ForeColor = System.Drawing.SystemColors.WindowText
        Me.listDepartments.Location = New System.Drawing.Point(12, 24)
        Me.listDepartments.MultiColumn = True
        Me.listDepartments.Name = "listDepartments"
        Me.listDepartments.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.listDepartments.Size = New System.Drawing.Size(247, 109)
        Me.listDepartments.TabIndex = 7
        '
        'frameUsers
        '
        Me.frameUsers.BackColor = System.Drawing.SystemColors.Control
        Me.frameUsers.Controls.Add(Me.cmdReset)
        Me.frameUsers.Controls.Add(Me.chkTabs2)
        Me.frameUsers.Controls.Add(Me.chkTabs1)
        Me.frameUsers.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameUsers.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameUsers.Location = New System.Drawing.Point(190, 12)
        Me.frameUsers.Name = "frameUsers"
        Me.frameUsers.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameUsers.Size = New System.Drawing.Size(169, 105)
        Me.frameUsers.TabIndex = 2
        Me.frameUsers.TabStop = False
        Me.frameUsers.Text = "Security Options"
        '
        'cmdReset
        '
        Me.cmdReset.BackColor = System.Drawing.SystemColors.Control
        Me.cmdReset.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdReset.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdReset.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdReset.Location = New System.Drawing.Point(16, 68)
        Me.cmdReset.Name = "cmdReset"
        Me.cmdReset.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdReset.Size = New System.Drawing.Size(138, 24)
        Me.cmdReset.TabIndex = 5
        Me.cmdReset.Text = "Reset DMV Password"
        Me.cmdReset.UseVisualStyleBackColor = False
        '
        'chkTabs2
        '
        Me.chkTabs2.BackColor = System.Drawing.SystemColors.Control
        Me.chkTabs2.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkTabs2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkTabs2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkTabs2.Location = New System.Drawing.Point(16, 44)
        Me.chkTabs2.Name = "chkTabs2"
        Me.chkTabs2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkTabs2.Size = New System.Drawing.Size(127, 18)
        Me.chkTabs2.TabIndex = 4
        Me.chkTabs2.Text = "Vehicle Checkout"
        Me.chkTabs2.UseVisualStyleBackColor = False
        '
        'chkTabs1
        '
        Me.chkTabs1.BackColor = System.Drawing.SystemColors.Control
        Me.chkTabs1.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkTabs1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkTabs1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkTabs1.Location = New System.Drawing.Point(16, 26)
        Me.chkTabs1.Name = "chkTabs1"
        Me.chkTabs1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkTabs1.Size = New System.Drawing.Size(81, 18)
        Me.chkTabs1.TabIndex = 3
        Me.chkTabs1.Text = "DMV System"
        Me.chkTabs1.UseVisualStyleBackColor = False
        '
        'listUsers
        '
        Me.listUsers.BackColor = System.Drawing.SystemColors.Window
        Me.listUsers.Cursor = System.Windows.Forms.Cursors.Default
        Me.listUsers.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.listUsers.ForeColor = System.Drawing.SystemColors.WindowText
        Me.listUsers.ItemHeight = 14
        Me.listUsers.Location = New System.Drawing.Point(8, 18)
        Me.listUsers.Name = "listUsers"
        Me.listUsers.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.listUsers.Size = New System.Drawing.Size(171, 312)
        Me.listUsers.Sorted = True
        Me.listUsers.TabIndex = 0
        '
        'lblUsers
        '
        Me.lblUsers.AutoSize = True
        Me.lblUsers.BackColor = System.Drawing.SystemColors.Control
        Me.lblUsers.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUsers.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsers.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUsers.Location = New System.Drawing.Point(10, 2)
        Me.lblUsers.Name = "lblUsers"
        Me.lblUsers.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUsers.Size = New System.Drawing.Size(39, 14)
        Me.lblUsers.TabIndex = 1
        Me.lblUsers.Text = "Users"
        '
        'SCRIGHTSDMVCOSTCENTERSBindingSource
        '
        Me.SCRIGHTSDMVCOSTCENTERSBindingSource.DataMember = "SC_RIGHTS_DMV_COST_CENTERS"
        Me.SCRIGHTSDMVCOSTCENTERSBindingSource.DataSource = Me.ListDepartments1
        '
        'ListDepartments1
        '
        Me.ListDepartments1.DataSetName = "ListDepartments"
        Me.ListDepartments1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SC_RIGHTS_DMV_COST_CENTERSTableAdapter
        '
        Me.SC_RIGHTS_DMV_COST_CENTERSTableAdapter.ClearBeforeFill = True
        '
        'frmDMVSecurity
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.CancelButton = Me.cmdTools1
        Me.ClientSize = New System.Drawing.Size(470, 372)
        Me.ControlBox = False
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdAddUser)
        Me.Controls.Add(Me.chkShowUsers)
        Me.Controls.Add(Me.Command1)
        Me.Controls.Add(Me.cmdTools2)
        Me.Controls.Add(Me.cmdTools1)
        Me.Controls.Add(Me.frameDept)
        Me.Controls.Add(Me.frameUsers)
        Me.Controls.Add(Me.listUsers)
        Me.Controls.Add(Me.lblUsers)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmDMVSecurity"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DMV Security"
        Me.Frame1.ResumeLayout(False)
        Me.frameDept.ResumeLayout(False)
        Me.frameUsers.ResumeLayout(False)
        CType(Me.SCRIGHTSDMVCOSTCENTERSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ListDepartments1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmDMVSecurity
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmDMVSecurity
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmDMVSecurity()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set(value As frmDMVSecurity)
            m_vb6FormDefInstance = value
        End Set
    End Property
#End Region
    Private DMVTabID As String
    Private VehicleTabID As String
    Private i As Short
    '---------------------------------------------------------------------------------------
    ' Procedure : chkShowUsers_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Show users who can use the Security module
    '---------------------------------------------------------------------------------------
    '
    Private Sub chkShowUsers_CheckStateChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles chkShowUsers.CheckStateChanged
        On Error Resume Next

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        GetUsers()
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdAddUser_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Add a new user to the security module
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdAddUser_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAddUser.Click
        On Error GoTo cmdAddUser_Click_ErrorHandler

        frmAddUser.DefInstance.ShowDialog()

        Exit Sub
cmdAddUser_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdAddUser_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdDelete_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Delete a user from the Security module
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdDelete_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdDelete.Click
        On Error GoTo cmdDelete_Click_ErrorHandler

        Dim vResponse As Object

        'Make sure we have a current record
        If listUsers.Text <> "" Then
            'Promt user for confirmation
            vResponse = MsgBox("Are you sure you want to Delete this user: " & listUsers.Text & "?", MsgBoxStyle.YesNo + MsgBoxStyle.Critical, "Delete User")
            If vResponse = MsgBoxResult.Yes Then
                'Delete user from SC_DMV_RIGHTS_SYSTEMS table
                sSQL = ""
                sSQL = "DELETE dbo.SC_DMV_RIGHTS_SYSTEMS " & "WHERE USER_ID = '" & listUsers.Text & "'"

                cmd = New ADODB.Command
                With cmd
                    .let_ActiveConnection(oConn)
                    .CommandType = ADODB.CommandTypeEnum.adCmdText
                    .CommandText = sSQL
                End With
                cmd.Execute()

                'Delte user from SC_USER_IDS table
                sSQL = ""
                sSQL = "DELETE dbo.SC_USER_IDS " & "WHERE USER_ID = '" & listUsers.Text & "'"

                cmd = New ADODB.Command
                With cmd
                    .let_ActiveConnection(oConn)
                    .CommandType = ADODB.CommandTypeEnum.adCmdText
                    .CommandText = sSQL
                End With
                cmd.Execute()

                MsgBox("Record Deleted.", MsgBoxStyle.Information, "User Deleted")
                'Populate list again
                Call GetUsers()

            End If
        Else
            MsgBox("You must first select a User to Delete", MsgBoxStyle.Information, "Select User")
        End If

        Exit Sub
cmdDelete_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdDelete_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdReset_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Reset security password for DMV
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdReset_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdReset.Click
        On Error GoTo cmdReset_Click_ErrorHandler

        'Make sure we have a current record
        If listUsers.Text = "" Then
            MsgBox("Select a user first.", MsgBoxStyle.Information, "Reset Password")
            Exit Sub
        End If

        'Prompt user for confirmation
        If MsgBox("Reset password for user: " & listUsers.Text & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm") = MsgBoxResult.No Then Exit Sub
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

        'Update record
        sSQL = "UPDATE dbo.sc_user_ids "
        sSQL = sSQL & "SET dmv_password='reset' "
        sSQL = sSQL & "WHERE user_id='" & listUsers.Text & "'"

        cmd = New ADODB.Command
        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdText
            .CommandText = sSQL
        End With
        cmd.Execute()

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        MsgBox("Password reset!", MsgBoxStyle.Information, "Confirm")

        Exit Sub
cmdReset_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdReset " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Exit Sub

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdSelectAll_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Select all options
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdSelectAll_Click(ByVal Index As Integer)
        On Error Resume Next

        If Index = 0 Then
            AllSelect(True)
        Else
            AllSelect(False)
        End If

        listDepartments.TopIndex = 0
        frameDept.Text = "DMV Screen Department Access (" & listDepartments.CheckedIndices.Count & ")"

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : AllSelect
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Either select or remove all options from list
    '---------------------------------------------------------------------------------------
    '
    Private Sub AllSelect(ByRef inBoolean As Boolean)
        On Error Resume Next

        For i = 0 To listDepartments.Items.Count - 1
            listDepartments.SetItemChecked(i, inBoolean)
        Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdTools_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Either save changes or close form
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdTools_Click(ByVal Index As Integer)
        On Error Resume Next

        If Index = 1 Then
            Me.Close()
        Else
            SaveChanges()
        End If

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : SaveChanges
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Save changes made
    '---------------------------------------------------------------------------------------
    '
    Private Sub SaveChanges()
        On Error GoTo SaveChanges_ErrorHandler

        'Make sure we have a current record
        If listUsers.Text = "" Then
            MsgBox("Select a user first.", MsgBoxStyle.Information, "Reset Password")
            Exit Sub
        End If

        'Prompt user for confirmation
        If MsgBox("Save changes for user: " & listUsers.Text & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm") = MsgBoxResult.No Then Exit Sub

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

        'Delete any previous records from table
        sSQL = "DELETE FROM dbo.sc_dmv_rights_systems "
        sSQL = sSQL & "WHERE user_id='" & listUsers.Text & "' "
        sSQL = sSQL & "AND tab_id IN ('" & DMVTabID & "','" & VehicleTabID & "')"

        cmd = New ADODB.Command
        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdText
            .CommandText = sSQL
        End With
        cmd.Execute()

        'Insert new record
        If chkTabs1.CheckState = System.Windows.Forms.CheckState.Checked Then
            sSQL = "INSERT INTO dbo.sc_dmv_rights_systems "
            sSQL = sSQL & "VALUES (0,'" & listUsers.Text & "','" & DMVTabID & "','VWF','" & LCase(Environ("USERNAME")) & "', '" & Now & "')"

            cmd = New ADODB.Command
            With cmd
                .let_ActiveConnection(oConn)
                .CommandType = ADODB.CommandTypeEnum.adCmdText
                .CommandText = sSQL
            End With
            cmd.Execute()
        End If

        'Insert new record
        If chkTabs2.CheckState = System.Windows.Forms.CheckState.Checked Then
            sSQL = "INSERT INTO dbo.sc_dmv_rights_systems "
            sSQL = sSQL & "VALUES (0,'" & listUsers.Text & "','" & VehicleTabID & "','VWF','" & LCase(Environ("USERNAME")) & "', '" & Now & "')"

            cmd = New ADODB.Command
            With cmd
                .let_ActiveConnection(oConn)
                .CommandType = ADODB.CommandTypeEnum.adCmdText
                .CommandText = sSQL
            End With
            cmd.Execute()
        End If

        'Delete any previous records
        sSQL = "DELETE FROM dbo.sc_rights_dmv_cost_centers "
        sSQL = sSQL & "WHERE user_id='" & listUsers.Text & "'"

        cmd = New ADODB.Command
        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdText
            .CommandText = sSQL
        End With
        cmd.Execute()

        'insert new record
        For i = 0 To listDepartments.Items.Count - 1
            If listDepartments.GetItemChecked(i) Then
                sSQL = "INSERT INTO dbo.sc_rights_dmv_cost_centers "
                sSQL = sSQL & "VALUES (0,'" & listUsers.Text & "','" & listDepartments.Text.ToString & "','0',NULL,'" & LCase(Environ("USERNAME")) & "', '" & Now & "')"

                cmd = New ADODB.Command
                With cmd
                    .let_ActiveConnection(oConn)
                    .CommandType = ADODB.CommandTypeEnum.adCmdText
                    .CommandText = sSQL
                End With
                cmd.Execute()
            End If
        Next

        'Update the Can Sign Records field
        sSQL = ""
        sSQL = "SELECT * FROM dbo.sc_user_ids WHERE user_id = '" & listUsers.Text & "'"
        If oConn.State <> ADODB.ObjectStateEnum.adStateOpen Then
            MsgBox("Connection could not be found. Contact your systems administrator.", MsgBoxStyle.Critical, "Connection error")
        End If

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic)

        If rs.RecordCount > 0 Then 'Record exist so update data
            rs.MoveFirst()
            If optYes.Checked = True Then
                rs.Fields("can_sign_record").Value = "Yes"
            Else
                rs.Fields("can_sign_record").Value = "No"
            End If

            rs.Update()
        End If

        rs.Close()

        MsgBox("Record has been saved", MsgBoxStyle.Information, "DMV Security")
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

        Exit Sub
SaveChanges_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: SaveChanges " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : Command1_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : View all user who can access this screen
    '---------------------------------------------------------------------------------------
    '
    Private Sub Command1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command1.Click
        On Error Resume Next

        Dim sStr As String = ""

        sSQL = "SELECT user_id "
        sSQL = sSQL & "FROM dbo.sc_user_ids "
        sSQL = sSQL & "WHERE security_zar='Y'"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenForwardOnly)
        If Not (rs.EOF And rs.BOF) Then
            sStr = ""
            rs.MoveFirst()
            Do Until rs.EOF
                sStr = sStr & rs.Fields("user_id").Value & vbCrLf
                rs.MoveNext()
            Loop
            rs = Nothing
        End If

        'Display results
        MsgBox("Users who have access to DMV Security:" & Chr(10) & Chr(10) & sStr)

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : Form_Load
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the form
    '---------------------------------------------------------------------------------------
    '
    Private Sub frmDMVSecurity_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ListDepartments1.SC_RIGHTS_DMV_COST_CENTERS' table. You can move, or remove it, as needed.
        Me.SC_RIGHTS_DMV_COST_CENTERSTableAdapter.Fill(Me.ListDepartments1.SC_RIGHTS_DMV_COST_CENTERS)
        On Error Resume Next

        tmp_user_id = LCase(Environ("USERNAME"))

        DMVTabID = "DMV"
        VehicleTabID = "VEHIC"
        GetDepartments()
        GetUsers()
        GetUsersSetup()

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : GetUsers
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Populate the listUsers listbox
    '---------------------------------------------------------------------------------------
    '
    Public Sub GetUsers()
        On Error GoTo GetUsers_ErrorHandler

        'Clear the listbox
        listUsers.Items.Clear()
        'Show only DMV users
        If chkShowUsers.CheckState = System.Windows.Forms.CheckState.Unchecked Then
            sSQL = "SELECT user_id " & " FROM dbo.sc_user_ids " & " ORDER BY 1"
        Else 'Show all users
            sSQL = "SELECT user_id " & " FROM dbo.sc_user_ids " & " WHERE user_id IN " & " (SELECT user_id FROM dbo.sc_dmv_rights_systems " & " WHERE tab_id IN ('" & DMVTabID & "','" & VehicleTabID & "'))" & " ORDER BY 1"
        End If

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                listUsers.Items.Add(rs.Fields("user_id").Value)
                rs.MoveNext()
            Loop
        End If

        lblUsers.Text = "Users (" & rs.RecordCount & ")"

        If listUsers.Items.Count > 0 Then
            'listUsers.ListIndex = 0
        End If

        Exit Sub
GetUsers_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetUsers " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : GetUsersDepartments
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   :
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetUsersDepartments()
        On Error GoTo GetUsersDepartments_ErrorHandler

        Dim Counter As Short
        Dim FirstEncounter As Short

        For i = 0 To listDepartments.Items.Count - 1
            listDepartments.SetItemChecked(i, False)
        Next

        sSQL = "SELECT COST_CENTER " & " FROM dbo.sc_rights_dmv_cost_centers " & " WHERE user_id='" & listUsers.Text & "' ORDER BY 1"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        Counter = 0
        FirstEncounter = -1
        If rs.RecordCount > 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                For i = 0 To listDepartments.Items.Count - 1
                    If listDepartments.Items(i) <> Nothing Then
                        If listDepartments.Items(i) = rs.Fields("COST_CENTER").Value Then
                            listDepartments.SetItemChecked(i, True)
                            If FirstEncounter < 0 Then FirstEncounter = i
                            Counter = Counter + 1
                            Exit For
                        End If
                    End If
                Next
                rs.MoveNext()
            Loop
        Else
            FirstEncounter = 0
        End If

        frameDept.Text = "DMV Screen Department Access (" & Counter & ")"
        listDepartments.SelectedIndex = FirstEncounter
        listDepartments.TopIndex = 0 'FirstEncounter

        Exit Sub
GetUsersDepartments_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetUsersDepartments " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : GetDepartments
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   :
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetDepartments()
        On Error GoTo GetDepartments_ErrorHandler

        Dim sCostCenter As String
        Dim sSection As String

        sSQL = "SELECT DISTINCT COST_CENTER, SECTION "
        sSQL = sSQL & "FROM dbo.SC_DMV_COST_CENTERS "
        sSQL = sSQL & "WHERE COST_CENTER <> '0621' "
        sSQL = sSQL & "ORDER BY 1"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            rs.MoveFirst()

            Do While rs.EOF = False
                sCostCenter = rs.Fields("COST_CENTER").Value
                'sSection = rs.Fields("Section").Value
                listDepartments.Items.Add(sCostCenter)
                rs.MoveNext()
            Loop
        End If

        Exit Sub
GetDepartments_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetDepartments " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : listDepartments_ItemCheck
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   :
    '---------------------------------------------------------------------------------------
    '
    Private Sub listDepartments_ItemCheck(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.ItemCheckEventArgs) Handles listDepartments.ItemCheck
        On Error Resume Next

        frameDept.Text = "DMV Screen Department Access (" & listDepartments.CheckedIndices.Count & ")"

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : listUsers_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Set the form whenever a user is selected
    '---------------------------------------------------------------------------------------
    '
    Private Sub listUsers_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles listUsers.SelectedIndexChanged
        On Error Resume Next

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        GetUsersSetup()
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : GetUsersSetup
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Get user information
    '---------------------------------------------------------------------------------------
    '
    Private Sub GetUsersSetup()
        On Error GoTo GetUsersSetup_ErrorHandler

        'Clear the checkbox
        chkTabs1.CheckState = System.Windows.Forms.CheckState.Unchecked
        chkTabs2.CheckState = System.Windows.Forms.CheckState.Unchecked

        'Get DMV and Vehicle infor
        sSQL = "SELECT tab_id " & " FROM dbo.sc_dmv_rights_systems " & " WHERE (tab_id ='" & DMVTabID & "' OR tab_id='" & VehicleTabID & "')" & " AND user_id='" & listUsers.Text & "'"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                Select Case rs.Fields("tab_id").Value
                    Case Is = DMVTabID
                        chkTabs1.CheckState = System.Windows.Forms.CheckState.Checked
                    Case Is = VehicleTabID
                        chkTabs2.CheckState = System.Windows.Forms.CheckState.Checked
                End Select
                rs.MoveNext()
            Loop
        End If

        GetUsersDepartments()
        GetCanSignRecords()
        frameUsers.Text = "Security Options (" & listUsers.Text & ")"

        Exit Sub
GetUsersSetup_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetUsersSetup " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub GetCanSignRecords()
        Dim sCanSignRecord As String

        sCanSignRecord = RetrieveFieldFrom("can_sign_record", "dbo.sc_user_ids", "user_id='" & listUsers.Text & "'")
        If sCanSignRecord = "Yes" Then
            optYes.Checked = True
        Else
            optNo.Checked = True
        End If

    End Sub

    Private Sub cmdSelectAll1_Click(sender As Object, e As EventArgs) Handles cmdSelectAll1.Click

        cmdSelectAll_Click(0)

    End Sub

    Private Sub cmdSelectAll2_Click(sender As Object, e As EventArgs) Handles cmdSelectAll2.Click

        cmdSelectAll_Click(1)

    End Sub

    Private Sub cmdTools1_Click(sender As Object, e As EventArgs) Handles cmdTools1.Click

        cmdTools_Click(0)

    End Sub

    Private Sub cmdTools2_Click(sender As Object, e As EventArgs) Handles cmdTools2.Click

        cmdTools_Click(1)

    End Sub

    Private Sub FillDepartmentListToolStripButton_Click(sender As Object, e As EventArgs)
        Try
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class