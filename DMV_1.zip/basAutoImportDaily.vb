Option Strict Off
Option Explicit On
Imports System.IO
Imports Microsoft.VisualBasic.FileIO

Module basAutoImportDaily
    Private Declare Function OpenProcess Lib "kernel32" (ByVal dwDesiredAccess As Integer, ByVal bInheritHandle As Integer, ByVal dwProcessId As Integer) As Integer
    Private Declare Function WaitForSingleObject Lib "kernel32" (ByVal hHandle As Integer, ByVal dwMilliseconds As Integer) As Integer
    Private Declare Function CloseHandle Lib "kernel32" (ByVal hObject As Integer) As Integer
    Dim sFormat As String = "MM/dd/yyyy"

    Public Function FileExists(ByRef sFile As String) As Object
        Dim fs As Object

        fs = CreateObject("Scripting.FileSystemObject")
        FileExists = fs.FileExists(sFile)

    End Function

    Public Function GetDateTimeStamp(ByRef sFile As String) As String
        Dim fs As Object
        fs = CreateObject("Scripting.FileSystemObject")
        GetDateTimeStamp = CDate(fs.GetFile(sFile).DateLastModified).ToString(sFormat)

    End Function

    Public Function GetFileSize(ByRef sFile As String) As Integer

        GetFileSize = FileLen(sFile)

    End Function

    Private Sub SendEmail(ByRef sTo As String, ByRef sBody As String, ByRef sSubject As String)
        Dim prm As Object
        On Error GoTo Err_ConnError

        Dim oEmailConn As New ADODB.Connection
        Dim cmdEmail As New ADODB.Command
        oEmailConn.ConnectionString = "Provider=SQLOLEDB;" &
                                        "SERVER=ormsql17;" &
                                        "Database=DMV;" &
                                        "DataTypeCompatibility=80;" &
                                        "User Id=InHouseApp_User;" &
                                        "Password=Oct@!2345;"
        oEmailConn.Open()
        With cmdEmail
            .let_ActiveConnection(oEmailConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
            .CommandText = "dbo.spSendDMVEmail"

            prm = .CreateParameter("@vchRecipients", ADODB.DataTypeEnum.adVarChar, ADODB.ParameterDirectionEnum.adParamInput, 100, sTo)
            .Parameters.Append(prm)
            prm = .CreateParameter("@vchBody", ADODB.DataTypeEnum.adVarChar, ADODB.ParameterDirectionEnum.adParamInput, 4000, sBody)
            .Parameters.Append(prm)
            prm = .CreateParameter("@vchSubject", ADODB.DataTypeEnum.adVarChar, ADODB.ParameterDirectionEnum.adParamInput, 100, sSubject)
            .Parameters.Append(prm)

            .Execute(Options:=ADODB.ExecuteOptionEnum.adExecuteNoRecords)
        End With


SendEmail_Exit:
        cmdEmail = Nothing
        oEmailConn.Close()
        oEmailConn = Nothing

        Exit Sub

Err_ConnError:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: SendEmail" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        Resume SendEmail_Exit

    End Sub

    Public Function ImportDMVFile() As Object
        Dim retval As Object
        Dim vResponse As Object
        Dim iDaysBeforeExpiring As Object
        Dim dPasswordDate As Object
        On Error GoTo ImportDMVFile_Error

        Dim sFTPPassword As String
        Dim sFilePath As String
        Dim sFileToGet As String
        Dim dYesterday As Date
        Dim iFileNo As Short
        Dim sStr As String
        Dim sEmailTo As String
        Dim sFTP_Tool_Path As String
        Dim sFTP_Path As String
        Dim dFileDate As Date

        sEmailTo = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='SendEmailTo'")

        cmd = New ADODB.Command

        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
            .CommandText = "dbo.spSendDMVExpiringPaswwordEmail"
        End With

        'Execute sproc
        cmd.Execute()

        'Get the DMV FTP password
        sFTPPassword = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='FTPPassword'")
        sFilePath = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='DMVFilePath'")
        sFTP_Tool_Path = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='SecureFXPath'")
        dYesterday = DateAdd(Microsoft.VisualBasic.DateInterval.Day, -1, Now)
        If DatePart(Microsoft.VisualBasic.DateInterval.Weekday, dYesterday) = FirstDayOfWeek.Saturday Then
            sFileToGet = "DLINQ_OUTA198" & (dYesterday).Year.ToString("0000") & (dYesterday).Month.ToString("00") & (dYesterday).Day.ToString("00") & ".TXT"
        Else
            sFileToGet = "DLINQ_OUT198" & (dYesterday).Year.ToString("0000") & (dYesterday).Month.ToString("00") & (dYesterday).Day.ToString("00") & ".TXT"
        End If

        'Create and open the file
        iFileNo = FreeFile()
        FileOpen(iFileNo, FILE_PATH & "\GET_DMV_Import.bat", OpenMode.Output)

        'Populate the file
        PrintLine(iFileNo, "C:")
        PrintLine(iFileNo, "CD..")
        PrintLine(iFileNo, "CD..")
        PrintLine(iFileNo, sFTP_Tool_Path)
        PrintLine(iFileNo, "SFXCL /s DMV /DMVData/FromDMV/" & sFileToGet & " " & sFilePath & "")
        PrintLine(iFileNo, "close")
        PrintLine(iFileNo, "quit")

        FileClose(iFileNo)

        Pause((3))
        retval = Shell(FILE_PATH & "\GET_DMV_Import.bat", AppWinStyle.NormalFocus)
        Pause((10))

        'Make sure file has been imported
        If FileExists(FILE_PATH & "\DMV.dat") Then
            Call AddBogusRecord()
        End If

ImportDMVFile_Exit:
        Exit Function

ImportDMVFile_Error:
        sMsg = "Error Information..." & "<br>" & "<br>"
        sMsg = sMsg & "Function: ImportDMVFile" & "<br>"
        sMsg = sMsg & "Description: " & Err.Description & "<br>"
        sMsg = sMsg & "Error #: " & Err.Number.ToString & "<br>"
        Call SendEmail(sEmailTo, "DMV Pull Notice File Not Received", sMsg)

    End Function

    Public Function ValidateDataLoad() As Boolean
        Dim sFilePath As String = ""
        Dim FSO As Object
        Dim FileName As Scripting.File
        Dim TextStream As Scripting.TextStream
        Dim sText As String
        Dim sDMV_CDL As String
        Dim sDBLoad_CDL As String

        ValidateDataLoad = False

        sFilePath = RetrieveFieldFrom("Value", "SC_SYSTEM", "Name='DMVFilePath'")

        FSO = CreateObject("Scripting.FileSystemObject")
        If FSO.FileExists(sFilePath) Then
            FileName = FSO.GetFile(sFilePath)
        Else
            ValidateDataLoad = False
            Exit Function
        End If

        TextStream = FileName.OpenAsTextStream(Scripting.IOMode.ForReading, Scripting.Tristate.TristateUseDefault)
        sText = TextStream.ReadLine
        sDMV_CDL = Trim(Mid(sText, 3, 9))
        TextStream.Close()
        TextStream = Nothing
        FSO = Nothing
        sDBLoad_CDL = Trim(Mid(RetrieveFieldFrom("Text", "dbo.HR_DMV_Load", "RAW_LINE_NUMBER = 1"), 2, 9))
        If sDBLoad_CDL = sDMV_CDL Then
            ValidateDataLoad = True
        Else
            ValidateDataLoad = False
        End If
    End Function

    Public Sub Pause(ByVal Seconds As Integer)

        For i As Integer = 0 To Seconds
            System.Threading.Thread.Sleep(10)
            Application.DoEvents()
        Next

    End Sub

    Public Function AddBogusRecord() As String
        On Error GoTo TransferFile_Error

        Dim retval As String
        Dim iFileSizeBefore As Integer
        Dim iFileSizeAfter As Integer

        iFileSizeBefore = GetFileSize(FILE_PATH & "\DMV.dat")

        'Append last line to imported file from DMV
        Dim intFileHandle As Short
        Dim sStr As String
        sStr = "A  XXXXXXXX XXX XXX 0 010101                       00000 010101 00000   BOGUS, TEST RECORD"
        intFileHandle = FreeFile()
        FileOpen(intFileHandle, FILE_PATH & "\DMV.dat", OpenMode.Append)
        PrintLine(intFileHandle, sStr)
        FileClose(intFileHandle)
        'Verify file was updated
        iFileSizeAfter = GetFileSize(FILE_PATH & "\DMV.dat")

TransferFile_Exit:
        Exit Function

TransferFile_Error:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: TransferFile" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        AddBogusRecord = sMsg

    End Function

    Private Function MungeData() As String
        On Error GoTo MungeData_Error

        Dim prm As ADODB.Parameter
        Dim iReturnValue As Integer = 0
        Dim x As Integer = 1

ExecuteAgain:

        Pause((10))

        cmd = New ADODB.Command

        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
            .CommandText = "dbo.dmv_load"
            prm = .CreateParameter("inLOAD_TYPE", ADODB.DataTypeEnum.adVarChar, ADODB.ParameterDirectionEnum.adParamInput, 14, "Daily")
            .Parameters.Append(prm)
            prm = .CreateParameter("ReturnCount", ADODB.DataTypeEnum.adInteger, ADODB.ParameterDirectionEnum.adParamOutput, 0)
            .Parameters.Append(prm)
        End With

        'Execute sproc
        cmd.Execute()
        iReturnValue = cmd.Parameters("ReturnCount").Value
        cmd = Nothing

        If iReturnValue = 0 And x < 5 Then
            x = x + 1
            GoTo ExecuteAgain
        End If

        If x = 4 Then
            MungeData = "No records processed."
        Else
            MungeData = "Completed."
        End If

MungeData_Exit:
        cmd = Nothing
        Exit Function

MungeData_Error:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: MungeData" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MungeData = sMsg

    End Function

    Private Function SetFlags() As String
        On Error GoTo SetFlags_Error

        Dim prm As ADODB.Parameter
        Dim iRecordCount As Short

        cmd = New ADODB.Command

        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
            .CommandText = "dbo.Dmv_Set_Flags"
        End With

        'Execute sproc
        cmd.Execute(iRecordCount)

        If iRecordCount = 0 Then
            SetFlags = "No records processed"
        Else
            SetFlags = "Completed"
        End If

        'Pause process 5 seconds
        Call Pause(5)

        cmd = Nothing

        Exit Function

SetFlags_Exit:
        Exit Function

SetFlags_Error:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdSetFlags" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        SetFlags = sMsg

    End Function

    Public Function ValidateTransfer() As String
        On Error GoTo ValidateTransfer_Error

        Dim iCount As Short

        'Check for DMV rights
        sSQL = "SELECT Count(*) as iCount "
        sSQL = sSQL & "FROM dbo.HR_DMV_I_EMPLOYEES "
        sSQL = sSQL & "WHERE CONVERT(varchar(10), CREATION_DATE, 101)='" & Date.Now.ToString(sFormat) & "'"

        Dim rs As New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenForwardOnly)
        If Not (rs.EOF And rs.BOF) Then
            iCount = rs.Fields("iCount").Value
        End If

        rs.Close()
        rs = Nothing

        If iCount > 0 Then
            ValidateTransfer = iCount & " records imported and processed."
        Else
            ValidateTransfer = "No records were processed"
        End If

        Exit Function

ValidateTransfer_Exit:
        Exit Function

ValidateTransfer_Error:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: ValidateTransfer" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        ValidateTransfer = sMsg

    End Function

    Public Sub ShellAndWait(ByVal program_name As String, ByVal window_style As AppWinStyle)
        Dim INFINITE As Object = &HFFFF
        Dim SYNCHRONIZE As Object = &H100000
        Dim process_id As Integer
        Dim process_handle As Integer

        ' Start the program.
        On Error Resume Next
        process_id = Shell(program_name, window_style)
        On Error GoTo 0

        System.Windows.Forms.Application.DoEvents()

        ' Wait for the program to finish.
        ' Get the process handle.
        process_handle = OpenProcess(SYNCHRONIZE, 0, process_id)
        If process_handle <> 0 Then
            WaitForSingleObject(process_handle, INFINITE)
            CloseHandle(process_handle)
        End If

    End Sub
End Module