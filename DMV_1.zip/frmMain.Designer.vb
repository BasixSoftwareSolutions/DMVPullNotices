﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.frmViews = New System.Windows.Forms.TabControl()
        Me.tbSearch = New System.Windows.Forms.TabPage()
        Me.gbSearchBy = New System.Windows.Forms.GroupBox()
        Me.optView3 = New System.Windows.Forms.RadioButton()
        Me.optView2 = New System.Windows.Forms.RadioButton()
        Me.optView1 = New System.Windows.Forms.RadioButton()
        Me.cmdUnsigned = New System.Windows.Forms.Button()
        Me.lblRecordCount1 = New System.Windows.Forms.Label()
        Me.txtInput2 = New System.Windows.Forms.MaskedTextBox()
        Me.txtInput1 = New System.Windows.Forms.MaskedTextBox()
        Me.chkSoundLike = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.listStatus = New System.Windows.Forms.ComboBox()
        Me.ListCompany1 = New System.Windows.Forms.ComboBox()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.lblInput2 = New System.Windows.Forms.Label()
        Me.lblInput1 = New System.Windows.Forms.Label()
        Me.tbMajorMinor = New System.Windows.Forms.TabPage()
        Me.lblRecordCount2 = New System.Windows.Forms.Label()
        Me.cmdExcel1 = New System.Windows.Forms.Button()
        Me.listStatus2 = New System.Windows.Forms.ComboBox()
        Me.lblOrderDate = New System.Windows.Forms.Label()
        Me.txtOrderDate = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbSearch = New System.Windows.Forms.ComboBox()
        Me.cmdMajorMinorSearch = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.optMajorMinor3 = New System.Windows.Forms.RadioButton()
        Me.optMajorMinor2 = New System.Windows.Forms.RadioButton()
        Me.optMajorMinor1 = New System.Windows.Forms.RadioButton()
        Me.ListCompany2 = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.tbExpired = New System.Windows.Forms.TabPage()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.cmdExcel2 = New System.Windows.Forms.Button()
        Me.cmdExpired = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtExpiredDays = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ListCompany3 = New System.Windows.Forms.ComboBox()
        Me.listStatus3 = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.optFutureSearch4 = New System.Windows.Forms.RadioButton()
        Me.optFutureSearch1 = New System.Windows.Forms.RadioButton()
        Me.optFutureSearch3 = New System.Windows.Forms.RadioButton()
        Me.optFutureSearch2 = New System.Windows.Forms.RadioButton()
        Me.lblRecordCount3 = New System.Windows.Forms.Label()
        Me.grdFlags = New System.Windows.Forms.DataGridView()
        Me.MESSAGE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Flag_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Major_Minor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EMPLOYEE_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblFlagRecords = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtHR6 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtHR5 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtHR4 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtHR3 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtHR2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtHR1 = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.fmDMVInfo = New System.Windows.Forms.GroupBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtDMV12 = New System.Windows.Forms.TextBox()
        Me.txtDMV14 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtDMV13 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtDMV11 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtDMV10 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtDMV9 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtDMV8 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtDMV5 = New System.Windows.Forms.TextBox()
        Me.txtDMV7 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtDMV6 = New System.Windows.Forms.TextBox()
        Me.lblCDLExpDate = New System.Windows.Forms.Label()
        Me.txtDMV4 = New System.Windows.Forms.TextBox()
        Me.lblMedicalCard = New System.Windows.Forms.Label()
        Me.txtDMV3 = New System.Windows.Forms.TextBox()
        Me.lblVTTExpDate = New System.Windows.Forms.Label()
        Me.txtDMV2 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtDMV1 = New System.Windows.Forms.TextBox()
        Me.txtSignature = New System.Windows.Forms.TextBox()
        Me.lblExpiredMessage = New System.Windows.Forms.Label()
        Me.cmdSignature = New System.Windows.Forms.Button()
        Me.EMPLOYEE_ID_5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SEQUENCE_5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CREATION_DATE_5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CREATED_BY_5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ADDRESS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmdPrintScreen = New System.Windows.Forms.Button()
        Me.grdSearch = New System.Windows.Forms.DataGridView()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.tabInformation = New System.Windows.Forms.TabControl()
        Me.tabx1 = New System.Windows.Forms.TabPage()
        Me.lblMisc = New System.Windows.Forms.Label()
        Me.lblSuspensions = New System.Windows.Forms.Label()
        Me.lblViolations = New System.Windows.Forms.Label()
        Me.grdMisc = New System.Windows.Forms.DataGridView()
        Me.COMMENTS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CREATED_BY = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CREATION_DATE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LAST_UPDATED_BY = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LAST_UPDATED_DATE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SEQUENCE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EMPLOYEE_ID_1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdSuspensions = New System.Windows.Forms.DataGridView()
        Me.CC_ACTION = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ORDER_DATE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EFFECTIVE_DATE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AUTHOR_ACTION = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.THRU_DATE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.REASON_FOR_ACTION = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SERVICE_TYPE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SERVICE_DATE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FILE_TYPE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ACTION_TAKEN = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TO_BE_RESOLVED_BY = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RESOLVED_DATE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LAST_UPDATED_BY_1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LAST_UPDATED = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SEQUENCE_1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EMPLOYEE_ID_2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdViolations = New System.Windows.Forms.DataGridView()
        Me.ViewActionTaken = New System.Windows.Forms.DataGridViewImageColumn()
        Me.ITEM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VIOlATION_DATE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CONVICTION_DATE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SECTION = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.STATUTE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DOCKET_FILE_NO = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.COURT_ACC_RPT_NO = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VEHICLE_LIC_NO = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.COMMENTS_1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tabx2 = New System.Windows.Forms.TabPage()
        Me.lblAKA = New System.Windows.Forms.Label()
        Me.grdAKA = New System.Windows.Forms.DataGridView()
        Me.AKA_NAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CREATED_BY_4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CREATION_DATE_4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LAST_UPDATED_BY_4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LAST_UPDATED_DATE_4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SEQUENCE_4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EMPLOYEE_ID_4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tabx5 = New System.Windows.Forms.TabPage()
        Me.cmdDeleteComment = New System.Windows.Forms.Button()
        Me.cmdAddComment = New System.Windows.Forms.Button()
        Me.txtComments = New System.Windows.Forms.TextBox()
        Me.lblComments = New System.Windows.Forms.Label()
        Me.grdComments = New System.Windows.Forms.DataGridView()
        Me.COMMENT_6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.COMMENT_DATE_6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CREATED_BY_6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SEQUENCE_6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EMPLOYEE_ID_6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.frmViews.SuspendLayout()
        Me.tbSearch.SuspendLayout()
        Me.gbSearchBy.SuspendLayout()
        Me.tbMajorMinor.SuspendLayout()
        Me.tbExpired.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdFlags, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.fmDMVInfo.SuspendLayout()
        CType(Me.grdSearch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.tabInformation.SuspendLayout()
        Me.tabx1.SuspendLayout()
        CType(Me.grdMisc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdSuspensions, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdViolations, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabx2.SuspendLayout()
        CType(Me.grdAKA, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabx5.SuspendLayout()
        CType(Me.grdComments, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'frmViews
        '
        Me.frmViews.Controls.Add(Me.tbSearch)
        Me.frmViews.Controls.Add(Me.tbMajorMinor)
        Me.frmViews.Controls.Add(Me.tbExpired)
        Me.frmViews.Location = New System.Drawing.Point(12, 12)
        Me.frmViews.Name = "frmViews"
        Me.frmViews.SelectedIndex = 0
        Me.frmViews.Size = New System.Drawing.Size(399, 201)
        Me.frmViews.TabIndex = 3
        '
        'tbSearch
        '
        Me.tbSearch.BackColor = System.Drawing.Color.White
        Me.tbSearch.Controls.Add(Me.gbSearchBy)
        Me.tbSearch.Controls.Add(Me.cmdUnsigned)
        Me.tbSearch.Controls.Add(Me.lblRecordCount1)
        Me.tbSearch.Controls.Add(Me.txtInput2)
        Me.tbSearch.Controls.Add(Me.txtInput1)
        Me.tbSearch.Controls.Add(Me.chkSoundLike)
        Me.tbSearch.Controls.Add(Me.Label3)
        Me.tbSearch.Controls.Add(Me.listStatus)
        Me.tbSearch.Controls.Add(Me.ListCompany1)
        Me.tbSearch.Controls.Add(Me.cmdGo)
        Me.tbSearch.Controls.Add(Me.lblInput2)
        Me.tbSearch.Controls.Add(Me.lblInput1)
        Me.tbSearch.Location = New System.Drawing.Point(4, 22)
        Me.tbSearch.Name = "tbSearch"
        Me.tbSearch.Padding = New System.Windows.Forms.Padding(3)
        Me.tbSearch.Size = New System.Drawing.Size(391, 175)
        Me.tbSearch.TabIndex = 0
        Me.tbSearch.Text = "Search"
        '
        'gbSearchBy
        '
        Me.gbSearchBy.Controls.Add(Me.optView3)
        Me.gbSearchBy.Controls.Add(Me.optView2)
        Me.gbSearchBy.Controls.Add(Me.optView1)
        Me.gbSearchBy.Location = New System.Drawing.Point(5, 11)
        Me.gbSearchBy.Name = "gbSearchBy"
        Me.gbSearchBy.Size = New System.Drawing.Size(248, 49)
        Me.gbSearchBy.TabIndex = 18
        Me.gbSearchBy.TabStop = False
        Me.gbSearchBy.Text = "Search By"
        '
        'optView3
        '
        Me.optView3.Appearance = System.Windows.Forms.Appearance.Button
        Me.optView3.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ScrollBar
        Me.optView3.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.optView3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.optView3.Location = New System.Drawing.Point(163, 19)
        Me.optView3.Name = "optView3"
        Me.optView3.Size = New System.Drawing.Size(72, 23)
        Me.optView3.TabIndex = 5
        Me.optView3.Text = "Badge"
        Me.optView3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optView3.UseVisualStyleBackColor = True
        '
        'optView2
        '
        Me.optView2.Appearance = System.Windows.Forms.Appearance.Button
        Me.optView2.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ScrollBar
        Me.optView2.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.optView2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.optView2.Location = New System.Drawing.Point(85, 19)
        Me.optView2.Name = "optView2"
        Me.optView2.Size = New System.Drawing.Size(72, 23)
        Me.optView2.TabIndex = 4
        Me.optView2.Text = "First"
        Me.optView2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optView2.UseVisualStyleBackColor = True
        '
        'optView1
        '
        Me.optView1.Appearance = System.Windows.Forms.Appearance.Button
        Me.optView1.Checked = True
        Me.optView1.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ScrollBar
        Me.optView1.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.optView1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.optView1.Location = New System.Drawing.Point(7, 19)
        Me.optView1.Name = "optView1"
        Me.optView1.Size = New System.Drawing.Size(72, 23)
        Me.optView1.TabIndex = 3
        Me.optView1.TabStop = True
        Me.optView1.Text = "Last"
        Me.optView1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optView1.UseVisualStyleBackColor = True
        '
        'cmdUnsigned
        '
        Me.cmdUnsigned.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdUnsigned.Location = New System.Drawing.Point(259, 28)
        Me.cmdUnsigned.Name = "cmdUnsigned"
        Me.cmdUnsigned.Size = New System.Drawing.Size(103, 26)
        Me.cmdUnsigned.TabIndex = 16
        Me.cmdUnsigned.Text = "Needs Signature"
        Me.cmdUnsigned.UseVisualStyleBackColor = True
        '
        'lblRecordCount1
        '
        Me.lblRecordCount1.AutoSize = True
        Me.lblRecordCount1.ForeColor = System.Drawing.Color.SteelBlue
        Me.lblRecordCount1.Location = New System.Drawing.Point(3, 155)
        Me.lblRecordCount1.Name = "lblRecordCount1"
        Me.lblRecordCount1.Size = New System.Drawing.Size(73, 13)
        Me.lblRecordCount1.TabIndex = 14
        Me.lblRecordCount1.Text = "Record Count"
        '
        'txtInput2
        '
        Me.txtInput2.Location = New System.Drawing.Point(129, 82)
        Me.txtInput2.Name = "txtInput2"
        Me.txtInput2.Size = New System.Drawing.Size(114, 20)
        Me.txtInput2.TabIndex = 13
        '
        'txtInput1
        '
        Me.txtInput1.Location = New System.Drawing.Point(15, 82)
        Me.txtInput1.Name = "txtInput1"
        Me.txtInput1.Size = New System.Drawing.Size(108, 20)
        Me.txtInput1.TabIndex = 0
        '
        'chkSoundLike
        '
        Me.chkSoundLike.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkSoundLike.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chkSoundLike.Location = New System.Drawing.Point(259, 80)
        Me.chkSoundLike.Name = "chkSoundLike"
        Me.chkSoundLike.Size = New System.Drawing.Size(103, 23)
        Me.chkSoundLike.TabIndex = 11
        Me.chkSoundLike.Text = "Sounds Like"
        Me.chkSoundLike.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chkSoundLike.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 120)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 13)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Base"
        '
        'listStatus
        '
        Me.listStatus.FormattingEnabled = True
        Me.listStatus.Location = New System.Drawing.Point(249, 117)
        Me.listStatus.Name = "listStatus"
        Me.listStatus.Size = New System.Drawing.Size(14, 21)
        Me.listStatus.TabIndex = 9
        Me.listStatus.Visible = False
        '
        'ListCompany1
        '
        Me.ListCompany1.FormattingEnabled = True
        Me.ListCompany1.Items.AddRange(New Object() {"GG", "SA", "AN", "Admin", "Maint", "Annex"})
        Me.ListCompany1.Location = New System.Drawing.Point(49, 117)
        Me.ListCompany1.Name = "ListCompany1"
        Me.ListCompany1.Size = New System.Drawing.Size(74, 21)
        Me.ListCompany1.TabIndex = 8
        '
        'cmdGo
        '
        Me.cmdGo.Image = CType(resources.GetObject("cmdGo.Image"), System.Drawing.Image)
        Me.cmdGo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdGo.Location = New System.Drawing.Point(129, 115)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(114, 23)
        Me.cmdGo.TabIndex = 7
        Me.cmdGo.Text = "Search"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'lblInput2
        '
        Me.lblInput2.AutoSize = True
        Me.lblInput2.Location = New System.Drawing.Point(126, 68)
        Me.lblInput2.Name = "lblInput2"
        Me.lblInput2.Size = New System.Drawing.Size(57, 13)
        Me.lblInput2.TabIndex = 6
        Me.lblInput2.Text = "First Name"
        '
        'lblInput1
        '
        Me.lblInput1.AutoSize = True
        Me.lblInput1.Location = New System.Drawing.Point(14, 68)
        Me.lblInput1.Name = "lblInput1"
        Me.lblInput1.Size = New System.Drawing.Size(58, 13)
        Me.lblInput1.TabIndex = 5
        Me.lblInput1.Text = "Last Name"
        '
        'tbMajorMinor
        '
        Me.tbMajorMinor.BackColor = System.Drawing.Color.White
        Me.tbMajorMinor.Controls.Add(Me.lblRecordCount2)
        Me.tbMajorMinor.Controls.Add(Me.cmdExcel1)
        Me.tbMajorMinor.Controls.Add(Me.listStatus2)
        Me.tbMajorMinor.Controls.Add(Me.lblOrderDate)
        Me.tbMajorMinor.Controls.Add(Me.txtOrderDate)
        Me.tbMajorMinor.Controls.Add(Me.Label2)
        Me.tbMajorMinor.Controls.Add(Me.cmbSearch)
        Me.tbMajorMinor.Controls.Add(Me.cmdMajorMinorSearch)
        Me.tbMajorMinor.Controls.Add(Me.Label1)
        Me.tbMajorMinor.Controls.Add(Me.optMajorMinor3)
        Me.tbMajorMinor.Controls.Add(Me.optMajorMinor2)
        Me.tbMajorMinor.Controls.Add(Me.optMajorMinor1)
        Me.tbMajorMinor.Controls.Add(Me.ListCompany2)
        Me.tbMajorMinor.Controls.Add(Me.GroupBox1)
        Me.tbMajorMinor.Location = New System.Drawing.Point(4, 22)
        Me.tbMajorMinor.Name = "tbMajorMinor"
        Me.tbMajorMinor.Padding = New System.Windows.Forms.Padding(3)
        Me.tbMajorMinor.Size = New System.Drawing.Size(391, 175)
        Me.tbMajorMinor.TabIndex = 1
        Me.tbMajorMinor.Text = "Major/Minor"
        '
        'lblRecordCount2
        '
        Me.lblRecordCount2.AutoSize = True
        Me.lblRecordCount2.ForeColor = System.Drawing.Color.SteelBlue
        Me.lblRecordCount2.Location = New System.Drawing.Point(2, 159)
        Me.lblRecordCount2.Name = "lblRecordCount2"
        Me.lblRecordCount2.Size = New System.Drawing.Size(73, 13)
        Me.lblRecordCount2.TabIndex = 28
        Me.lblRecordCount2.Text = "Record Count"
        '
        'cmdExcel1
        '
        Me.cmdExcel1.Location = New System.Drawing.Point(135, 125)
        Me.cmdExcel1.Name = "cmdExcel1"
        Me.cmdExcel1.Size = New System.Drawing.Size(108, 23)
        Me.cmdExcel1.TabIndex = 27
        Me.cmdExcel1.Text = "Export to Excel"
        Me.cmdExcel1.UseVisualStyleBackColor = True
        '
        'listStatus2
        '
        Me.listStatus2.FormattingEnabled = True
        Me.listStatus2.Location = New System.Drawing.Point(259, 42)
        Me.listStatus2.Name = "listStatus2"
        Me.listStatus2.Size = New System.Drawing.Size(14, 21)
        Me.listStatus2.TabIndex = 26
        Me.listStatus2.Visible = False
        '
        'lblOrderDate
        '
        Me.lblOrderDate.AutoSize = True
        Me.lblOrderDate.Location = New System.Drawing.Point(132, 99)
        Me.lblOrderDate.Name = "lblOrderDate"
        Me.lblOrderDate.Size = New System.Drawing.Size(68, 13)
        Me.lblOrderDate.TabIndex = 25
        Me.lblOrderDate.Text = "Order Date >"
        Me.lblOrderDate.Visible = False
        '
        'txtOrderDate
        '
        Me.txtOrderDate.Location = New System.Drawing.Point(201, 96)
        Me.txtOrderDate.Name = "txtOrderDate"
        Me.txtOrderDate.Size = New System.Drawing.Size(41, 20)
        Me.txtOrderDate.TabIndex = 24
        Me.txtOrderDate.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Type"
        '
        'cmbSearch
        '
        Me.cmbSearch.FormattingEnabled = True
        Me.cmbSearch.Location = New System.Drawing.Point(50, 69)
        Me.cmbSearch.Name = "cmbSearch"
        Me.cmbSearch.Size = New System.Drawing.Size(193, 21)
        Me.cmbSearch.TabIndex = 22
        '
        'cmdMajorMinorSearch
        '
        Me.cmdMajorMinorSearch.Image = CType(resources.GetObject("cmdMajorMinorSearch.Image"), System.Drawing.Image)
        Me.cmdMajorMinorSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdMajorMinorSearch.Location = New System.Drawing.Point(15, 125)
        Me.cmdMajorMinorSearch.Name = "cmdMajorMinorSearch"
        Me.cmdMajorMinorSearch.Size = New System.Drawing.Size(114, 23)
        Me.cmdMajorMinorSearch.TabIndex = 21
        Me.cmdMajorMinorSearch.Text = "Search"
        Me.cmdMajorMinorSearch.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 99)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(31, 13)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Base"
        '
        'optMajorMinor3
        '
        Me.optMajorMinor3.Appearance = System.Windows.Forms.Appearance.Button
        Me.optMajorMinor3.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ScrollBar
        Me.optMajorMinor3.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.optMajorMinor3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.optMajorMinor3.Location = New System.Drawing.Point(171, 31)
        Me.optMajorMinor3.Name = "optMajorMinor3"
        Me.optMajorMinor3.Size = New System.Drawing.Size(72, 23)
        Me.optMajorMinor3.TabIndex = 5
        Me.optMajorMinor3.Text = "Minor"
        Me.optMajorMinor3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optMajorMinor3.UseVisualStyleBackColor = True
        '
        'optMajorMinor2
        '
        Me.optMajorMinor2.Appearance = System.Windows.Forms.Appearance.Button
        Me.optMajorMinor2.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ScrollBar
        Me.optMajorMinor2.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.optMajorMinor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.optMajorMinor2.Location = New System.Drawing.Point(93, 31)
        Me.optMajorMinor2.Name = "optMajorMinor2"
        Me.optMajorMinor2.Size = New System.Drawing.Size(72, 23)
        Me.optMajorMinor2.TabIndex = 4
        Me.optMajorMinor2.Text = "Major"
        Me.optMajorMinor2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optMajorMinor2.UseVisualStyleBackColor = True
        '
        'optMajorMinor1
        '
        Me.optMajorMinor1.Appearance = System.Windows.Forms.Appearance.Button
        Me.optMajorMinor1.Checked = True
        Me.optMajorMinor1.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ScrollBar
        Me.optMajorMinor1.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.optMajorMinor1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.optMajorMinor1.Location = New System.Drawing.Point(15, 31)
        Me.optMajorMinor1.Name = "optMajorMinor1"
        Me.optMajorMinor1.Size = New System.Drawing.Size(72, 23)
        Me.optMajorMinor1.TabIndex = 3
        Me.optMajorMinor1.TabStop = True
        Me.optMajorMinor1.Text = "All"
        Me.optMajorMinor1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.optMajorMinor1.UseVisualStyleBackColor = True
        '
        'ListCompany2
        '
        Me.ListCompany2.FormattingEnabled = True
        Me.ListCompany2.Items.AddRange(New Object() {"GG", "SA", "AN", "Admin", "Maint", "Annex"})
        Me.ListCompany2.Location = New System.Drawing.Point(49, 96)
        Me.ListCompany2.Name = "ListCompany2"
        Me.ListCompany2.Size = New System.Drawing.Size(80, 21)
        Me.ListCompany2.TabIndex = 9
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(5, 14)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(248, 49)
        Me.GroupBox1.TabIndex = 19
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Major/Minor"
        '
        'tbExpired
        '
        Me.tbExpired.BackColor = System.Drawing.Color.White
        Me.tbExpired.Controls.Add(Me.Label12)
        Me.tbExpired.Controls.Add(Me.Button4)
        Me.tbExpired.Controls.Add(Me.cmdExcel2)
        Me.tbExpired.Controls.Add(Me.cmdExpired)
        Me.tbExpired.Controls.Add(Me.Label5)
        Me.tbExpired.Controls.Add(Me.txtExpiredDays)
        Me.tbExpired.Controls.Add(Me.Label4)
        Me.tbExpired.Controls.Add(Me.ListCompany3)
        Me.tbExpired.Controls.Add(Me.listStatus3)
        Me.tbExpired.Controls.Add(Me.GroupBox2)
        Me.tbExpired.Controls.Add(Me.lblRecordCount3)
        Me.tbExpired.Location = New System.Drawing.Point(4, 22)
        Me.tbExpired.Name = "tbExpired"
        Me.tbExpired.Padding = New System.Windows.Forms.Padding(3)
        Me.tbExpired.Size = New System.Drawing.Size(391, 175)
        Me.tbExpired.TabIndex = 2
        Me.tbExpired.Text = "Expired"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(330, 80)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(31, 13)
        Me.Label12.TabIndex = 42
        Me.Label12.Text = "Days"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(250, 115)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(108, 23)
        Me.Button4.TabIndex = 41
        Me.Button4.Text = "Letter"
        Me.Button4.UseVisualStyleBackColor = True
        Me.Button4.Visible = False
        '
        'cmdExcel2
        '
        Me.cmdExcel2.Location = New System.Drawing.Point(136, 115)
        Me.cmdExcel2.Name = "cmdExcel2"
        Me.cmdExcel2.Size = New System.Drawing.Size(108, 23)
        Me.cmdExcel2.TabIndex = 40
        Me.cmdExcel2.Text = "Export to Excel"
        Me.cmdExcel2.UseVisualStyleBackColor = True
        '
        'cmdExpired
        '
        Me.cmdExpired.Image = CType(resources.GetObject("cmdExpired.Image"), System.Drawing.Image)
        Me.cmdExpired.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdExpired.Location = New System.Drawing.Point(16, 115)
        Me.cmdExpired.Name = "cmdExpired"
        Me.cmdExpired.Size = New System.Drawing.Size(114, 23)
        Me.cmdExpired.TabIndex = 39
        Me.cmdExpired.Text = "Search"
        Me.cmdExpired.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(168, 80)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 13)
        Me.Label5.TabIndex = 38
        Me.Label5.Text = "Future Expiration"
        '
        'txtExpiredDays
        '
        Me.txtExpiredDays.Location = New System.Drawing.Point(257, 77)
        Me.txtExpiredDays.Name = "txtExpiredDays"
        Me.txtExpiredDays.Size = New System.Drawing.Size(66, 20)
        Me.txtExpiredDays.TabIndex = 37
        Me.txtExpiredDays.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 79)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 13)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "Base"
        '
        'ListCompany3
        '
        Me.ListCompany3.FormattingEnabled = True
        Me.ListCompany3.Items.AddRange(New Object() {"GG", "SA", "AN", "Admin", "Maint", "Annex"})
        Me.ListCompany3.Location = New System.Drawing.Point(54, 76)
        Me.ListCompany3.Name = "ListCompany3"
        Me.ListCompany3.Size = New System.Drawing.Size(96, 21)
        Me.ListCompany3.TabIndex = 35
        '
        'listStatus3
        '
        Me.listStatus3.FormattingEnabled = True
        Me.listStatus3.Location = New System.Drawing.Point(370, 30)
        Me.listStatus3.Name = "listStatus3"
        Me.listStatus3.Size = New System.Drawing.Size(14, 21)
        Me.listStatus3.TabIndex = 34
        Me.listStatus3.Visible = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.optFutureSearch4)
        Me.GroupBox2.Controls.Add(Me.optFutureSearch1)
        Me.GroupBox2.Controls.Add(Me.optFutureSearch3)
        Me.GroupBox2.Controls.Add(Me.optFutureSearch2)
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox2.Location = New System.Drawing.Point(6, 11)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(358, 49)
        Me.GroupBox2.TabIndex = 33
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Expired"
        '
        'optFutureSearch4
        '
        Me.optFutureSearch4.Appearance = System.Windows.Forms.Appearance.Button
        Me.optFutureSearch4.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ScrollBar
        Me.optFutureSearch4.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.optFutureSearch4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.optFutureSearch4.Location = New System.Drawing.Point(269, 15)
        Me.optFutureSearch4.Name = "optFutureSearch4"
        Me.optFutureSearch4.Size = New System.Drawing.Size(79, 25)
        Me.optFutureSearch4.TabIndex = 45
        Me.optFutureSearch4.TabStop = True
        Me.optFutureSearch4.Text = "Record Exp"
        Me.optFutureSearch4.UseVisualStyleBackColor = True
        '
        'optFutureSearch1
        '
        Me.optFutureSearch1.Appearance = System.Windows.Forms.Appearance.Button
        Me.optFutureSearch1.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ScrollBar
        Me.optFutureSearch1.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.optFutureSearch1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.optFutureSearch1.Location = New System.Drawing.Point(14, 15)
        Me.optFutureSearch1.Name = "optFutureSearch1"
        Me.optFutureSearch1.Size = New System.Drawing.Size(79, 25)
        Me.optFutureSearch1.TabIndex = 42
        Me.optFutureSearch1.TabStop = True
        Me.optFutureSearch1.Text = "CDL Exp"
        Me.optFutureSearch1.UseVisualStyleBackColor = True
        '
        'optFutureSearch3
        '
        Me.optFutureSearch3.Appearance = System.Windows.Forms.Appearance.Button
        Me.optFutureSearch3.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ScrollBar
        Me.optFutureSearch3.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.optFutureSearch3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.optFutureSearch3.Location = New System.Drawing.Point(184, 15)
        Me.optFutureSearch3.Name = "optFutureSearch3"
        Me.optFutureSearch3.Size = New System.Drawing.Size(79, 25)
        Me.optFutureSearch3.TabIndex = 44
        Me.optFutureSearch3.TabStop = True
        Me.optFutureSearch3.Text = "VTT Exp"
        Me.optFutureSearch3.UseVisualStyleBackColor = True
        '
        'optFutureSearch2
        '
        Me.optFutureSearch2.Appearance = System.Windows.Forms.Appearance.Button
        Me.optFutureSearch2.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ScrollBar
        Me.optFutureSearch2.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.optFutureSearch2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.optFutureSearch2.Location = New System.Drawing.Point(99, 15)
        Me.optFutureSearch2.Name = "optFutureSearch2"
        Me.optFutureSearch2.Size = New System.Drawing.Size(79, 25)
        Me.optFutureSearch2.TabIndex = 43
        Me.optFutureSearch2.TabStop = True
        Me.optFutureSearch2.Text = "Med Card Exp"
        Me.optFutureSearch2.UseVisualStyleBackColor = True
        '
        'lblRecordCount3
        '
        Me.lblRecordCount3.AutoSize = True
        Me.lblRecordCount3.ForeColor = System.Drawing.Color.SteelBlue
        Me.lblRecordCount3.Location = New System.Drawing.Point(6, 159)
        Me.lblRecordCount3.Name = "lblRecordCount3"
        Me.lblRecordCount3.Size = New System.Drawing.Size(73, 13)
        Me.lblRecordCount3.TabIndex = 29
        Me.lblRecordCount3.Text = "Record Count"
        '
        'grdFlags
        '
        Me.grdFlags.AllowUserToAddRows = False
        Me.grdFlags.AllowUserToDeleteRows = False
        Me.grdFlags.AllowUserToOrderColumns = True
        Me.grdFlags.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        Me.grdFlags.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdFlags.CausesValidation = False
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdFlags.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.grdFlags.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.MESSAGE, Me.Flag_Name, Me.Major_Minor, Me.EMPLOYEE_ID})
        Me.grdFlags.Location = New System.Drawing.Point(12, 733)
        Me.grdFlags.Name = "grdFlags"
        Me.grdFlags.ReadOnly = True
        Me.grdFlags.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdFlags.Size = New System.Drawing.Size(700, 200)
        Me.grdFlags.TabIndex = 4
        '
        'MESSAGE
        '
        Me.MESSAGE.HeaderText = "MESSAGE"
        Me.MESSAGE.Name = "MESSAGE"
        Me.MESSAGE.ReadOnly = True
        Me.MESSAGE.Width = 350
        '
        'Flag_Name
        '
        Me.Flag_Name.HeaderText = "FLAG NAME"
        Me.Flag_Name.Name = "Flag_Name"
        Me.Flag_Name.ReadOnly = True
        Me.Flag_Name.Width = 175
        '
        'Major_Minor
        '
        Me.Major_Minor.HeaderText = "MAJOR/MINOR"
        Me.Major_Minor.Name = "Major_Minor"
        Me.Major_Minor.ReadOnly = True
        Me.Major_Minor.Width = 120
        '
        'EMPLOYEE_ID
        '
        Me.EMPLOYEE_ID.HeaderText = "EMPLOYEE_ID"
        Me.EMPLOYEE_ID.Name = "EMPLOYEE_ID"
        Me.EMPLOYEE_ID.ReadOnly = True
        Me.EMPLOYEE_ID.Visible = False
        Me.EMPLOYEE_ID.Width = 5
        '
        'lblFlagRecords
        '
        Me.lblFlagRecords.ForeColor = System.Drawing.Color.SteelBlue
        Me.lblFlagRecords.Location = New System.Drawing.Point(12, 699)
        Me.lblFlagRecords.Name = "lblFlagRecords"
        Me.lblFlagRecords.Size = New System.Drawing.Size(700, 31)
        Me.lblFlagRecords.TabIndex = 5
        Me.lblFlagRecords.Text = "Flag Records"
        Me.lblFlagRecords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblFlagRecords.Visible = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.GroupBox3)
        Me.Panel1.Location = New System.Drawing.Point(411, 33)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(300, 179)
        Me.Panel1.TabIndex = 42
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtHR6)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.txtHR5)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.txtHR4)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.txtHR3)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.txtHR2)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.txtHR1)
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox3.Location = New System.Drawing.Point(47, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(250, 159)
        Me.GroupBox3.TabIndex = 10
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "HR Information"
        '
        'txtHR6
        '
        Me.txtHR6.Location = New System.Drawing.Point(114, 124)
        Me.txtHR6.Name = "txtHR6"
        Me.txtHR6.Size = New System.Drawing.Size(123, 20)
        Me.txtHR6.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(18, 125)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(61, 19)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Location:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtHR5
        '
        Me.txtHR5.Location = New System.Drawing.Point(79, 124)
        Me.txtHR5.Name = "txtHR5"
        Me.txtHR5.Size = New System.Drawing.Size(29, 20)
        Me.txtHR5.TabIndex = 8
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(18, 83)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 19)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Job Title:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtHR4
        '
        Me.txtHR4.Location = New System.Drawing.Point(79, 83)
        Me.txtHR4.Multiline = True
        Me.txtHR4.Name = "txtHR4"
        Me.txtHR4.Size = New System.Drawing.Size(158, 40)
        Me.txtHR4.TabIndex = 6
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(18, 60)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 19)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "Status:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtHR3
        '
        Me.txtHR3.Location = New System.Drawing.Point(79, 62)
        Me.txtHR3.Name = "txtHR3"
        Me.txtHR3.Size = New System.Drawing.Size(158, 20)
        Me.txtHR3.TabIndex = 4
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(18, 40)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(61, 19)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "Name:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtHR2
        '
        Me.txtHR2.Location = New System.Drawing.Point(79, 42)
        Me.txtHR2.Name = "txtHR2"
        Me.txtHR2.Size = New System.Drawing.Size(158, 20)
        Me.txtHR2.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(18, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 19)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Badge:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtHR1
        '
        Me.txtHR1.Location = New System.Drawing.Point(79, 20)
        Me.txtHR1.Name = "txtHR1"
        Me.txtHR1.Size = New System.Drawing.Size(158, 20)
        Me.txtHR1.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.fmDMVInfo)
        Me.Panel2.Location = New System.Drawing.Point(3, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(526, 171)
        Me.Panel2.TabIndex = 43
        '
        'fmDMVInfo
        '
        Me.fmDMVInfo.Controls.Add(Me.Label16)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV12)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV14)
        Me.fmDMVInfo.Controls.Add(Me.Label17)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV13)
        Me.fmDMVInfo.Controls.Add(Me.Label18)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV11)
        Me.fmDMVInfo.Controls.Add(Me.Label19)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV10)
        Me.fmDMVInfo.Controls.Add(Me.Label20)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV9)
        Me.fmDMVInfo.Controls.Add(Me.Label21)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV8)
        Me.fmDMVInfo.Controls.Add(Me.Label22)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV5)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV7)
        Me.fmDMVInfo.Controls.Add(Me.Label11)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV6)
        Me.fmDMVInfo.Controls.Add(Me.lblCDLExpDate)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV4)
        Me.fmDMVInfo.Controls.Add(Me.lblMedicalCard)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV3)
        Me.fmDMVInfo.Controls.Add(Me.lblVTTExpDate)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV2)
        Me.fmDMVInfo.Controls.Add(Me.Label15)
        Me.fmDMVInfo.Controls.Add(Me.txtDMV1)
        Me.fmDMVInfo.Location = New System.Drawing.Point(5, 11)
        Me.fmDMVInfo.Name = "fmDMVInfo"
        Me.fmDMVInfo.Size = New System.Drawing.Size(496, 159)
        Me.fmDMVInfo.TabIndex = 10
        Me.fmDMVInfo.TabStop = False
        Me.fmDMVInfo.Text = "DMV Information"
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(263, 104)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(61, 19)
        Me.Label16.TabIndex = 47
        Me.Label16.Text = "Gender:"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV12
        '
        Me.txtDMV12.Location = New System.Drawing.Point(327, 104)
        Me.txtDMV12.Name = "txtDMV12"
        Me.txtDMV12.Size = New System.Drawing.Size(158, 20)
        Me.txtDMV12.TabIndex = 46
        '
        'txtDMV14
        '
        Me.txtDMV14.Location = New System.Drawing.Point(410, 125)
        Me.txtDMV14.Name = "txtDMV14"
        Me.txtDMV14.Size = New System.Drawing.Size(75, 20)
        Me.txtDMV14.TabIndex = 45
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(263, 125)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(61, 19)
        Me.Label17.TabIndex = 44
        Me.Label17.Text = "Hair/Eyes:"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV13
        '
        Me.txtDMV13.Location = New System.Drawing.Point(327, 125)
        Me.txtDMV13.Name = "txtDMV13"
        Me.txtDMV13.Size = New System.Drawing.Size(75, 20)
        Me.txtDMV13.TabIndex = 43
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(251, 83)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(73, 19)
        Me.Label18.TabIndex = 42
        Me.Label18.Text = "Record Date:"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV11
        '
        Me.txtDMV11.Location = New System.Drawing.Point(327, 83)
        Me.txtDMV11.Name = "txtDMV11"
        Me.txtDMV11.Size = New System.Drawing.Size(158, 20)
        Me.txtDMV11.TabIndex = 41
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(263, 62)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(61, 19)
        Me.Label19.TabIndex = 40
        Me.Label19.Text = "Pt Count:"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV10
        '
        Me.txtDMV10.Location = New System.Drawing.Point(327, 62)
        Me.txtDMV10.Name = "txtDMV10"
        Me.txtDMV10.Size = New System.Drawing.Size(158, 20)
        Me.txtDMV10.TabIndex = 39
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(253, 41)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(71, 19)
        Me.Label20.TabIndex = 38
        Me.Label20.Text = "Commercial:"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV9
        '
        Me.txtDMV9.Location = New System.Drawing.Point(327, 41)
        Me.txtDMV9.Name = "txtDMV9"
        Me.txtDMV9.Size = New System.Drawing.Size(158, 20)
        Me.txtDMV9.TabIndex = 37
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(263, 20)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(61, 19)
        Me.Label21.TabIndex = 36
        Me.Label21.Text = "Class:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV8
        '
        Me.txtDMV8.Location = New System.Drawing.Point(327, 20)
        Me.txtDMV8.Name = "txtDMV8"
        Me.txtDMV8.Size = New System.Drawing.Size(158, 20)
        Me.txtDMV8.TabIndex = 35
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(25, 104)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(61, 19)
        Me.Label22.TabIndex = 34
        Me.Label22.Text = "Birth Date:"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV5
        '
        Me.txtDMV5.Location = New System.Drawing.Point(89, 104)
        Me.txtDMV5.Name = "txtDMV5"
        Me.txtDMV5.Size = New System.Drawing.Size(158, 20)
        Me.txtDMV5.TabIndex = 33
        '
        'txtDMV7
        '
        Me.txtDMV7.Location = New System.Drawing.Point(172, 125)
        Me.txtDMV7.Name = "txtDMV7"
        Me.txtDMV7.Size = New System.Drawing.Size(75, 20)
        Me.txtDMV7.TabIndex = 21
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(3, 125)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 19)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Weight/Height:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV6
        '
        Me.txtDMV6.Location = New System.Drawing.Point(89, 125)
        Me.txtDMV6.Name = "txtDMV6"
        Me.txtDMV6.Size = New System.Drawing.Size(75, 20)
        Me.txtDMV6.TabIndex = 19
        '
        'lblCDLExpDate
        '
        Me.lblCDLExpDate.Location = New System.Drawing.Point(6, 83)
        Me.lblCDLExpDate.Name = "lblCDLExpDate"
        Me.lblCDLExpDate.Size = New System.Drawing.Size(80, 19)
        Me.lblCDLExpDate.TabIndex = 18
        Me.lblCDLExpDate.Text = "CDL Exp Date:"
        Me.lblCDLExpDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV4
        '
        Me.txtDMV4.Location = New System.Drawing.Point(89, 83)
        Me.txtDMV4.Name = "txtDMV4"
        Me.txtDMV4.Size = New System.Drawing.Size(158, 20)
        Me.txtDMV4.TabIndex = 17
        '
        'lblMedicalCard
        '
        Me.lblMedicalCard.Location = New System.Drawing.Point(9, 62)
        Me.lblMedicalCard.Name = "lblMedicalCard"
        Me.lblMedicalCard.Size = New System.Drawing.Size(77, 19)
        Me.lblMedicalCard.TabIndex = 16
        Me.lblMedicalCard.Text = "Med Card:"
        Me.lblMedicalCard.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV3
        '
        Me.txtDMV3.Location = New System.Drawing.Point(89, 62)
        Me.txtDMV3.Name = "txtDMV3"
        Me.txtDMV3.Size = New System.Drawing.Size(158, 20)
        Me.txtDMV3.TabIndex = 15
        '
        'lblVTTExpDate
        '
        Me.lblVTTExpDate.Location = New System.Drawing.Point(2, 41)
        Me.lblVTTExpDate.Name = "lblVTTExpDate"
        Me.lblVTTExpDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblVTTExpDate.Size = New System.Drawing.Size(84, 19)
        Me.lblVTTExpDate.TabIndex = 14
        Me.lblVTTExpDate.Text = "VTT Exp. Date:"
        Me.lblVTTExpDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV2
        '
        Me.txtDMV2.Location = New System.Drawing.Point(89, 41)
        Me.txtDMV2.Name = "txtDMV2"
        Me.txtDMV2.Size = New System.Drawing.Size(158, 20)
        Me.txtDMV2.TabIndex = 13
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(25, 20)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(61, 19)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "CDL:"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDMV1
        '
        Me.txtDMV1.Location = New System.Drawing.Point(89, 20)
        Me.txtDMV1.Name = "txtDMV1"
        Me.txtDMV1.Size = New System.Drawing.Size(158, 20)
        Me.txtDMV1.TabIndex = 11
        '
        'txtSignature
        '
        Me.txtSignature.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSignature.Location = New System.Drawing.Point(4, 3)
        Me.txtSignature.Multiline = True
        Me.txtSignature.Name = "txtSignature"
        Me.txtSignature.Size = New System.Drawing.Size(359, 23)
        Me.txtSignature.TabIndex = 45
        Me.txtSignature.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblExpiredMessage
        '
        Me.lblExpiredMessage.BackColor = System.Drawing.Color.Red
        Me.lblExpiredMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblExpiredMessage.ForeColor = System.Drawing.Color.Yellow
        Me.lblExpiredMessage.Location = New System.Drawing.Point(4, 33)
        Me.lblExpiredMessage.Name = "lblExpiredMessage"
        Me.lblExpiredMessage.Size = New System.Drawing.Size(359, 20)
        Me.lblExpiredMessage.TabIndex = 46
        Me.lblExpiredMessage.Text = "This Record has Expired!"
        Me.lblExpiredMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblExpiredMessage.Visible = False
        '
        'cmdSignature
        '
        Me.cmdSignature.Location = New System.Drawing.Point(369, 3)
        Me.cmdSignature.Name = "cmdSignature"
        Me.cmdSignature.Size = New System.Drawing.Size(124, 23)
        Me.cmdSignature.TabIndex = 47
        Me.cmdSignature.Text = "Click to S&ign Record"
        Me.cmdSignature.UseVisualStyleBackColor = True
        '
        'EMPLOYEE_ID_5
        '
        Me.EMPLOYEE_ID_5.HeaderText = "EMPLOYEE_ID"
        Me.EMPLOYEE_ID_5.Name = "EMPLOYEE_ID_5"
        Me.EMPLOYEE_ID_5.ReadOnly = True
        Me.EMPLOYEE_ID_5.Visible = False
        Me.EMPLOYEE_ID_5.Width = 5
        '
        'SEQUENCE_5
        '
        Me.SEQUENCE_5.HeaderText = "SEQ"
        Me.SEQUENCE_5.Name = "SEQUENCE_5"
        Me.SEQUENCE_5.ReadOnly = True
        '
        'CREATION_DATE_5
        '
        Me.CREATION_DATE_5.HeaderText = "CREATION DATE"
        Me.CREATION_DATE_5.Name = "CREATION_DATE_5"
        Me.CREATION_DATE_5.ReadOnly = True
        Me.CREATION_DATE_5.Width = 150
        '
        'CREATED_BY_5
        '
        Me.CREATED_BY_5.HeaderText = "CREATED BY"
        Me.CREATED_BY_5.Name = "CREATED_BY_5"
        Me.CREATED_BY_5.ReadOnly = True
        Me.CREATED_BY_5.Width = 150
        '
        'ADDRESS
        '
        Me.ADDRESS.HeaderText = "ADDRESS"
        Me.ADDRESS.Name = "ADDRESS"
        Me.ADDRESS.ReadOnly = True
        Me.ADDRESS.Width = 300
        '
        'cmdPrintScreen
        '
        Me.cmdPrintScreen.Location = New System.Drawing.Point(369, 33)
        Me.cmdPrintScreen.Name = "cmdPrintScreen"
        Me.cmdPrintScreen.Size = New System.Drawing.Size(124, 25)
        Me.cmdPrintScreen.TabIndex = 48
        Me.cmdPrintScreen.Text = "Print Screen"
        Me.cmdPrintScreen.UseVisualStyleBackColor = True
        '
        'grdSearch
        '
        Me.grdSearch.AllowUserToAddRows = False
        Me.grdSearch.AllowUserToDeleteRows = False
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        Me.grdSearch.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle3
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.SteelBlue
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdSearch.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.grdSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdSearch.Location = New System.Drawing.Point(12, 220)
        Me.grdSearch.MultiSelect = False
        Me.grdSearch.Name = "grdSearch"
        Me.grdSearch.ReadOnly = True
        Me.grdSearch.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdSearch.Size = New System.Drawing.Size(700, 476)
        Me.grdSearch.TabIndex = 49
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel4, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.tabInformation, 0, 2)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(718, 34)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.61017!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.38983!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 663.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(741, 915)
        Me.TableLayoutPanel1.TabIndex = 50
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.cmdSignature)
        Me.Panel4.Controls.Add(Me.lblExpiredMessage)
        Me.Panel4.Controls.Add(Me.txtSignature)
        Me.Panel4.Controls.Add(Me.cmdPrintScreen)
        Me.Panel4.Location = New System.Drawing.Point(3, 183)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(496, 60)
        Me.Panel4.TabIndex = 51
        '
        'tabInformation
        '
        Me.tabInformation.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tabInformation.Controls.Add(Me.tabx1)
        Me.tabInformation.Controls.Add(Me.tabx2)
        Me.tabInformation.Controls.Add(Me.tabx5)
        Me.tabInformation.Location = New System.Drawing.Point(3, 254)
        Me.tabInformation.MinimumSize = New System.Drawing.Size(680, 0)
        Me.tabInformation.Name = "tabInformation"
        Me.tabInformation.SelectedIndex = 0
        Me.tabInformation.Size = New System.Drawing.Size(735, 658)
        Me.tabInformation.TabIndex = 44
        '
        'tabx1
        '
        Me.tabx1.BackColor = System.Drawing.Color.White
        Me.tabx1.Controls.Add(Me.lblMisc)
        Me.tabx1.Controls.Add(Me.lblSuspensions)
        Me.tabx1.Controls.Add(Me.lblViolations)
        Me.tabx1.Controls.Add(Me.grdMisc)
        Me.tabx1.Controls.Add(Me.grdSuspensions)
        Me.tabx1.Controls.Add(Me.grdViolations)
        Me.tabx1.Location = New System.Drawing.Point(4, 22)
        Me.tabx1.Name = "tabx1"
        Me.tabx1.Padding = New System.Windows.Forms.Padding(3)
        Me.tabx1.Size = New System.Drawing.Size(727, 632)
        Me.tabx1.TabIndex = 0
        Me.tabx1.Text = "Violations"
        '
        'lblMisc
        '
        Me.lblMisc.Location = New System.Drawing.Point(10, 410)
        Me.lblMisc.Name = "lblMisc"
        Me.lblMisc.Size = New System.Drawing.Size(680, 14)
        Me.lblMisc.TabIndex = 5
        Me.lblMisc.Text = "Miscellaneous"
        '
        'lblSuspensions
        '
        Me.lblSuspensions.Location = New System.Drawing.Point(10, 206)
        Me.lblSuspensions.Name = "lblSuspensions"
        Me.lblSuspensions.Size = New System.Drawing.Size(680, 14)
        Me.lblSuspensions.TabIndex = 4
        Me.lblSuspensions.Text = "Suspensions"
        '
        'lblViolations
        '
        Me.lblViolations.Location = New System.Drawing.Point(9, 3)
        Me.lblViolations.Name = "lblViolations"
        Me.lblViolations.Size = New System.Drawing.Size(680, 14)
        Me.lblViolations.TabIndex = 3
        Me.lblViolations.Text = "Violations"
        '
        'grdMisc
        '
        Me.grdMisc.AllowUserToAddRows = False
        Me.grdMisc.AllowUserToDeleteRows = False
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        Me.grdMisc.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle5
        Me.grdMisc.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdMisc.CausesValidation = False
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.SteelBlue
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdMisc.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.grdMisc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdMisc.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.COMMENTS, Me.CREATED_BY, Me.CREATION_DATE, Me.LAST_UPDATED_BY, Me.LAST_UPDATED_DATE, Me.SEQUENCE, Me.EMPLOYEE_ID_1})
        Me.grdMisc.Location = New System.Drawing.Point(12, 427)
        Me.grdMisc.Name = "grdMisc"
        Me.grdMisc.ReadOnly = True
        Me.grdMisc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdMisc.Size = New System.Drawing.Size(706, 196)
        Me.grdMisc.TabIndex = 2
        '
        'COMMENTS
        '
        Me.COMMENTS.HeaderText = "COMMENTS"
        Me.COMMENTS.Name = "COMMENTS"
        Me.COMMENTS.ReadOnly = True
        Me.COMMENTS.Width = 325
        '
        'CREATED_BY
        '
        Me.CREATED_BY.HeaderText = "CREATED BY"
        Me.CREATED_BY.Name = "CREATED_BY"
        Me.CREATED_BY.ReadOnly = True
        Me.CREATED_BY.Width = 120
        '
        'CREATION_DATE
        '
        Me.CREATION_DATE.HeaderText = "CREATION DATE"
        Me.CREATION_DATE.Name = "CREATION_DATE"
        Me.CREATION_DATE.ReadOnly = True
        Me.CREATION_DATE.Width = 150
        '
        'LAST_UPDATED_BY
        '
        Me.LAST_UPDATED_BY.HeaderText = "LAST UPDATED BY"
        Me.LAST_UPDATED_BY.Name = "LAST_UPDATED_BY"
        Me.LAST_UPDATED_BY.ReadOnly = True
        Me.LAST_UPDATED_BY.Width = 150
        '
        'LAST_UPDATED_DATE
        '
        Me.LAST_UPDATED_DATE.HeaderText = "LAST UPDATED DATE"
        Me.LAST_UPDATED_DATE.Name = "LAST_UPDATED_DATE"
        Me.LAST_UPDATED_DATE.ReadOnly = True
        Me.LAST_UPDATED_DATE.Width = 170
        '
        'SEQUENCE
        '
        Me.SEQUENCE.HeaderText = "SEQ"
        Me.SEQUENCE.Name = "SEQUENCE"
        Me.SEQUENCE.ReadOnly = True
        Me.SEQUENCE.Width = 75
        '
        'EMPLOYEE_ID_1
        '
        Me.EMPLOYEE_ID_1.HeaderText = "EMPLOYEE_ID"
        Me.EMPLOYEE_ID_1.Name = "EMPLOYEE_ID_1"
        Me.EMPLOYEE_ID_1.ReadOnly = True
        Me.EMPLOYEE_ID_1.Visible = False
        Me.EMPLOYEE_ID_1.Width = 5
        '
        'grdSuspensions
        '
        Me.grdSuspensions.AllowUserToAddRows = False
        Me.grdSuspensions.AllowUserToDeleteRows = False
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        Me.grdSuspensions.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle7
        Me.grdSuspensions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdSuspensions.CausesValidation = False
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.SteelBlue
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdSuspensions.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.grdSuspensions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdSuspensions.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CC_ACTION, Me.ORDER_DATE, Me.EFFECTIVE_DATE, Me.AUTHOR_ACTION, Me.THRU_DATE, Me.REASON_FOR_ACTION, Me.SERVICE_TYPE, Me.SERVICE_DATE, Me.FILE_TYPE, Me.ACTION_TAKEN, Me.TO_BE_RESOLVED_BY, Me.RESOLVED_DATE, Me.LAST_UPDATED_BY_1, Me.LAST_UPDATED, Me.SEQUENCE_1, Me.EMPLOYEE_ID_2})
        Me.grdSuspensions.Location = New System.Drawing.Point(12, 223)
        Me.grdSuspensions.Name = "grdSuspensions"
        Me.grdSuspensions.ReadOnly = True
        Me.grdSuspensions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdSuspensions.Size = New System.Drawing.Size(706, 184)
        Me.grdSuspensions.TabIndex = 1
        '
        'CC_ACTION
        '
        Me.CC_ACTION.HeaderText = "CC ACTION"
        Me.CC_ACTION.Name = "CC_ACTION"
        Me.CC_ACTION.ReadOnly = True
        Me.CC_ACTION.Width = 150
        '
        'ORDER_DATE
        '
        Me.ORDER_DATE.HeaderText = "ORDER DATE"
        Me.ORDER_DATE.Name = "ORDER_DATE"
        Me.ORDER_DATE.ReadOnly = True
        Me.ORDER_DATE.Width = 120
        '
        'EFFECTIVE_DATE
        '
        Me.EFFECTIVE_DATE.HeaderText = "EFFECTIVE DATE"
        Me.EFFECTIVE_DATE.Name = "EFFECTIVE_DATE"
        Me.EFFECTIVE_DATE.ReadOnly = True
        Me.EFFECTIVE_DATE.Width = 125
        '
        'AUTHOR_ACTION
        '
        Me.AUTHOR_ACTION.HeaderText = "AUTHOR ACTION"
        Me.AUTHOR_ACTION.Name = "AUTHOR_ACTION"
        Me.AUTHOR_ACTION.ReadOnly = True
        Me.AUTHOR_ACTION.Width = 125
        '
        'THRU_DATE
        '
        Me.THRU_DATE.HeaderText = "THRU DATE"
        Me.THRU_DATE.Name = "THRU_DATE"
        Me.THRU_DATE.ReadOnly = True
        Me.THRU_DATE.Width = 125
        '
        'REASON_FOR_ACTION
        '
        Me.REASON_FOR_ACTION.HeaderText = "REASON FOR ACTION"
        Me.REASON_FOR_ACTION.Name = "REASON_FOR_ACTION"
        Me.REASON_FOR_ACTION.ReadOnly = True
        Me.REASON_FOR_ACTION.Width = 150
        '
        'SERVICE_TYPE
        '
        Me.SERVICE_TYPE.HeaderText = "SERVICE TYPE"
        Me.SERVICE_TYPE.Name = "SERVICE_TYPE"
        Me.SERVICE_TYPE.ReadOnly = True
        Me.SERVICE_TYPE.Width = 120
        '
        'SERVICE_DATE
        '
        Me.SERVICE_DATE.HeaderText = "SERVICE DATE"
        Me.SERVICE_DATE.Name = "SERVICE_DATE"
        Me.SERVICE_DATE.ReadOnly = True
        Me.SERVICE_DATE.Width = 125
        '
        'FILE_TYPE
        '
        Me.FILE_TYPE.HeaderText = "FILE TYPE"
        Me.FILE_TYPE.Name = "FILE_TYPE"
        Me.FILE_TYPE.ReadOnly = True
        '
        'ACTION_TAKEN
        '
        Me.ACTION_TAKEN.HeaderText = "ACTION TAKEN"
        Me.ACTION_TAKEN.Name = "ACTION_TAKEN"
        Me.ACTION_TAKEN.ReadOnly = True
        Me.ACTION_TAKEN.Width = 150
        '
        'TO_BE_RESOLVED_BY
        '
        Me.TO_BE_RESOLVED_BY.HeaderText = "TO BE RESOLVED BY"
        Me.TO_BE_RESOLVED_BY.Name = "TO_BE_RESOLVED_BY"
        Me.TO_BE_RESOLVED_BY.ReadOnly = True
        Me.TO_BE_RESOLVED_BY.Width = 150
        '
        'RESOLVED_DATE
        '
        Me.RESOLVED_DATE.HeaderText = "RESOLVED DATE"
        Me.RESOLVED_DATE.Name = "RESOLVED_DATE"
        Me.RESOLVED_DATE.ReadOnly = True
        Me.RESOLVED_DATE.Width = 125
        '
        'LAST_UPDATED_BY_1
        '
        Me.LAST_UPDATED_BY_1.HeaderText = "LAST UPDATED BY"
        Me.LAST_UPDATED_BY_1.Name = "LAST_UPDATED_BY_1"
        Me.LAST_UPDATED_BY_1.ReadOnly = True
        Me.LAST_UPDATED_BY_1.Width = 150
        '
        'LAST_UPDATED
        '
        Me.LAST_UPDATED.HeaderText = "LAST UPDATED"
        Me.LAST_UPDATED.Name = "LAST_UPDATED"
        Me.LAST_UPDATED.ReadOnly = True
        Me.LAST_UPDATED.Width = 125
        '
        'SEQUENCE_1
        '
        Me.SEQUENCE_1.HeaderText = "SEQ"
        Me.SEQUENCE_1.Name = "SEQUENCE_1"
        Me.SEQUENCE_1.ReadOnly = True
        Me.SEQUENCE_1.Width = 75
        '
        'EMPLOYEE_ID_2
        '
        Me.EMPLOYEE_ID_2.HeaderText = "EMPLOYEE_ID"
        Me.EMPLOYEE_ID_2.Name = "EMPLOYEE_ID_2"
        Me.EMPLOYEE_ID_2.ReadOnly = True
        Me.EMPLOYEE_ID_2.Visible = False
        '
        'grdViolations
        '
        Me.grdViolations.AllowUserToAddRows = False
        Me.grdViolations.AllowUserToDeleteRows = False
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        Me.grdViolations.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle9
        Me.grdViolations.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdViolations.CausesValidation = False
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.SteelBlue
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdViolations.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.grdViolations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdViolations.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ViewActionTaken, Me.ITEM, Me.VIOlATION_DATE, Me.CONVICTION_DATE, Me.SECTION, Me.STATUTE, Me.DOCKET_FILE_NO, Me.COURT_ACC_RPT_NO, Me.VEHICLE_LIC_NO, Me.COMMENTS_1})
        Me.grdViolations.Location = New System.Drawing.Point(12, 19)
        Me.grdViolations.Name = "grdViolations"
        Me.grdViolations.ReadOnly = True
        Me.grdViolations.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdViolations.Size = New System.Drawing.Size(706, 184)
        Me.grdViolations.TabIndex = 0
        '
        'ViewActionTaken
        '
        Me.ViewActionTaken.HeaderText = "Action Taken"
        Me.ViewActionTaken.Image = CType(resources.GetObject("ViewActionTaken.Image"), System.Drawing.Image)
        Me.ViewActionTaken.Name = "ViewActionTaken"
        Me.ViewActionTaken.ReadOnly = True
        Me.ViewActionTaken.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'ITEM
        '
        Me.ITEM.HeaderText = "ITEM"
        Me.ITEM.Name = "ITEM"
        Me.ITEM.ReadOnly = True
        Me.ITEM.Width = 51
        '
        'VIOlATION_DATE
        '
        Me.VIOlATION_DATE.HeaderText = "VIOlATION DATE"
        Me.VIOlATION_DATE.Name = "VIOlATION_DATE"
        Me.VIOlATION_DATE.ReadOnly = True
        Me.VIOlATION_DATE.Width = 125
        '
        'CONVICTION_DATE
        '
        Me.CONVICTION_DATE.HeaderText = "CONVICTION DATE"
        Me.CONVICTION_DATE.Name = "CONVICTION_DATE"
        Me.CONVICTION_DATE.ReadOnly = True
        Me.CONVICTION_DATE.Width = 130
        '
        'SECTION
        '
        Me.SECTION.HeaderText = "SECTION"
        Me.SECTION.Name = "SECTION"
        Me.SECTION.ReadOnly = True
        Me.SECTION.Width = 53
        '
        'STATUTE
        '
        Me.STATUTE.HeaderText = "STATUTE"
        Me.STATUTE.Name = "STATUTE"
        Me.STATUTE.ReadOnly = True
        Me.STATUTE.Width = 52
        '
        'DOCKET_FILE_NO
        '
        Me.DOCKET_FILE_NO.HeaderText = "DOCKET/FILE NO"
        Me.DOCKET_FILE_NO.Name = "DOCKET_FILE_NO"
        Me.DOCKET_FILE_NO.ReadOnly = True
        Me.DOCKET_FILE_NO.Width = 125
        '
        'COURT_ACC_RPT_NO
        '
        Me.COURT_ACC_RPT_NO.HeaderText = "COURT/ACC RPT NO"
        Me.COURT_ACC_RPT_NO.Name = "COURT_ACC_RPT_NO"
        Me.COURT_ACC_RPT_NO.ReadOnly = True
        Me.COURT_ACC_RPT_NO.Width = 140
        '
        'VEHICLE_LIC_NO
        '
        Me.VEHICLE_LIC_NO.HeaderText = "VEHICLE LIC NO"
        Me.VEHICLE_LIC_NO.Name = "VEHICLE_LIC_NO"
        Me.VEHICLE_LIC_NO.ReadOnly = True
        Me.VEHICLE_LIC_NO.Width = 125
        '
        'COMMENTS_1
        '
        Me.COMMENTS_1.HeaderText = "COMMENTS"
        Me.COMMENTS_1.Name = "COMMENTS_1"
        Me.COMMENTS_1.ReadOnly = True
        Me.COMMENTS_1.Width = 75
        '
        'tabx2
        '
        Me.tabx2.BackColor = System.Drawing.Color.White
        Me.tabx2.Controls.Add(Me.lblAKA)
        Me.tabx2.Controls.Add(Me.grdAKA)
        Me.tabx2.Location = New System.Drawing.Point(4, 22)
        Me.tabx2.Name = "tabx2"
        Me.tabx2.Padding = New System.Windows.Forms.Padding(3)
        Me.tabx2.Size = New System.Drawing.Size(727, 632)
        Me.tabx2.TabIndex = 1
        Me.tabx2.Text = "AKA"
        '
        'lblAKA
        '
        Me.lblAKA.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblAKA.Location = New System.Drawing.Point(9, 10)
        Me.lblAKA.Name = "lblAKA"
        Me.lblAKA.Size = New System.Drawing.Size(712, 0)
        Me.lblAKA.TabIndex = 4
        Me.lblAKA.Text = "AKA Name"
        '
        'grdAKA
        '
        Me.grdAKA.AllowUserToAddRows = False
        Me.grdAKA.AllowUserToDeleteRows = False
        Me.grdAKA.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdAKA.CausesValidation = False
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.SteelBlue
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdAKA.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.grdAKA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdAKA.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AKA_NAME, Me.CREATED_BY_4, Me.CREATION_DATE_4, Me.LAST_UPDATED_BY_4, Me.LAST_UPDATED_DATE_4, Me.SEQUENCE_4, Me.EMPLOYEE_ID_4})
        Me.grdAKA.Location = New System.Drawing.Point(12, 27)
        Me.grdAKA.Name = "grdAKA"
        Me.grdAKA.ReadOnly = True
        Me.grdAKA.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdAKA.Size = New System.Drawing.Size(705, 359)
        Me.grdAKA.TabIndex = 3
        '
        'AKA_NAME
        '
        Me.AKA_NAME.HeaderText = "AKA NAME"
        Me.AKA_NAME.Name = "AKA_NAME"
        Me.AKA_NAME.ReadOnly = True
        Me.AKA_NAME.Width = 300
        '
        'CREATED_BY_4
        '
        Me.CREATED_BY_4.HeaderText = "CREATED BY"
        Me.CREATED_BY_4.Name = "CREATED_BY_4"
        Me.CREATED_BY_4.ReadOnly = True
        Me.CREATED_BY_4.Width = 120
        '
        'CREATION_DATE_4
        '
        Me.CREATION_DATE_4.HeaderText = "CREATION DATE"
        Me.CREATION_DATE_4.Name = "CREATION_DATE_4"
        Me.CREATION_DATE_4.ReadOnly = True
        Me.CREATION_DATE_4.Width = 140
        '
        'LAST_UPDATED_BY_4
        '
        Me.LAST_UPDATED_BY_4.HeaderText = "LAST UPDATED BY"
        Me.LAST_UPDATED_BY_4.Name = "LAST_UPDATED_BY_4"
        Me.LAST_UPDATED_BY_4.ReadOnly = True
        Me.LAST_UPDATED_BY_4.Width = 150
        '
        'LAST_UPDATED_DATE_4
        '
        Me.LAST_UPDATED_DATE_4.HeaderText = "LAST UPDATED DATE"
        Me.LAST_UPDATED_DATE_4.Name = "LAST_UPDATED_DATE_4"
        Me.LAST_UPDATED_DATE_4.ReadOnly = True
        Me.LAST_UPDATED_DATE_4.Width = 175
        '
        'SEQUENCE_4
        '
        Me.SEQUENCE_4.HeaderText = "SEQ"
        Me.SEQUENCE_4.Name = "SEQUENCE_4"
        Me.SEQUENCE_4.ReadOnly = True
        Me.SEQUENCE_4.Width = 75
        '
        'EMPLOYEE_ID_4
        '
        Me.EMPLOYEE_ID_4.HeaderText = "EMPLOYEE_ID"
        Me.EMPLOYEE_ID_4.Name = "EMPLOYEE_ID_4"
        Me.EMPLOYEE_ID_4.ReadOnly = True
        Me.EMPLOYEE_ID_4.Visible = False
        Me.EMPLOYEE_ID_4.Width = 5
        '
        'tabx5
        '
        Me.tabx5.BackColor = System.Drawing.Color.White
        Me.tabx5.Controls.Add(Me.cmdDeleteComment)
        Me.tabx5.Controls.Add(Me.cmdAddComment)
        Me.tabx5.Controls.Add(Me.txtComments)
        Me.tabx5.Controls.Add(Me.lblComments)
        Me.tabx5.Controls.Add(Me.grdComments)
        Me.tabx5.Location = New System.Drawing.Point(4, 22)
        Me.tabx5.Name = "tabx5"
        Me.tabx5.Padding = New System.Windows.Forms.Padding(3)
        Me.tabx5.Size = New System.Drawing.Size(727, 632)
        Me.tabx5.TabIndex = 4
        Me.tabx5.Text = "Comments"
        '
        'cmdDeleteComment
        '
        Me.cmdDeleteComment.Enabled = False
        Me.cmdDeleteComment.Location = New System.Drawing.Point(107, 116)
        Me.cmdDeleteComment.Name = "cmdDeleteComment"
        Me.cmdDeleteComment.Size = New System.Drawing.Size(88, 24)
        Me.cmdDeleteComment.TabIndex = 11
        Me.cmdDeleteComment.Text = "Delete"
        Me.cmdDeleteComment.UseVisualStyleBackColor = True
        '
        'cmdAddComment
        '
        Me.cmdAddComment.Location = New System.Drawing.Point(13, 117)
        Me.cmdAddComment.Name = "cmdAddComment"
        Me.cmdAddComment.Size = New System.Drawing.Size(88, 24)
        Me.cmdAddComment.TabIndex = 10
        Me.cmdAddComment.Text = "Add Comment"
        Me.cmdAddComment.UseVisualStyleBackColor = True
        '
        'txtComments
        '
        Me.txtComments.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtComments.Location = New System.Drawing.Point(13, 14)
        Me.txtComments.Multiline = True
        Me.txtComments.Name = "txtComments"
        Me.txtComments.Size = New System.Drawing.Size(442, 97)
        Me.txtComments.TabIndex = 9
        '
        'lblComments
        '
        Me.lblComments.Location = New System.Drawing.Point(10, 161)
        Me.lblComments.Name = "lblComments"
        Me.lblComments.Size = New System.Drawing.Size(828, 14)
        Me.lblComments.TabIndex = 8
        Me.lblComments.Text = "Comments"
        '
        'grdComments
        '
        Me.grdComments.AllowUserToAddRows = False
        Me.grdComments.AllowUserToDeleteRows = False
        Me.grdComments.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdComments.CausesValidation = False
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.SteelBlue
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdComments.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.grdComments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdComments.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.COMMENT_6, Me.COMMENT_DATE_6, Me.CREATED_BY_6, Me.SEQUENCE_6, Me.EMPLOYEE_ID_6})
        Me.grdComments.Location = New System.Drawing.Point(13, 178)
        Me.grdComments.Name = "grdComments"
        Me.grdComments.ReadOnly = True
        Me.grdComments.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdComments.Size = New System.Drawing.Size(698, 445)
        Me.grdComments.TabIndex = 7
        '
        'COMMENT_6
        '
        Me.COMMENT_6.HeaderText = "COMMENT"
        Me.COMMENT_6.Name = "COMMENT_6"
        Me.COMMENT_6.ReadOnly = True
        Me.COMMENT_6.Width = 650
        '
        'COMMENT_DATE_6
        '
        Me.COMMENT_DATE_6.HeaderText = "COMMENT DATE"
        Me.COMMENT_DATE_6.Name = "COMMENT_DATE_6"
        Me.COMMENT_DATE_6.ReadOnly = True
        Me.COMMENT_DATE_6.Width = 150
        '
        'CREATED_BY_6
        '
        Me.CREATED_BY_6.HeaderText = "CREATED BY"
        Me.CREATED_BY_6.Name = "CREATED_BY_6"
        Me.CREATED_BY_6.ReadOnly = True
        Me.CREATED_BY_6.Width = 150
        '
        'SEQUENCE_6
        '
        Me.SEQUENCE_6.HeaderText = "SEQ"
        Me.SEQUENCE_6.Name = "SEQUENCE_6"
        Me.SEQUENCE_6.ReadOnly = True
        '
        'EMPLOYEE_ID_6
        '
        Me.EMPLOYEE_ID_6.HeaderText = "EMPLOYEE_ID"
        Me.EMPLOYEE_ID_6.Name = "EMPLOYEE_ID_6"
        Me.EMPLOYEE_ID_6.ReadOnly = True
        Me.EMPLOYEE_ID_6.Visible = False
        Me.EMPLOYEE_ID_6.Width = 5
        '
        'frmMain
        '
        Me.AcceptButton = Me.cmdGo
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1472, 971)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.grdSearch)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.lblFlagRecords)
        Me.Controls.Add(Me.grdFlags)
        Me.Controls.Add(Me.frmViews)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(1435, 0)
        Me.Name = "frmMain"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Search"
        Me.frmViews.ResumeLayout(False)
        Me.tbSearch.ResumeLayout(False)
        Me.tbSearch.PerformLayout()
        Me.gbSearchBy.ResumeLayout(False)
        Me.tbMajorMinor.ResumeLayout(False)
        Me.tbMajorMinor.PerformLayout()
        Me.tbExpired.ResumeLayout(False)
        Me.tbExpired.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.grdFlags, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.fmDMVInfo.ResumeLayout(False)
        Me.fmDMVInfo.PerformLayout()
        CType(Me.grdSearch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.tabInformation.ResumeLayout(False)
        Me.tabx1.ResumeLayout(False)
        CType(Me.grdMisc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdSuspensions, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdViolations, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabx2.ResumeLayout(False)
        CType(Me.grdAKA, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabx5.ResumeLayout(False)
        Me.tabx5.PerformLayout()
        CType(Me.grdComments, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents frmViews As System.Windows.Forms.TabControl
    Friend WithEvents tbSearch As System.Windows.Forms.TabPage
    Friend WithEvents tbMajorMinor As System.Windows.Forms.TabPage
    Friend WithEvents tbExpired As System.Windows.Forms.TabPage
    Friend WithEvents lblInput2 As System.Windows.Forms.Label
    Friend WithEvents lblInput1 As System.Windows.Forms.Label
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents ListCompany1 As System.Windows.Forms.ComboBox
    Friend WithEvents ListCompany2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents listStatus As System.Windows.Forms.ComboBox
    Friend WithEvents chkSoundLike As System.Windows.Forms.CheckBox
    Friend WithEvents txtInput2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtInput1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents EMPLOYMENTSTATUSDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LOCATIONDESCDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblRecordCount1 As System.Windows.Forms.Label
    Friend WithEvents cmdUnsigned As System.Windows.Forms.Button
    Friend WithEvents gbSearchBy As System.Windows.Forms.GroupBox
    Friend WithEvents optView3 As System.Windows.Forms.RadioButton
    Friend WithEvents optView2 As System.Windows.Forms.RadioButton
    Friend WithEvents optView1 As System.Windows.Forms.RadioButton
    Friend WithEvents lblOrderDate As System.Windows.Forms.Label
    Friend WithEvents txtOrderDate As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbSearch As System.Windows.Forms.ComboBox
    Friend WithEvents cmdMajorMinorSearch As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents optMajorMinor3 As System.Windows.Forms.RadioButton
    Friend WithEvents optMajorMinor2 As System.Windows.Forms.RadioButton
    Friend WithEvents optMajorMinor1 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdExcel1 As System.Windows.Forms.Button
    Friend WithEvents listStatus2 As System.Windows.Forms.ComboBox
    Friend WithEvents lblRecordCount2 As System.Windows.Forms.Label
    Friend WithEvents lblRecordCount3 As System.Windows.Forms.Label
    Friend WithEvents listStatus3 As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents cmdExcel2 As System.Windows.Forms.Button
    Friend WithEvents cmdExpired As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtExpiredDays As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ListCompany3 As System.Windows.Forms.ComboBox
    Friend WithEvents optFutureSearch4 As System.Windows.Forms.RadioButton
    Friend WithEvents optFutureSearch3 As System.Windows.Forms.RadioButton
    Friend WithEvents optFutureSearch2 As System.Windows.Forms.RadioButton
    Friend WithEvents optFutureSearch1 As System.Windows.Forms.RadioButton
    Friend WithEvents grdFlags As System.Windows.Forms.DataGridView
    Friend WithEvents lblFlagRecords As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtHR5 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtHR4 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtHR3 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtHR2 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtHR1 As System.Windows.Forms.TextBox
    Friend WithEvents txtHR6 As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents fmDMVInfo As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtDMV12 As System.Windows.Forms.TextBox
    Friend WithEvents txtDMV14 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtDMV13 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtDMV11 As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtDMV10 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtDMV9 As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtDMV8 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtDMV5 As System.Windows.Forms.TextBox
    Friend WithEvents txtDMV7 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtDMV6 As System.Windows.Forms.TextBox
    Friend WithEvents lblCDLExpDate As System.Windows.Forms.Label
    Friend WithEvents txtDMV4 As System.Windows.Forms.TextBox
    Friend WithEvents lblMedicalCard As System.Windows.Forms.Label
    Friend WithEvents txtDMV3 As System.Windows.Forms.TextBox
    Friend WithEvents lblVTTExpDate As System.Windows.Forms.Label
    Friend WithEvents txtDMV2 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtDMV1 As System.Windows.Forms.TextBox
    Friend WithEvents txtSignature As System.Windows.Forms.TextBox
    Friend WithEvents lblExpiredMessage As System.Windows.Forms.Label
    Friend WithEvents cmdSignature As System.Windows.Forms.Button
    Friend WithEvents MESSAGE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Flag_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Major_Minor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EMPLOYEE_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EMPLOYEE_ID_5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SEQUENCE_5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CREATION_DATE_5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CREATED_BY_5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ADDRESS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmdPrintScreen As System.Windows.Forms.Button
    Friend WithEvents grdSearch As DataGridView
    Friend WithEvents Label12 As Label
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents tabInformation As System.Windows.Forms.TabControl
    Friend WithEvents tabx2 As System.Windows.Forms.TabPage
    Friend WithEvents lblAKA As System.Windows.Forms.Label
    Friend WithEvents grdAKA As System.Windows.Forms.DataGridView
    Friend WithEvents AKA_NAME As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CREATED_BY_4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CREATION_DATE_4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LAST_UPDATED_BY_4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LAST_UPDATED_DATE_4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SEQUENCE_4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EMPLOYEE_ID_4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tabx5 As System.Windows.Forms.TabPage
    Friend WithEvents cmdDeleteComment As System.Windows.Forms.Button
    Friend WithEvents cmdAddComment As System.Windows.Forms.Button
    Friend WithEvents txtComments As System.Windows.Forms.TextBox
    Friend WithEvents lblComments As System.Windows.Forms.Label
    Friend WithEvents grdComments As System.Windows.Forms.DataGridView
    Friend WithEvents COMMENT_6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents COMMENT_DATE_6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CREATED_BY_6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SEQUENCE_6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EMPLOYEE_ID_6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tabx1 As System.Windows.Forms.TabPage
    Friend WithEvents lblMisc As System.Windows.Forms.Label
    Friend WithEvents lblSuspensions As System.Windows.Forms.Label
    Friend WithEvents lblViolations As System.Windows.Forms.Label
    Friend WithEvents grdMisc As System.Windows.Forms.DataGridView
    Friend WithEvents COMMENTS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CREATED_BY As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CREATION_DATE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LAST_UPDATED_BY As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LAST_UPDATED_DATE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SEQUENCE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EMPLOYEE_ID_1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdSuspensions As System.Windows.Forms.DataGridView
    Friend WithEvents CC_ACTION As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ORDER_DATE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EFFECTIVE_DATE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AUTHOR_ACTION As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents THRU_DATE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents REASON_FOR_ACTION As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SERVICE_TYPE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SERVICE_DATE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FILE_TYPE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ACTION_TAKEN As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TO_BE_RESOLVED_BY As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RESOLVED_DATE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LAST_UPDATED_BY_1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LAST_UPDATED As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SEQUENCE_1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EMPLOYEE_ID_2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdViolations As System.Windows.Forms.DataGridView
    Friend WithEvents ViewActionTaken As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents ITEM As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VIOlATION_DATE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CONVICTION_DATE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SECTION As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents STATUTE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DOCKET_FILE_NO As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents COURT_ACC_RPT_NO As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VEHICLE_LIC_NO As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents COMMENTS_1 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
