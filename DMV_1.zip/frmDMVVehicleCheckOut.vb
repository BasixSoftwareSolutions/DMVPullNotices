Option Strict Off
Option Explicit On
'Imports VB = Microsoft.VisualBasic
Friend Class frmDMVVehicleCheckOut
    Inherits System.Windows.Forms.Form
    Private TextInfo() As TextBox
    Private LabelInfo() As Label
#Region "Windows Form Designer generated code "
    Public Sub New()
        MyBase.New()
        If m_vb6FormDefInstance Is Nothing Then
            If m_InitializingDefInstance Then
                m_vb6FormDefInstance = Me
            Else
                Try
                    'For the start-up form, the first instance created is the default instance.
                    If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
                        m_vb6FormDefInstance = Me
                    End If
                Catch
                End Try
            End If
        End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        TextInfo = New TextBox() {Text1, Text2, Text3, Text4}
        'LabelInfo = New Label() {LabelInfo1, LabelInfo2, LabelInfo3, Text4}
    End Sub
    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents cmdTools2 As System.Windows.Forms.Button
    Public WithEvents cmdTools1 As System.Windows.Forms.Button
    Public WithEvents Text4 As System.Windows.Forms.TextBox
    Public WithEvents Text3 As System.Windows.Forms.TextBox
    Public WithEvents Text2 As System.Windows.Forms.TextBox
    Public WithEvents _Text1_1 As System.Windows.Forms.TextBox
    Public WithEvents Text1 As System.Windows.Forms.TextBox
    Public WithEvents txtBADGE As System.Windows.Forms.TextBox
    Public WithEvents frameBlank As System.Windows.Forms.GroupBox
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents Image3 As System.Windows.Forms.PictureBox
    Public WithEvents frameOK As System.Windows.Forms.GroupBox
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Image2 As System.Windows.Forms.PictureBox
    Public WithEvents frameNotOK As System.Windows.Forms.GroupBox
    Public WithEvents Image4 As System.Windows.Forms.PictureBox
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents frameCheckBadge As System.Windows.Forms.GroupBox
    Public WithEvents _Label1_6 As System.Windows.Forms.Label
    Public WithEvents _Label1_3 As System.Windows.Forms.Label
    Public WithEvents _Label1_2 As System.Windows.Forms.Label
    Public WithEvents _Label1_1 As System.Windows.Forms.Label
    Public WithEvents _Label1_0 As System.Windows.Forms.Label
    'Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    'Public WithEvents Text11 As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    'Public WithEvents cmdTools As ButtonArray
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDMVVehicleCheckOut))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdTools2 = New System.Windows.Forms.Button()
        Me.cmdTools1 = New System.Windows.Forms.Button()
        Me.Text4 = New System.Windows.Forms.TextBox()
        Me.Text3 = New System.Windows.Forms.TextBox()
        Me.Text2 = New System.Windows.Forms.TextBox()
        Me._Text1_1 = New System.Windows.Forms.TextBox()
        Me.Text1 = New System.Windows.Forms.TextBox()
        Me.txtBADGE = New System.Windows.Forms.TextBox()
        Me.frameBlank = New System.Windows.Forms.GroupBox()
        Me.frameOK = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Image3 = New System.Windows.Forms.PictureBox()
        Me.frameNotOK = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Image2 = New System.Windows.Forms.PictureBox()
        Me.frameCheckBadge = New System.Windows.Forms.GroupBox()
        Me.Image4 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me._Label1_6 = New System.Windows.Forms.Label()
        Me._Label1_3 = New System.Windows.Forms.Label()
        Me._Label1_2 = New System.Windows.Forms.Label()
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.frameOK.SuspendLayout()
        CType(Me.Image3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.frameNotOK.SuspendLayout()
        CType(Me.Image2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.frameCheckBadge.SuspendLayout()
        CType(Me.Image4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdTools2
        '
        Me.cmdTools2.BackColor = System.Drawing.SystemColors.Control
        Me.cmdTools2.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdTools2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdTools2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTools2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdTools2.Location = New System.Drawing.Point(280, 8)
        Me.cmdTools2.Name = "cmdTools2"
        Me.cmdTools2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdTools2.Size = New System.Drawing.Size(77, 23)
        Me.cmdTools2.TabIndex = 7
        Me.cmdTools2.Text = "&Close"
        Me.cmdTools2.UseVisualStyleBackColor = False
        '
        'cmdTools1
        '
        Me.cmdTools1.BackColor = System.Drawing.SystemColors.Control
        Me.cmdTools1.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdTools1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTools1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdTools1.Location = New System.Drawing.Point(194, 8)
        Me.cmdTools1.Name = "cmdTools1"
        Me.cmdTools1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdTools1.Size = New System.Drawing.Size(85, 23)
        Me.cmdTools1.TabIndex = 6
        Me.cmdTools1.Text = "&Verify"
        Me.cmdTools1.UseVisualStyleBackColor = False
        '
        'Text4
        '
        Me.Text4.AcceptsReturn = True
        Me.Text4.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Text4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text4.Location = New System.Drawing.Point(113, 98)
        Me.Text4.MaxLength = 0
        Me.Text4.Name = "Text4"
        Me.Text4.ReadOnly = True
        Me.Text4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text4.Size = New System.Drawing.Size(242, 20)
        Me.Text4.TabIndex = 5
        Me.Text4.TabStop = False
        '
        'Text3
        '
        Me.Text3.AcceptsReturn = True
        Me.Text3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Text3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text3.Location = New System.Drawing.Point(113, 78)
        Me.Text3.MaxLength = 0
        Me.Text3.Name = "Text3"
        Me.Text3.ReadOnly = True
        Me.Text3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text3.Size = New System.Drawing.Size(242, 20)
        Me.Text3.TabIndex = 4
        Me.Text3.TabStop = False
        '
        'Text2
        '
        Me.Text2.AcceptsReturn = True
        Me.Text2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Text2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text2.Location = New System.Drawing.Point(113, 58)
        Me.Text2.MaxLength = 0
        Me.Text2.Name = "Text2"
        Me.Text2.ReadOnly = True
        Me.Text2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text2.Size = New System.Drawing.Size(242, 20)
        Me.Text2.TabIndex = 3
        Me.Text2.TabStop = False
        '
        '_Text1_1
        '
        Me._Text1_1.AcceptsReturn = True
        Me._Text1_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me._Text1_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._Text1_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Text1_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me._Text1_1.Location = New System.Drawing.Point(39, 54)
        Me._Text1_1.MaxLength = 0
        Me._Text1_1.Name = "_Text1_1"
        Me._Text1_1.ReadOnly = True
        Me._Text1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Text1_1.Size = New System.Drawing.Size(7, 20)
        Me._Text1_1.TabIndex = 2
        Me._Text1_1.TabStop = False
        Me._Text1_1.Visible = False
        '
        'Text1
        '
        Me.Text1.AcceptsReturn = True
        Me.Text1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Text1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text1.Location = New System.Drawing.Point(113, 38)
        Me.Text1.MaxLength = 0
        Me.Text1.Name = "Text1"
        Me.Text1.ReadOnly = True
        Me.Text1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text1.Size = New System.Drawing.Size(242, 20)
        Me.Text1.TabIndex = 1
        Me.Text1.TabStop = False
        '
        'txtBADGE
        '
        Me.txtBADGE.AcceptsReturn = True
        Me.txtBADGE.BackColor = System.Drawing.SystemColors.Window
        Me.txtBADGE.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBADGE.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBADGE.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBADGE.Location = New System.Drawing.Point(113, 11)
        Me.txtBADGE.MaxLength = 5
        Me.txtBADGE.Name = "txtBADGE"
        Me.txtBADGE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBADGE.Size = New System.Drawing.Size(71, 20)
        Me.txtBADGE.TabIndex = 0
        '
        'frameBlank
        '
        Me.frameBlank.BackColor = System.Drawing.SystemColors.Control
        Me.frameBlank.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameBlank.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameBlank.Location = New System.Drawing.Point(14, 120)
        Me.frameBlank.Name = "frameBlank"
        Me.frameBlank.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameBlank.Size = New System.Drawing.Size(343, 63)
        Me.frameBlank.TabIndex = 20
        Me.frameBlank.TabStop = False
        '
        'frameOK
        '
        Me.frameOK.BackColor = System.Drawing.SystemColors.Control
        Me.frameOK.Controls.Add(Me.Label3)
        Me.frameOK.Controls.Add(Me.Image3)
        Me.frameOK.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameOK.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameOK.Location = New System.Drawing.Point(14, 120)
        Me.frameOK.Name = "frameOK"
        Me.frameOK.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameOK.Size = New System.Drawing.Size(343, 63)
        Me.frameOK.TabIndex = 16
        Me.frameOK.TabStop = False
        Me.frameOK.Visible = False
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(60, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(271, 21)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "OK to checkout vehicle......."
        '
        'Image3
        '
        Me.Image3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Image3.Image = CType(resources.GetObject("Image3.Image"), System.Drawing.Image)
        Me.Image3.Location = New System.Drawing.Point(18, 18)
        Me.Image3.Name = "Image3"
        Me.Image3.Size = New System.Drawing.Size(32, 32)
        Me.Image3.TabIndex = 18
        Me.Image3.TabStop = False
        '
        'frameNotOK
        '
        Me.frameNotOK.BackColor = System.Drawing.SystemColors.Control
        Me.frameNotOK.Controls.Add(Me.Label2)
        Me.frameNotOK.Controls.Add(Me.Image2)
        Me.frameNotOK.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameNotOK.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameNotOK.Location = New System.Drawing.Point(14, 119)
        Me.frameNotOK.Name = "frameNotOK"
        Me.frameNotOK.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameNotOK.Size = New System.Drawing.Size(343, 63)
        Me.frameNotOK.TabIndex = 14
        Me.frameNotOK.TabStop = False
        Me.frameNotOK.Visible = False
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(58, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(259, 41)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Not authorized to check out vehicle. Please have employee contact their superviso" &
    "r."
        '
        'Image2
        '
        Me.Image2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Image2.Image = CType(resources.GetObject("Image2.Image"), System.Drawing.Image)
        Me.Image2.Location = New System.Drawing.Point(14, 16)
        Me.Image2.Name = "Image2"
        Me.Image2.Size = New System.Drawing.Size(32, 32)
        Me.Image2.TabIndex = 16
        Me.Image2.TabStop = False
        '
        'frameCheckBadge
        '
        Me.frameCheckBadge.BackColor = System.Drawing.SystemColors.Control
        Me.frameCheckBadge.Controls.Add(Me.Image4)
        Me.frameCheckBadge.Controls.Add(Me.Label4)
        Me.frameCheckBadge.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameCheckBadge.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameCheckBadge.Location = New System.Drawing.Point(14, 120)
        Me.frameCheckBadge.Name = "frameCheckBadge"
        Me.frameCheckBadge.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameCheckBadge.Size = New System.Drawing.Size(343, 63)
        Me.frameCheckBadge.TabIndex = 18
        Me.frameCheckBadge.TabStop = False
        Me.frameCheckBadge.Visible = False
        '
        'Image4
        '
        Me.Image4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Image4.Image = CType(resources.GetObject("Image4.Image"), System.Drawing.Image)
        Me.Image4.Location = New System.Drawing.Point(16, 16)
        Me.Image4.Name = "Image4"
        Me.Image4.Size = New System.Drawing.Size(32, 32)
        Me.Image4.TabIndex = 0
        Me.Image4.TabStop = False
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(54, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(269, 17)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Employee is not in the system. Check Badge Number."
        '
        '_Label1_6
        '
        Me._Label1_6.AutoSize = True
        Me._Label1_6.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_6.Location = New System.Drawing.Point(9, 98)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(101, 14)
        Me._Label1_6.TabIndex = 13
        Me._Label1_6.Text = "Employment Status:"
        '
        '_Label1_3
        '
        Me._Label1_3.AutoSize = True
        Me._Label1_3.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_3.Location = New System.Drawing.Point(61, 78)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(49, 14)
        Me._Label1_3.TabIndex = 11
        Me._Label1_3.Text = "Job Title:"
        '
        '_Label1_2
        '
        Me._Label1_2.AutoSize = True
        Me._Label1_2.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_2.Location = New System.Drawing.Point(59, 58)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(51, 14)
        Me._Label1_2.TabIndex = 10
        Me._Label1_2.Text = "Location:"
        '
        '_Label1_1
        '
        Me._Label1_1.AutoSize = True
        Me._Label1_1.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_1.Location = New System.Drawing.Point(24, 41)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(86, 14)
        Me._Label1_1.TabIndex = 9
        Me._Label1_1.Text = "Employee Name:"
        '
        '_Label1_0
        '
        Me._Label1_0.AutoSize = True
        Me._Label1_0.BackColor = System.Drawing.SystemColors.Control
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Label1_0.Location = New System.Drawing.Point(75, 13)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(38, 14)
        Me._Label1_0.TabIndex = 8
        Me._Label1_0.Text = "Badge"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(41, 39)
        Me.PictureBox1.TabIndex = 21
        Me.PictureBox1.TabStop = False
        '
        'frmDMVVehicleCheckOut
        '
        Me.AcceptButton = Me.cmdTools1
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.CancelButton = Me.cmdTools2
        Me.ClientSize = New System.Drawing.Size(370, 199)
        Me.ControlBox = False
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.cmdTools2)
        Me.Controls.Add(Me.cmdTools1)
        Me.Controls.Add(Me.Text4)
        Me.Controls.Add(Me.Text3)
        Me.Controls.Add(Me.Text2)
        Me.Controls.Add(Me._Text1_1)
        Me.Controls.Add(Me.Text1)
        Me.Controls.Add(Me.txtBADGE)
        Me.Controls.Add(Me.frameBlank)
        Me.Controls.Add(Me.frameOK)
        Me.Controls.Add(Me.frameNotOK)
        Me.Controls.Add(Me.frameCheckBadge)
        Me.Controls.Add(Me._Label1_6)
        Me.Controls.Add(Me._Label1_3)
        Me.Controls.Add(Me._Label1_2)
        Me.Controls.Add(Me._Label1_1)
        Me.Controls.Add(Me._Label1_0)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmDMVVehicleCheckOut"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Vehicle Checkout Verification"
        Me.frameOK.ResumeLayout(False)
        CType(Me.Image3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.frameNotOK.ResumeLayout(False)
        CType(Me.Image2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.frameCheckBadge.ResumeLayout(False)
        CType(Me.Image4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmDMVVehicleCheckOut
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmDMVVehicleCheckOut
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmDMVVehicleCheckOut()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdTools_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Verify a badge or close the form
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdTools_Click(ByVal Index As Integer)
        On Error Resume Next

        If Index = 0 Then
            Verify() 'Validate the badge
        Else
            Me.Close() 'Close the form
        End If

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : Verify
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Check to see if an employee is eligable to drive a company vehicle
    '---------------------------------------------------------------------------------------
    '
    Private Sub Verify()
        Dim XSPoints As Object
        On Error Resume Next

        Dim Temp As String = ""
        Dim Temp_Status As String = ""
        Dim EmpFound As Boolean
        Dim DMVEmpFound As Boolean
        Dim DMVOptOut As Boolean
        Dim ViolationsFound As Boolean

        'Format the badge number
        Temp = txtBADGE.Text

        'Validate the badge number
        If Len(txtBADGE.Text) > 4 Or Len(txtBADGE.Text) = 0 Or VerifyNumber(txtBADGE.Text) = 0 Then
            MsgBox("Please enter a valid badge!", MsgBoxStyle.Exclamation, "Stop")
            txtBADGE.Focus()
        End If

        'See if they exist in the database
        sSQL = "SELECT A.last_name + ', ' + A.first_name employee_name," & " dbo.DecryptData(A.drivers_license) AS drivers_license," & " A.Location_Code + '-' + A.Location_Desc location," & " A.job_title," & " A.employment_status" & " FROM dbo.hr_c_employees A" & " WHERE A.employee_id='" & Temp & "'"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then 'Record found
            TextInfo(0).Text = rs.Fields("employee_name").Value
            TextInfo(1).Text = RemoveSpaces(rs.Fields("drivers_license").Value)
            TextInfo(2).Text = RemoveSpaces(rs.Fields("Location").Value)
            TextInfo(3).Text = RemoveSpaces(rs.Fields("JOB_TITLE").Value)
            TextInfo(4).Text = RemoveSpaces(rs.Fields("EMPLOYMENT_STATUS").Value)
            Temp_Status = RemoveSpaces(rs.Fields("EMPLOYMENT_STATUS").Value).Substring(0, 1)
            EmpFound = True
        Else 'Record not found
            TextInfo(0).Text = "NOT FOUND"
            TextInfo(1).Text = ""
            TextInfo(2).Text = ""
            TextInfo(3).Text = ""
            TextInfo(4).Text = ""
            EmpFound = False
        End If

        'Check for DMV record
        sSQL = ""
        sSQL = "SELECT dbo.DecryptData(A.Drivers_License_No) AS Drivers_License_No" & " FROM dbo.hr_dmv_employees A " & " WHERE A.employee_id='" & Temp & "'"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            DMVEmpFound = True
        Else
            DMVEmpFound = False
        End If

        'See if they Opted Out
        'They are not eligable if they did
        sSQL = ""
        sSQL = "SELECT A.employee_id" & " FROM dbo.hr_dmv_optout A " & " WHERE A.employee_id='" & Temp & "'"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            DMVOptOut = True
        Else
            DMVOptOut = False
        End If

        'See if they have too many points
        'Max of 2 points is allowed
        sSQL = ""
        sSQL = "SELECT Sum(A.point_count_1) as Points" & " FROM dbo.hr_dmv_employees A " & " WHERE employee_id = '" & Temp & "'" & " GROUP BY employee_id"


        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.Fields("Points").Value >= 2 Then
            XSPoints = True
        Else
            XSPoints = False
        End If

        'Check for certain violations
        sSQL = ""
        sSQL = "SELECT COUNT(*) AS iCount" & " FROM dbo.hr_dmv_employee_flags " & " WHERE employee_id='" & Temp & "'" & " AND flag IN (2,5,6,9,16,17)"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.Fields("iCount").Value <> 0 Then rs.MoveLast()
        If rs.Fields("iCount").Value > 0 Then
            ViolationsFound = True
        Else
            ViolationsFound = False
        End If


        'Display the appropriate message
        frameNotOK.Visible = False
        frameBlank.Visible = False
        frameCheckBadge.Visible = False
        frameOK.Visible = False

        'Check the employee status
        Select Case True
            Case DMVEmpFound = False
                frameNotOK.Visible = True
            Case Temp_Status <> "A"
                frameNotOK.Visible = True
            Case DMVOptOut = True
                frameNotOK.Visible = True
            Case XSPoints = True
                frameNotOK.Visible = True
            Case ViolationsFound = True
                frameNotOK.Visible = True
            Case Else
                frameOK.Visible = True
        End Select

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : Form_Load
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the form
    '---------------------------------------------------------------------------------------
    '
    Private Sub frmDMVVehicleCheckOut_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        On Error Resume Next

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        ClearTextBoxes()

    End Sub

    Private Sub Image1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        On Error Resume Next

        MsgBox("We are out of here...See Yah", MsgBoxStyle.Information, "")

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : txtBADGE_Change
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Clear the text box if the badge is empty
    '---------------------------------------------------------------------------------------
    '
    Private Sub txtBADGE_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtBADGE.TextChanged
        On Error Resume Next

        If Len(txtBADGE.Text) <= 1 Then
            ClearTextBoxes()
        End If

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : ClearTextBoxes
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Clear all the text boxes
    '---------------------------------------------------------------------------------------
    '
    Private Sub ClearTextBoxes()
        Dim i As Object
        On Error Resume Next

        frameNotOK.Visible = False
        frameCheckBadge.Visible = False
        frameOK.Visible = False
        frameBlank.Visible = True
        For i = 0 To 3
            TextInfo(i).Text = ""
        Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : txtBADGE_GotFocus
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Hightlight the entire textbox when it has the focus
    '---------------------------------------------------------------------------------------
    '
    Private Sub txtBADGE_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtBADGE.Enter
        On Error Resume Next

        txtBADGE.SelectionStart = 0
        txtBADGE.SelectionLength = Len(txtBADGE.Text)

    End Sub

    Private Sub cmdTools1_Click(sender As Object, e As EventArgs) Handles cmdTools1.Click

        cmdTools_Click(0)

    End Sub

    Private Sub cmdTools2_Click(sender As Object, e As EventArgs) Handles cmdTools2.Click

        cmdTools_Click(1)

    End Sub

End Class