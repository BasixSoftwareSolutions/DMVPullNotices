Option Strict Off
Option Explicit On
Friend Class frmProcessSatImport
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents cmdSetFlags As System.Windows.Forms.Button
	Public WithEvents cmdMungeData As System.Windows.Forms.Button
	Public WithEvents cmdTransferFile As System.Windows.Forms.Button
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents _Image1_1 As System.Windows.Forms.PictureBox
	Public WithEvents _Image1_2 As System.Windows.Forms.PictureBox
	Public WithEvents _Image1_3 As System.Windows.Forms.PictureBox
	Public WithEvents _Image2_1 As System.Windows.Forms.PictureBox
	Public WithEvents _Image2_2 As System.Windows.Forms.PictureBox
	Public WithEvents _Image2_3 As System.Windows.Forms.PictureBox
	Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents cmdGETEmpList As System.Windows.Forms.Button
	Public WithEvents cmdImportData As System.Windows.Forms.Button
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    'Public WithEvents Image1 As Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray
    'Public WithEvents Image2 As Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProcessSatImport))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.cmdSetFlags = New System.Windows.Forms.Button()
        Me.cmdMungeData = New System.Windows.Forms.Button()
        Me.cmdTransferFile = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me._Image1_1 = New System.Windows.Forms.PictureBox()
        Me._Image1_2 = New System.Windows.Forms.PictureBox()
        Me._Image1_3 = New System.Windows.Forms.PictureBox()
        Me._Image2_1 = New System.Windows.Forms.PictureBox()
        Me._Image2_2 = New System.Windows.Forms.PictureBox()
        Me._Image2_3 = New System.Windows.Forms.PictureBox()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmdGETEmpList = New System.Windows.Forms.Button()
        Me.cmdImportData = New System.Windows.Forms.Button()
        'Me.Image1 = New Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray(Me.components)
        'Me.Image2 = New Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray(Me.components)
        Me.Frame2.SuspendLayout()
        CType(Me._Image1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Image1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Image1_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Image2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Image2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._Image2_3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Frame1.SuspendLayout()
        'CType(Me.Image1, System.ComponentModel.ISupportInitialize).BeginInit()
        'CType(Me.Image2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(29, 266)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(63, 23)
        Me.cmdClose.TabIndex = 10
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.Controls.Add(Me.cmdSetFlags)
        Me.Frame2.Controls.Add(Me.cmdMungeData)
        Me.Frame2.Controls.Add(Me.cmdTransferFile)
        Me.Frame2.Controls.Add(Me.Label3)
        Me.Frame2.Controls.Add(Me.Label4)
        Me.Frame2.Controls.Add(Me.Label1)
        Me.Frame2.Controls.Add(Me._Image1_1)
        Me.Frame2.Controls.Add(Me._Image1_2)
        Me.Frame2.Controls.Add(Me._Image1_3)
        Me.Frame2.Controls.Add(Me._Image2_1)
        Me.Frame2.Controls.Add(Me._Image2_2)
        Me.Frame2.Controls.Add(Me._Image2_3)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(8, 16)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(176, 125)
        Me.Frame2.TabIndex = 3
        Me.Frame2.TabStop = False
        Me.Frame2.Text = "Process Data"
        '
        'cmdSetFlags
        '
        Me.cmdSetFlags.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSetFlags.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSetFlags.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSetFlags.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSetFlags.Location = New System.Drawing.Point(33, 88)
        Me.cmdSetFlags.Name = "cmdSetFlags"
        Me.cmdSetFlags.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSetFlags.Size = New System.Drawing.Size(107, 24)
        Me.cmdSetFlags.TabIndex = 6
        Me.cmdSetFlags.Text = "Set Flags"
        Me.cmdSetFlags.UseVisualStyleBackColor = False
        '
        'cmdMungeData
        '
        Me.cmdMungeData.BackColor = System.Drawing.SystemColors.Control
        Me.cmdMungeData.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdMungeData.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMungeData.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdMungeData.Location = New System.Drawing.Point(33, 53)
        Me.cmdMungeData.Name = "cmdMungeData"
        Me.cmdMungeData.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdMungeData.Size = New System.Drawing.Size(107, 24)
        Me.cmdMungeData.TabIndex = 5
        Me.cmdMungeData.Text = "Munge Data"
        Me.cmdMungeData.UseVisualStyleBackColor = False
        '
        'cmdTransferFile
        '
        Me.cmdTransferFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdTransferFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdTransferFile.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTransferFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdTransferFile.Location = New System.Drawing.Point(33, 19)
        Me.cmdTransferFile.Name = "cmdTransferFile"
        Me.cmdTransferFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdTransferFile.Size = New System.Drawing.Size(107, 24)
        Me.cmdTransferFile.TabIndex = 4
        Me.cmdTransferFile.Text = "Transfer File to DB"
        Me.cmdTransferFile.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(13, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(18, 26)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "1)"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(12, 55)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(18, 26)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "2)"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(12, 89)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(18, 26)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "3)"
        '
        '_Image1_1
        '
        Me._Image1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image1_1.Image = CType(resources.GetObject("_Image1_1.Image"), System.Drawing.Image)
        'Me.Image1.SetIndex(Me._Image1_1, CType(1, Short))
        Me._Image1_1.Location = New System.Drawing.Point(146, 20)
        Me._Image1_1.Name = "_Image1_1"
        Me._Image1_1.Size = New System.Drawing.Size(22, 21)
        Me._Image1_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image1_1.TabIndex = 10
        Me._Image1_1.TabStop = False
        Me._Image1_1.Visible = False
        '
        '_Image1_2
        '
        Me._Image1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image1_2.Image = CType(resources.GetObject("_Image1_2.Image"), System.Drawing.Image)
        'Me.Image1.SetIndex(Me._Image1_2, CType(2, Short))
        Me._Image1_2.Location = New System.Drawing.Point(146, 55)
        Me._Image1_2.Name = "_Image1_2"
        Me._Image1_2.Size = New System.Drawing.Size(22, 21)
        Me._Image1_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image1_2.TabIndex = 11
        Me._Image1_2.TabStop = False
        Me._Image1_2.Visible = False
        '
        '_Image1_3
        '
        Me._Image1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image1_3.Image = CType(resources.GetObject("_Image1_3.Image"), System.Drawing.Image)
        'Me.Image1.SetIndex(Me._Image1_3, CType(3, Short))
        Me._Image1_3.Location = New System.Drawing.Point(146, 89)
        Me._Image1_3.Name = "_Image1_3"
        Me._Image1_3.Size = New System.Drawing.Size(22, 21)
        Me._Image1_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image1_3.TabIndex = 12
        Me._Image1_3.TabStop = False
        Me._Image1_3.Visible = False
        '
        '_Image2_1
        '
        Me._Image2_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image2_1.Image = CType(resources.GetObject("_Image2_1.Image"), System.Drawing.Image)
        'Me.Image2.SetIndex(Me._Image2_1, CType(1, Short))
        Me._Image2_1.Location = New System.Drawing.Point(147, 20)
        Me._Image2_1.Name = "_Image2_1"
        Me._Image2_1.Size = New System.Drawing.Size(20, 20)
        Me._Image2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image2_1.TabIndex = 13
        Me._Image2_1.TabStop = False
        Me._Image2_1.Visible = False
        '
        '_Image2_2
        '
        Me._Image2_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image2_2.Image = CType(resources.GetObject("_Image2_2.Image"), System.Drawing.Image)
        'Me.Image2.SetIndex(Me._Image2_2, CType(2, Short))
        Me._Image2_2.Location = New System.Drawing.Point(147, 55)
        Me._Image2_2.Name = "_Image2_2"
        Me._Image2_2.Size = New System.Drawing.Size(20, 20)
        Me._Image2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image2_2.TabIndex = 14
        Me._Image2_2.TabStop = False
        Me._Image2_2.Visible = False
        '
        '_Image2_3
        '
        Me._Image2_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Image2_3.Image = CType(resources.GetObject("_Image2_3.Image"), System.Drawing.Image)
        'Me.Image2.SetIndex(Me._Image2_3, CType(3, Short))
        Me._Image2_3.Location = New System.Drawing.Point(147, 89)
        Me._Image2_3.Name = "_Image2_3"
        Me._Image2_3.Size = New System.Drawing.Size(20, 20)
        Me._Image2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me._Image2_3.TabIndex = 15
        Me._Image2_3.TabStop = False
        Me._Image2_3.Visible = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.cmdGETEmpList)
        Me.Frame1.Controls.Add(Me.cmdImportData)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(12, 155)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(174, 93)
        Me.Frame1.TabIndex = 0
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Utilities"
        '
        'cmdGETEmpList
        '
        Me.cmdGETEmpList.BackColor = System.Drawing.SystemColors.Control
        Me.cmdGETEmpList.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdGETEmpList.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdGETEmpList.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdGETEmpList.Location = New System.Drawing.Point(32, 24)
        Me.cmdGETEmpList.Name = "cmdGETEmpList"
        Me.cmdGETEmpList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdGETEmpList.Size = New System.Drawing.Size(107, 24)
        Me.cmdGETEmpList.TabIndex = 2
        Me.cmdGETEmpList.Text = "Get File Data"
        Me.cmdGETEmpList.UseVisualStyleBackColor = False
        '
        'cmdImportData
        '
        Me.cmdImportData.BackColor = System.Drawing.SystemColors.Control
        Me.cmdImportData.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdImportData.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdImportData.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdImportData.Location = New System.Drawing.Point(31, 55)
        Me.cmdImportData.Name = "cmdImportData"
        Me.cmdImportData.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdImportData.Size = New System.Drawing.Size(107, 24)
        Me.cmdImportData.TabIndex = 1
        Me.cmdImportData.Text = "Import Data"
        Me.cmdImportData.UseVisualStyleBackColor = False
        '
        'frmProcessSatImport
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(214, 299)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.Frame2)
        Me.Controls.Add(Me.Frame1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(4, 30)
        Me.Name = "frmProcessSatImport"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Saturday Import"
        Me.Frame2.ResumeLayout(False)
        CType(Me._Image1_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Image1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Image1_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Image2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Image2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._Image2_3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame1.ResumeLayout(False)
        'CType(Me.Image1, System.ComponentModel.ISupportInitialize).EndInit()
        'CType(Me.Image2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As frmProcessSatImport
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmProcessSatImport
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmProcessSatImport()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		
		Me.Close()
		
	End Sub
	
	Private Sub cmdGETEmpList_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdGETEmpList.Click
		On Error GoTo cmdGETEmpList_Click_Error
		
		MsgBox("File Date is: " & FileDateTime(FILE_PATH & "\DMV_Sat.dat"), MsgBoxStyle.Information)
		
cmdGETEmpList_Click_Exit: 
		'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
		System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
		Exit Sub
		
cmdGETEmpList_Click_Error: 
		'Image2(0).Visible = True
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: cmdGETEmpList_Click" & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdGETEmpList_Click_Exit

    End Sub

    Private Sub cmdImportData_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdImportData.Click
        On Error GoTo cmdImportData_Click_Error

        Dim retval As String
        Dim iFileNo As Short

        'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        'Create and open the file
        iFileNo = FreeFile
        FileOpen(iFileNo, FILE_PATH & "\DMV_GET_Sat.ftp", OpenMode.Output)

        'Populate the file
        retval = InputBox("Enter the FTP Password", "Password...")
        If retval <> "" Then
            PrintLine(iFileNo, "open mvs.teale.ca.gov")
            PrintLine(iFileNo, "user mvxocta")
            PrintLine(iFileNo, retval)
            PrintLine(iFileNo, "ascii")
            PrintLine(iFileNo, "get 'mv.volreqst.r67198.out.sat' " & FILE_PATH & "\DMV_Sat.dat")
            PrintLine(iFileNo, "close")
            PrintLine(iFileNo, "quit")
        End If

        FileClose(iFileNo)

        retval = CStr(Shell(FILE_PATH & "\DMV_GET_SAT.bat", AppWinStyle.NormalFocus))

cmdImportData_Click_Exit:
        'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdImportData_Click_Error:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdImportData_Click" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdImportData_Click_Exit

    End Sub

    Private Sub cmdMungeData_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdMungeData.Click
        On Error GoTo cmdMungeData_Click_Error

        Dim prm As ADODB.Parameter
        Dim iRecordCount As Short

        'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        cmd = New ADODB.Command

        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
            .CommandText = "dbo.dmv_load"
            prm = .CreateParameter("inLOAD_TYPE", ADODB.DataTypeEnum.adVarChar, ADODB.ParameterDirectionEnum.adParamInput, 14, "Daily")
            .Parameters.Append(prm)
        End With

        'Execute sproc
        cmd.Execute(iRecordCount)

        If iRecordCount > 0 Then
            _Image1_2.Visible = True
        Else
            MsgBox("No records processed", MsgBoxStyle.Information, "Process Data...")
            _Image2_2.Visible = True
        End If

cmdMungeData_Click_Exit:
        'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdMungeData_Click_Error:
        _Image2_2.Visible = True
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdMungeData_Click" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdMungeData_Click_Exit

    End Sub

    Private Sub cmdSetFlags_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSetFlags.Click
        On Error GoTo cmdSetFlags_Click_Error

        Dim prm As ADODB.Parameter
        Dim iRecordCount As Short

        'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        cmd = New ADODB.Command

        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
            .CommandText = "dbo.Dmv_Set_Flags"
        End With

        'Execute sproc
        cmd.Execute(iRecordCount)

        If iRecordCount > 0 Then
            _Image1_3.Visible = True
        Else
            MsgBox("No records processed", MsgBoxStyle.Information, "Process Data...")
            _Image2_3.Visible = True
        End If

cmdSetFlags_Click_Exit:
        'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdSetFlags_Click_Error:
        _Image2_3.Visible = True
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdSetFlags" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdSetFlags_Click_Exit

    End Sub

    Private Sub cmdTransferFile_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdTransferFile.Click
        Dim iRecordCount As Object = 0
        Dim prm As Object
        On Error GoTo cmdTransferFile_Click_Error

        Dim retval As String

        'UPGRADE_WARNING: Screen property Screen.MousePointer has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        cmd = New ADODB.Command

        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
            .CommandText = "dbo.truncate_table"
            prm = .CreateParameter("varTABLE_NAME", ADODB.DataTypeEnum.adVarChar, ADODB.ParameterDirectionEnum.adParamInput, 11, "hr_dmv_load")
            .Parameters.Append(prm)
        End With

        'Execute sproc
        cmd.Execute(iRecordCount)

        'UPGRADE_WARNING: Couldn't resolve default property of object iRecordCount. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        Dim intFileHandle As Short
        Dim sStr As String
        If iRecordCount > 0 Then
            retval = CStr(Shell(FILE_PATH & "\dmv_conv_Sat.bat", AppWinStyle.NormalFocus))
            'Append last line to imported file from DMV
            sStr = "A  XXXXXXXX XXX XXX 0 010101                       00000 010101 00000   BOGUS, TEST RECORD"
            intFileHandle = FreeFile
            FileOpen(intFileHandle, FILE_PATH & "\DMV_Sat.dat", OpenMode.Append)
            PrintLine(intFileHandle, sStr)
            FileClose(intFileHandle)

            _Image2_1.Visible = False
            _Image1_1.Visible = True
        Else
            MsgBox("No records processed", MsgBoxStyle.Information, "Process Data...")
            _Image2_1.Visible = True
            _Image1_1.Visible = False
        End If

        _Image1_1.Visible = True

cmdTransferFile_Click_Exit:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdTransferFile_Click_Error:
        _Image2_1.Visible = True
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdTransferFile_Click" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdTransferFile_Click_Exit

    End Sub
End Class