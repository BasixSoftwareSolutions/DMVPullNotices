Option Strict Off
Option Explicit On 
Imports System.Reflection

Friend Class MDIForm1
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			m_vb6FormDefInstance = Me
		End If
		'This call is required by the Windows Form Designer.
        InitializeComponent()
	End Sub

    Private Property frmTopic As Object

    'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents EnCrypt1 As System.Windows.Forms.PictureBox
    Public WithEvents mnuFileExit As System.Windows.Forms.MenuItem
	Public WithEvents mnuFile As System.Windows.Forms.MenuItem
	Public WithEvents mnuDMVSystem As System.Windows.Forms.MenuItem
	Public WithEvents mnuVehicleCheckout As System.Windows.Forms.MenuItem
	Public WithEvents mnuSecurity As System.Windows.Forms.MenuItem
	Public WithEvents mnuOptOut As System.Windows.Forms.MenuItem
	Public WithEvents mnuExportFile As System.Windows.Forms.MenuItem
	Public WithEvents mnuDeleteTermedEmp As System.Windows.Forms.MenuItem
	Public WithEvents mnuDailyImport As System.Windows.Forms.MenuItem
	Public WithEvents mnuProcessImport As System.Windows.Forms.MenuItem
	Public WithEvents mnuChangeFTPPassword As System.Windows.Forms.MenuItem
	Public WithEvents mnuAdmin As System.Windows.Forms.MenuItem
	Public MainMenu1 As System.Windows.Forms.MainMenu
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MDIForm1))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.EnCrypt1 = New System.Windows.Forms.PictureBox()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu(Me.components)
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuFileExit = New System.Windows.Forms.MenuItem()
        Me.mnuDMVSystem = New System.Windows.Forms.MenuItem()
        Me.mnuVehicleCheckout = New System.Windows.Forms.MenuItem()
        Me.mnuAdmin = New System.Windows.Forms.MenuItem()
        Me.mnuSecurity = New System.Windows.Forms.MenuItem()
        Me.mnuOptOut = New System.Windows.Forms.MenuItem()
        Me.mnuExportFile = New System.Windows.Forms.MenuItem()
        Me.mnuDeleteTermedEmp = New System.Windows.Forms.MenuItem()
        Me.mnuDailyImport = New System.Windows.Forms.MenuItem()
        Me.mnuProcessImport = New System.Windows.Forms.MenuItem()
        Me.mnuChangeFTPPassword = New System.Windows.Forms.MenuItem()
        CType(Me.EnCrypt1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'EnCrypt1
        '
        Me.EnCrypt1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(162, Byte), Integer))
        Me.EnCrypt1.BackgroundImage = CType(resources.GetObject("EnCrypt1.BackgroundImage"), System.Drawing.Image)
        Me.EnCrypt1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.EnCrypt1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.EnCrypt1.Cursor = System.Windows.Forms.Cursors.Default
        Me.EnCrypt1.Dock = System.Windows.Forms.DockStyle.Top
        Me.EnCrypt1.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EnCrypt1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.EnCrypt1.InitialImage = Nothing
        Me.EnCrypt1.Location = New System.Drawing.Point(0, 0)
        Me.EnCrypt1.Name = "EnCrypt1"
        Me.EnCrypt1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.EnCrypt1.Size = New System.Drawing.Size(1196, 68)
        Me.EnCrypt1.TabIndex = 0
        Me.EnCrypt1.TabStop = False
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuDMVSystem, Me.mnuVehicleCheckout, Me.mnuAdmin})
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFileExit})
        Me.mnuFile.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuFile.Text = "&File"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Index = 0
        Me.mnuFileExit.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuFileExit.Text = "&Exit"
        '
        'mnuDMVSystem
        '
        Me.mnuDMVSystem.Index = 1
        Me.mnuDMVSystem.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuDMVSystem.Text = "&DMV System"
        '
        'mnuVehicleCheckout
        '
        Me.mnuVehicleCheckout.Index = 2
        Me.mnuVehicleCheckout.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuVehicleCheckout.Text = "&Vehicle Checkout"
        '
        'mnuAdmin
        '
        Me.mnuAdmin.Index = 3
        Me.mnuAdmin.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuSecurity, Me.mnuOptOut, Me.mnuExportFile, Me.mnuDeleteTermedEmp, Me.mnuDailyImport, Me.mnuProcessImport, Me.mnuChangeFTPPassword})
        Me.mnuAdmin.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuAdmin.Text = "&Administration"
        '
        'mnuSecurity
        '
        Me.mnuSecurity.Index = 0
        Me.mnuSecurity.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuSecurity.Text = "&Security"
        '
        'mnuOptOut
        '
        Me.mnuOptOut.Index = 1
        Me.mnuOptOut.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuOptOut.Text = "&Opt Out"
        '
        'mnuExportFile
        '
        Me.mnuExportFile.Index = 2
        Me.mnuExportFile.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuExportFile.Text = "E&xport Add/Del"
        '
        'mnuDeleteTermedEmp
        '
        Me.mnuDeleteTermedEmp.Index = 3
        Me.mnuDeleteTermedEmp.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuDeleteTermedEmp.Text = "Delete &Termed Emp"
        '
        'mnuDailyImport
        '
        Me.mnuDailyImport.Index = 4
        Me.mnuDailyImport.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuDailyImport.Text = "Process &Daily Import"
        '
        'mnuProcessImport
        '
        Me.mnuProcessImport.Index = 5
        Me.mnuProcessImport.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuProcessImport.Text = "&Process Volume Reqst"
        '
        'mnuChangeFTPPassword
        '
        Me.mnuChangeFTPPassword.Index = 6
        Me.mnuChangeFTPPassword.MergeType = System.Windows.Forms.MenuMerge.Remove
        Me.mnuChangeFTPPassword.Text = "&Change SFTP Password"
        '
        'MDIForm1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 15)
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1196, 533)
        Me.Controls.Add(Me.EnCrypt1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Location = New System.Drawing.Point(15, 57)
        Me.Menu = Me.MainMenu1
        Me.Name = "MDIForm1"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text = "DMV System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.EnCrypt1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As MDIForm1
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As MDIForm1
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New MDIForm1()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	'---------------------------------------------------------------------------------------
	' Procedure : GetDMVPassword
	' DateTime  : 03/21/2007
	' Author    : aalvidrez
	' Purpose   : Retreive the users password
	'---------------------------------------------------------------------------------------
	'
	Public ReadOnly Property GetDMVPassword() As String
		Get
			On Error GoTo Get_GetDMVPassword_ErrorHandler
			
			'Get the password
			GetDMVPassword = RetrieveFieldFrom("dmv_password", "dbo.sc_user_ids", "user_id='" & LCase(Environ("USERNAME")) & "'")
			
			'Reset the password if none is found
			If Trim(GetDMVPassword) = "" Then
				GetDMVPassword = "reset"
			End If
			
			Exit Property
Get_GetDMVPassword_ErrorHandler: 
			sMsg = "Error Information..." & vbCrLf & vbCrLf
			sMsg = sMsg & "Function: Get_GetDMVPassword " & vbCrLf
			sMsg = sMsg & "Description: " & Err.Description & vbCrLf
            sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
            MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
            Resume Next

        End Get
    End Property
    '---------------------------------------------------------------------------------------
    ' Procedure : MDIForm_Load
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the MDI form
    '---------------------------------------------------------------------------------------
    '
    Private Sub MDIForm1_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        On Error GoTo MDIForm_Load_ErrorHandler

        Dim TCount As Short

        'Check for DMV rights
        sSQL = "SELECT Count(*) as iCount "
        sSQL = sSQL & "FROM dbo.sc_dmv_rights_systems "
        sSQL = sSQL & "WHERE user_id='" & LCase(Environ("USERNAME")) & "' AND tab_id='DMV'"

        Dim rs As New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenForwardOnly)
        If Not (rs.EOF And rs.BOF) Then
            TCount = rs.Fields("iCount").Value
        End If

        rs = Nothing

        If TCount = 0 Then
            mnuDMVSystem.Visible = False
        End If

        'Check for Vehicle rights
        sSQL = "SELECT Count(*) as iCount "
        sSQL = sSQL & "FROM dbo.sc_dmv_rights_systems "
        sSQL = sSQL & "WHERE user_id='" & LCase(Environ("USERNAME")) & "' AND tab_id='VEHIC'"

        Dim rs1 As New ADODB.Recordset
        rs1.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenForwardOnly)
        If Not (rs1.EOF And rs1.BOF) Then
            TCount = rs1.Fields("iCount").Value
        End If

        rs1 = Nothing

        If TCount = 0 Then
            mnuVehicleCheckout.Visible = False
        End If

        'Check for security rights
        sSQL = "SELECT Count(*) as iCount "
        sSQL = sSQL & "FROM dbo.sc_user_ids "
        sSQL = sSQL & "WHERE user_id='" & LCase(Environ("USERNAME")) & "' AND security_zar='Y'"

        Dim rs2 As New ADODB.Recordset
        rs2.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenForwardOnly)
        If Not (rs2.EOF And rs2.BOF) Then
            TCount = rs2.Fields("iCount").Value
        End If

        rs = Nothing

        If TCount = 0 Then
            mnuAdmin.Visible = False
        End If

        '"set the caption
        Dim sVersion As String
        Dim versionNumber As Version

        versionNumber = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version
        Dim sRevision As String = System.Reflection.Assembly.GetExecutingAssembly().GetName.Version.ToString

        sVersion = System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).FileMajorPart & "." & System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).FileMinorPart & "." & sRevision
        Me.Text = "DMV System (v" & sVersion & ")     " & LCase(Environ("USERNAME"))

        Exit Sub
MDIForm_Load_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: MDIForm_Load " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : MDIForm_QueryUnload
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Close the connection
    '---------------------------------------------------------------------------------------
    '
    'UPGRADE_WARNING: Form event MDIForm1.QueryUnload has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
    Private Sub MDIForm1_Closing(ByVal eventSender As System.Object, ByVal eventArgs As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Dim Cancel As Short = eventArgs.Cancel
        On Error Resume Next

        oConn.Close()

        eventArgs.Cancel = Cancel
    End Sub

    Public Sub mnuChangeFTPPassword_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuChangeFTPPassword.Popup
        mnuChangeFTPPassword_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuChangeFTPPassword_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuChangeFTPPassword.Click
        Dim vbcrl As Object
        Dim retval As Object
        On Error GoTo mnuChangeFTPPassword_Click_ErrorHandler

        Dim sGetPassword As String

        'Get the old password
        sGetPassword = RetrieveFieldFrom("Value", "dbo.sc_system", "Name='SFTPPassword'")
        retval = InputBox("Type in the NEW SFTP password.", "New SFTP Password")
        If Len(retval) < 6 Or Len(retval) > 12 Then
            MsgBox("Password must be between 6 and 12 characters long.", MsgBoxStyle.Information, "Reset Password")
            Exit Sub
        End If

        If sGetPassword <> retval Then
            sSQL = "UPDATE dbo.SC_SYSTEM SET VALUE = '" & retval & "' WHERE NAME = 'SFTPPassword'"

            cmd = New ADODB.Command
            With cmd
                .let_ActiveConnection(oConn)
                .CommandType = ADODB.CommandTypeEnum.adCmdText
                .CommandText = sSQL
            End With
            cmd.Execute()

            sSQL = "UPDATE dbo.SC_SYSTEM SET VALUE = '" & Now & "' WHERE NAME = 'SFTPPasswordDate'"

            cmd = New ADODB.Command
            With cmd
                .let_ActiveConnection(oConn)
                .CommandType = ADODB.CommandTypeEnum.adCmdText
                .CommandText = sSQL
            End With
            cmd.Execute()

            MsgBox("Password has been set." & vbCrLf & "The new password is: " & retval & "", MsgBoxStyle.Information, "DMV System")
        Else
            MsgBox("The old password and the new password are the same." & vbCrLf & "Please change your password.", MsgBoxStyle.Critical, "DMV System")
        End If

        Exit Sub

mnuChangeFTPPassword_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: mnuChangeFTPPassword_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Exit Sub

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : mnuDailyImport_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Open the Daily Import form
    '---------------------------------------------------------------------------------------
    '
    Public Sub mnuDailyImport_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuDailyImport.Popup
        mnuDailyImport_Click(eventSender, eventArgs)
    End Sub

    Public Sub mnuDailyImport_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuDailyImport.Click
        On Error GoTo mnuDailyImport_Click_ErrorHandler

        frmProcessDailyImport.DefInstance.Show()

        Exit Sub

mnuDailyImport_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: mnuDailyImport_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : mnuDailyImport_Click
    ' DateTime  : 08/24/2010
    ' Author    : aalvidrez/amunoz
    ' Purpose   : Open the Saturday Import form
    '---------------------------------------------------------------------------------------
    '
    Private Sub mnuSatImport_Click()
        On Error GoTo mnuSatImport_Click_ErrorHandler

        frmProcessSatImport.DefInstance.Show()

        Exit Sub

mnuSatImport_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: mnuSatImport_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : mnuDMVSystem_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Open the DMV system
    '---------------------------------------------------------------------------------------
    '
    Public Sub mnuDMVSystem_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuDMVSystem.Popup
        mnuDMVSystem_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuDMVSystem_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuDMVSystem.Click
        On Error GoTo mnuDMVSystem_Click_ErrorHandler

        'Check for password reset
        ValidUpdate = False
        If GetDMVPassword = "reset" Then
            frmDMVPasswordChange.DefInstance.ShowDialog()
        Else 'Open the form
            frmDMVPassword.DefInstance.ShowDialog()
            If ValidUpdate Then
                AttendanceScreenLoaded = False
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
                'frmTopic = frmMain.DefInstance
                'Dim frm As New frmMain
                frmMain.Show(Me)
                'frm.MdiParent = Me
            End If
        End If

        Exit Sub
mnuDMVSystem_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: mnuDMVSystem_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : mnuExportFile_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Shoe the Employee Add/Delete form
    '---------------------------------------------------------------------------------------
    '
    Public Sub mnuExportFile_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuExportFile.Popup
        mnuExportFile_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuExportFile_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuExportFile.Click
        On Error GoTo mnuExportFile_Click_ErrorHandler

        frmEmployeeAddDelete.DefInstance.Show()

        Exit Sub
mnuExportFile_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: mnuExportFile_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : mnuFileExit_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Exit the application
    '---------------------------------------------------------------------------------------
    '
    Public Sub mnuFileExit_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFileExit.Popup
        mnuFileExit_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuFileExit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFileExit.Click
        On Error Resume Next

        End

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : mnuOptOut_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Open the Optout form
    '---------------------------------------------------------------------------------------
    '
    Public Sub mnuOptOut_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptOut.Popup
        mnuOptOut_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuOptOut_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptOut.Click
        On Error GoTo mnuOptOut_Click_ErrorHandler

        frmOptOut.DefInstance.Show()

        Exit Sub
mnuOptOut_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: mnuOptOut_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : mnuSecurity_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Open the security form
    '---------------------------------------------------------------------------------------
    '
    Public Sub mnuSecurity_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuSecurity.Popup
        mnuSecurity_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuSecurity_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuSecurity.Click
        On Error GoTo mnuSecurity_Click_ErrorHandler

        frmDMVSecurity.DefInstance.Show()

        Exit Sub
mnuSecurity_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: mnuSecurity_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : mnuVehicleCheckout_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Open the Vehicle Checkout form
    '---------------------------------------------------------------------------------------
    '
    Public Sub mnuVehicleCheckout_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuVehicleCheckout.Popup
        mnuVehicleCheckout_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuVehicleCheckout_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuVehicleCheckout.Click
        On Error GoTo mnuVehicleCheckout_Click_ErrorHandler

        frmDMVVehicleCheckOut.DefInstance.ShowDialog()

        Exit Sub
mnuVehicleCheckout_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: mnuVehicleCheckout_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : mnuProcessImport_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Open the Vehicle Checkout form
    '---------------------------------------------------------------------------------------
    '
    Public Sub mnuProcessImport_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuProcessImport.Popup
        mnuProcessImport_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuProcessImport_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuProcessImport.Click
        On Error GoTo mnuProcessImport_Click_ErrorHandler

        frmProcessVolReqst.DefInstance.ShowDialog()

        Exit Sub
mnuProcessImport_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: mnuProcessImport_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : mnuDeleteTermedEmp_Click
    ' DateTime  : 02/08/2012
    ' Author    : aalvidrez
    ' Purpose   : Delete Termed employees from database
    '---------------------------------------------------------------------------------------
    '
    Public Sub mnuDeleteTermedEmp_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuDeleteTermedEmp.Popup
        mnuDeleteTermedEmp_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuDeleteTermedEmp_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuDeleteTermedEmp.Click
        Dim retval As Object
        On Error GoTo mnuDeleteTermedEmp_Click_ErrorHandler

        retval = MsgBox("Are you sure you want to delete all termed employees from the HR database?", MsgBoxStyle.YesNo, "DMV System - Confirm Delete")

        If retval = MsgBoxResult.Yes Then
            sSQL = "DELETE dbo.hr_dmv_employees "
            sSQL = sSQL & "WHERE employee_id "
            sSQL = sSQL & "NOT IN(SELECT employee_id FROM dbo.hr_c_employees "
            sSQL = sSQL & "WHERE (employment_status LIKE 'A%' OR employment_status LIKE 'L%')) "
            sSQL = sSQL & "AND employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout)"

            cmd = New ADODB.Command
            With cmd
                .let_ActiveConnection(oConn)
                .CommandType = ADODB.CommandTypeEnum.adCmdText
                .CommandText = sSQL
            End With
            cmd.Execute()
            MsgBox("Records have been successfully deleted", MsgBoxStyle.Information, "DMV System")
        End If

        Exit Sub
mnuDeleteTermedEmp_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: mnuDeleteTermedEmp_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
End Class