Option Strict Off
Option Explicit On
'Imports VB = Microsoft.VisualBasic
Friend Class frmEmployeeAddDelete
    Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
    Public Sub New()
        MyBase.New()
        If m_vb6FormDefInstance Is Nothing Then
            If m_InitializingDefInstance Then
                m_vb6FormDefInstance = Me
            Else
                Try
                    'For the start-up form, the first instance created is the default instance.
                    If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
                        m_vb6FormDefInstance = Me
                    End If
                Catch
                End Try
            End If
        End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents cmdExpiredRecords As System.Windows.Forms.Button
    Public WithEvents cmdSelectAllForDelete As System.Windows.Forms.Button
    Public WithEvents cmdRemoveAllFromDelete As System.Windows.Forms.Button
    Public WithEvents cmdRemoveAll As System.Windows.Forms.Button
    Public WithEvents cmdSelectAll As System.Windows.Forms.Button
    Public WithEvents cmdRemoveAdd As System.Windows.Forms.Button
    Public WithEvents cmdMissingFromHR As System.Windows.Forms.Button
    Public WithEvents cmdShowAll As System.Windows.Forms.Button
    Public WithEvents cmdShowMissing As System.Windows.Forms.Button
    Public WithEvents cmdFTPFile As System.Windows.Forms.Button
    Public WithEvents cmdClose As System.Windows.Forms.Button
    Public WithEvents cmdExportFile As System.Windows.Forms.Button
    Public WithEvents cmdRemoveDelete As System.Windows.Forms.Button
    Public WithEvents cmdDeleteEmployee As System.Windows.Forms.Button
    Public WithEvents cmdAddEmployee As System.Windows.Forms.Button
    Public WithEvents lstDeleteEmployee As System.Windows.Forms.ListBox
    Public WithEvents lstAddEmployee As System.Windows.Forms.ListBox
    Public WithEvents lstEmployeeList As System.Windows.Forms.ListBox
    Public WithEvents Line1 As System.Windows.Forms.Label
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents lblEmployeeList As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEmployeeAddDelete))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdExpiredRecords = New System.Windows.Forms.Button()
        Me.cmdSelectAllForDelete = New System.Windows.Forms.Button()
        Me.cmdRemoveAllFromDelete = New System.Windows.Forms.Button()
        Me.cmdRemoveAll = New System.Windows.Forms.Button()
        Me.cmdSelectAll = New System.Windows.Forms.Button()
        Me.cmdRemoveAdd = New System.Windows.Forms.Button()
        Me.cmdMissingFromHR = New System.Windows.Forms.Button()
        Me.cmdShowAll = New System.Windows.Forms.Button()
        Me.cmdShowMissing = New System.Windows.Forms.Button()
        Me.cmdFTPFile = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdExportFile = New System.Windows.Forms.Button()
        Me.cmdRemoveDelete = New System.Windows.Forms.Button()
        Me.cmdDeleteEmployee = New System.Windows.Forms.Button()
        Me.cmdAddEmployee = New System.Windows.Forms.Button()
        Me.lstDeleteEmployee = New System.Windows.Forms.ListBox()
        Me.lstAddEmployee = New System.Windows.Forms.ListBox()
        Me.lstEmployeeList = New System.Windows.Forms.ListBox()
        Me.Line1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblEmployeeList = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdExpiredRecords
        '
        Me.cmdExpiredRecords.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExpiredRecords.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExpiredRecords.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExpiredRecords.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExpiredRecords.Location = New System.Drawing.Point(371, 410)
        Me.cmdExpiredRecords.Name = "cmdExpiredRecords"
        Me.cmdExpiredRecords.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExpiredRecords.Size = New System.Drawing.Size(91, 22)
        Me.cmdExpiredRecords.TabIndex = 20
        Me.cmdExpiredRecords.Text = "&Expired Records"
        Me.cmdExpiredRecords.UseVisualStyleBackColor = False
        '
        'cmdSelectAllForDelete
        '
        Me.cmdSelectAllForDelete.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSelectAllForDelete.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSelectAllForDelete.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSelectAllForDelete.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSelectAllForDelete.Location = New System.Drawing.Point(297, 344)
        Me.cmdSelectAllForDelete.Name = "cmdSelectAllForDelete"
        Me.cmdSelectAllForDelete.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSelectAllForDelete.Size = New System.Drawing.Size(44, 22)
        Me.cmdSelectAllForDelete.TabIndex = 19
        Me.cmdSelectAllForDelete.Text = ">>All"
        Me.cmdSelectAllForDelete.UseVisualStyleBackColor = False
        '
        'cmdRemoveAllFromDelete
        '
        Me.cmdRemoveAllFromDelete.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemoveAllFromDelete.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRemoveAllFromDelete.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRemoveAllFromDelete.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRemoveAllFromDelete.Location = New System.Drawing.Point(297, 367)
        Me.cmdRemoveAllFromDelete.Name = "cmdRemoveAllFromDelete"
        Me.cmdRemoveAllFromDelete.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRemoveAllFromDelete.Size = New System.Drawing.Size(44, 22)
        Me.cmdRemoveAllFromDelete.TabIndex = 18
        Me.cmdRemoveAllFromDelete.Text = "<<All"
        Me.cmdRemoveAllFromDelete.UseVisualStyleBackColor = False
        '
        'cmdRemoveAll
        '
        Me.cmdRemoveAll.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemoveAll.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRemoveAll.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRemoveAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRemoveAll.Location = New System.Drawing.Point(297, 151)
        Me.cmdRemoveAll.Name = "cmdRemoveAll"
        Me.cmdRemoveAll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRemoveAll.Size = New System.Drawing.Size(44, 22)
        Me.cmdRemoveAll.TabIndex = 17
        Me.cmdRemoveAll.Text = "<<All"
        Me.cmdRemoveAll.UseVisualStyleBackColor = False
        '
        'cmdSelectAll
        '
        Me.cmdSelectAll.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSelectAll.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSelectAll.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSelectAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSelectAll.Location = New System.Drawing.Point(297, 128)
        Me.cmdSelectAll.Name = "cmdSelectAll"
        Me.cmdSelectAll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSelectAll.Size = New System.Drawing.Size(44, 22)
        Me.cmdSelectAll.TabIndex = 16
        Me.cmdSelectAll.Text = ">>All"
        Me.cmdSelectAll.UseVisualStyleBackColor = False
        '
        'cmdRemoveAdd
        '
        Me.cmdRemoveAdd.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemoveAdd.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRemoveAdd.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRemoveAdd.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRemoveAdd.Location = New System.Drawing.Point(297, 91)
        Me.cmdRemoveAdd.Name = "cmdRemoveAdd"
        Me.cmdRemoveAdd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRemoveAdd.Size = New System.Drawing.Size(44, 29)
        Me.cmdRemoveAdd.TabIndex = 15
        Me.cmdRemoveAdd.Text = "<<"
        Me.cmdRemoveAdd.UseVisualStyleBackColor = False
        '
        'cmdMissingFromHR
        '
        Me.cmdMissingFromHR.BackColor = System.Drawing.SystemColors.Control
        Me.cmdMissingFromHR.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdMissingFromHR.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMissingFromHR.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdMissingFromHR.Location = New System.Drawing.Point(265, 410)
        Me.cmdMissingFromHR.Name = "cmdMissingFromHR"
        Me.cmdMissingFromHR.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdMissingFromHR.Size = New System.Drawing.Size(102, 22)
        Me.cmdMissingFromHR.TabIndex = 14
        Me.cmdMissingFromHR.Text = "&Missing From HR"
        Me.cmdMissingFromHR.UseVisualStyleBackColor = False
        '
        'cmdShowAll
        '
        Me.cmdShowAll.BackColor = System.Drawing.SystemColors.Control
        Me.cmdShowAll.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdShowAll.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdShowAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdShowAll.Location = New System.Drawing.Point(73, 410)
        Me.cmdShowAll.Name = "cmdShowAll"
        Me.cmdShowAll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdShowAll.Size = New System.Drawing.Size(72, 22)
        Me.cmdShowAll.TabIndex = 13
        Me.cmdShowAll.Text = "Show &All"
        Me.cmdShowAll.UseVisualStyleBackColor = False
        '
        'cmdShowMissing
        '
        Me.cmdShowMissing.BackColor = System.Drawing.SystemColors.Control
        Me.cmdShowMissing.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdShowMissing.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdShowMissing.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdShowMissing.Location = New System.Drawing.Point(149, 410)
        Me.cmdShowMissing.Name = "cmdShowMissing"
        Me.cmdShowMissing.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdShowMissing.Size = New System.Drawing.Size(112, 22)
        Me.cmdShowMissing.TabIndex = 12
        Me.cmdShowMissing.Text = "&Missing From DMV"
        Me.cmdShowMissing.UseVisualStyleBackColor = False
        '
        'cmdFTPFile
        '
        Me.cmdFTPFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdFTPFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdFTPFile.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdFTPFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdFTPFile.Location = New System.Drawing.Point(549, 410)
        Me.cmdFTPFile.Name = "cmdFTPFile"
        Me.cmdFTPFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdFTPFile.Size = New System.Drawing.Size(64, 22)
        Me.cmdFTPFile.TabIndex = 11
        Me.cmdFTPFile.Text = "FTP File"
        Me.cmdFTPFile.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(12, 410)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(57, 22)
        Me.cmdClose.TabIndex = 10
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdExportFile
        '
        Me.cmdExportFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExportFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExportFile.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExportFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExportFile.Location = New System.Drawing.Point(466, 410)
        Me.cmdExportFile.Name = "cmdExportFile"
        Me.cmdExportFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExportFile.Size = New System.Drawing.Size(79, 22)
        Me.cmdExportFile.TabIndex = 9
        Me.cmdExportFile.Text = "CreateFile"
        Me.cmdExportFile.UseVisualStyleBackColor = False
        '
        'cmdRemoveDelete
        '
        Me.cmdRemoveDelete.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemoveDelete.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRemoveDelete.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRemoveDelete.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRemoveDelete.Location = New System.Drawing.Point(297, 293)
        Me.cmdRemoveDelete.Name = "cmdRemoveDelete"
        Me.cmdRemoveDelete.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRemoveDelete.Size = New System.Drawing.Size(44, 29)
        Me.cmdRemoveDelete.TabIndex = 5
        Me.cmdRemoveDelete.Text = "<<"
        Me.cmdRemoveDelete.UseVisualStyleBackColor = False
        '
        'cmdDeleteEmployee
        '
        Me.cmdDeleteEmployee.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDeleteEmployee.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDeleteEmployee.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDeleteEmployee.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDeleteEmployee.Location = New System.Drawing.Point(297, 263)
        Me.cmdDeleteEmployee.Name = "cmdDeleteEmployee"
        Me.cmdDeleteEmployee.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDeleteEmployee.Size = New System.Drawing.Size(44, 29)
        Me.cmdDeleteEmployee.TabIndex = 4
        Me.cmdDeleteEmployee.Text = ">>"
        Me.cmdDeleteEmployee.UseVisualStyleBackColor = False
        '
        'cmdAddEmployee
        '
        Me.cmdAddEmployee.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddEmployee.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddEmployee.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddEmployee.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddEmployee.Location = New System.Drawing.Point(297, 61)
        Me.cmdAddEmployee.Name = "cmdAddEmployee"
        Me.cmdAddEmployee.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAddEmployee.Size = New System.Drawing.Size(44, 29)
        Me.cmdAddEmployee.TabIndex = 3
        Me.cmdAddEmployee.Text = ">>"
        Me.cmdAddEmployee.UseVisualStyleBackColor = False
        '
        'lstDeleteEmployee
        '
        Me.lstDeleteEmployee.BackColor = System.Drawing.SystemColors.Window
        Me.lstDeleteEmployee.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstDeleteEmployee.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstDeleteEmployee.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstDeleteEmployee.ItemHeight = 14
        Me.lstDeleteEmployee.Location = New System.Drawing.Point(358, 236)
        Me.lstDeleteEmployee.Name = "lstDeleteEmployee"
        Me.lstDeleteEmployee.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstDeleteEmployee.Size = New System.Drawing.Size(250, 158)
        Me.lstDeleteEmployee.TabIndex = 2
        '
        'lstAddEmployee
        '
        Me.lstAddEmployee.BackColor = System.Drawing.SystemColors.Window
        Me.lstAddEmployee.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstAddEmployee.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstAddEmployee.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstAddEmployee.ItemHeight = 14
        Me.lstAddEmployee.Location = New System.Drawing.Point(353, 31)
        Me.lstAddEmployee.Name = "lstAddEmployee"
        Me.lstAddEmployee.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstAddEmployee.Size = New System.Drawing.Size(250, 158)
        Me.lstAddEmployee.TabIndex = 1
        '
        'lstEmployeeList
        '
        Me.lstEmployeeList.BackColor = System.Drawing.SystemColors.Window
        Me.lstEmployeeList.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstEmployeeList.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstEmployeeList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstEmployeeList.ItemHeight = 14
        Me.lstEmployeeList.Location = New System.Drawing.Point(27, 29)
        Me.lstEmployeeList.Name = "lstEmployeeList"
        Me.lstEmployeeList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstEmployeeList.Size = New System.Drawing.Size(250, 368)
        Me.lstEmployeeList.TabIndex = 0
        '
        'Line1
        '
        Me.Line1.BackColor = System.Drawing.SystemColors.WindowText
        Me.Line1.Location = New System.Drawing.Point(13, 403)
        Me.Line1.Name = "Line1"
        Me.Line1.Size = New System.Drawing.Size(603, 1)
        Me.Line1.TabIndex = 21
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(359, 216)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(250, 16)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Employee's to Delete"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(355, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(250, 15)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Employee's to Add"
        '
        'lblEmployeeList
        '
        Me.lblEmployeeList.BackColor = System.Drawing.SystemColors.Control
        Me.lblEmployeeList.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblEmployeeList.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmployeeList.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEmployeeList.Location = New System.Drawing.Point(29, 14)
        Me.lblEmployeeList.Name = "lblEmployeeList"
        Me.lblEmployeeList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblEmployeeList.Size = New System.Drawing.Size(250, 16)
        Me.lblEmployeeList.TabIndex = 6
        Me.lblEmployeeList.Text = "Employee List"
        '
        'frmEmployeeAddDelete
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(631, 445)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdExpiredRecords)
        Me.Controls.Add(Me.cmdSelectAllForDelete)
        Me.Controls.Add(Me.cmdRemoveAllFromDelete)
        Me.Controls.Add(Me.cmdRemoveAll)
        Me.Controls.Add(Me.cmdSelectAll)
        Me.Controls.Add(Me.cmdRemoveAdd)
        Me.Controls.Add(Me.cmdMissingFromHR)
        Me.Controls.Add(Me.cmdShowAll)
        Me.Controls.Add(Me.cmdShowMissing)
        Me.Controls.Add(Me.cmdFTPFile)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.cmdExportFile)
        Me.Controls.Add(Me.cmdRemoveDelete)
        Me.Controls.Add(Me.cmdDeleteEmployee)
        Me.Controls.Add(Me.cmdAddEmployee)
        Me.Controls.Add(Me.lstDeleteEmployee)
        Me.Controls.Add(Me.lstAddEmployee)
        Me.Controls.Add(Me.lstEmployeeList)
        Me.Controls.Add(Me.Line1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblEmployeeList)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmEmployeeAddDelete"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Employee Add/Delete"
        Me.ResumeLayout(False)

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmEmployeeAddDelete
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmEmployeeAddDelete
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmEmployeeAddDelete()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set(value As frmEmployeeAddDelete)
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdAddEmployee_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Add an employee to the "Add" list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdAddEmployee_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAddEmployee.Click
        On Error GoTo cmdAddEmployee_Click_ErrorHandler

        'Make sure we have a current record
        If lstEmployeeList.Text <> "" Then
            lstAddEmployee.Items.Add(lstEmployeeList.Text)
        End If

        Exit Sub
cmdAddEmployee_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdAddEmployee_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdClose_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Close the form
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
        On Error Resume Next

        Me.Close()

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdDeleteEmployee_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Add an employee to the "Delete" list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdDeleteEmployee_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdDeleteEmployee.Click
        On Error GoTo cmdDeleteEmployee_Click_ErrorHandler

        'Make sure we have a current record
        If lstEmployeeList.Text <> "" Then
            lstDeleteEmployee.Items.Add(lstEmployeeList.Text)
        End If

        Exit Sub
cmdDeleteEmployee_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdDeleteEmployee " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdExpiredRecords_Click
    ' DateTime  : 03/19/2010
    ' Author    : aalvidrez
    ' Purpose   : Show employees with Expired Records
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdExpiredRecords_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExpiredRecords.Click
        On Error GoTo cmdExpiredRecords_ErrorHandler

        'Clear the list
        lstEmployeeList.Items.Clear()

        sSQL = "SELECT dmv_employee_name  + ' - ' +  dbo.DecryptData(drivers_license_no) AS emp_name " & "From dbo.HR_DMV_EMPLOYEES " & "WHERE employee_id IN(SELECT employee_id FROM dbo.HR_C_EMPLOYEES WHERE (employment_status LIKE 'A%' OR employment_status LIKE 'L%')) " & "AND employee_id NOT IN(SELECT employee_id FROM dbo.HR_DMV_OPTOUT) " & "AND DATEDIFF(d, record_date, GETDATE()) >= 365 " & "ORDER BY 1"
        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        'Populate the list
        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                lstEmployeeList.Items.Add(rs.Fields("emp_name").Value)
                rs.MoveNext()
            Loop
        Else
            lstEmployeeList.Items.Add("No Expired Records exist")
        End If

        lblEmployeeList.Text = "Expired Records"

        Exit Sub

cmdExpiredRecords_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdExpiredRecords " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdExportFile_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Create an Export file for the EPN Add/Delete VPN process
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdExportFile_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExportFile.Click
        Dim i As Object
        On Error GoTo cmdExportFile_Click_ErrorHandler

        Dim sStr As String
        Dim iFileNo As Short

        iFileNo = FreeFile

        'Create and open the file
        FileOpen(iFileNo, FILE_PATH & "\DMV_Export_Add_Delete.dat", OpenMode.Output)

        'Write to the file (row by row from the list box)
        If lstAddEmployee.Items.Count > 0 Then
            For i = 0 To lstAddEmployee.Items.Count - 1
                'PrintLine(iFileNo, VB.Right(lstAddEmployee.Items(i).ToString, 8) & "1" & VB.Left(lstAddEmployee.Items(i).ToString, 3) & "A99993504267198                     ")
                PrintLine(iFileNo, lstAddEmployee.Items(i).ToString.Substring(lstAddEmployee.Items(i).ToString.Length - 8) & "1" & lstAddEmployee.Items(i).ToString.Substring(0, 3) & "A99993504267198                     ")
            Next i
        End If

        'Add the "Deleted" from list to the file
        If lstDeleteEmployee.Items.Count > 0 Then
            For i = 0 To lstDeleteEmployee.Items.Count - 1
                'PrintLine(iFileNo, VB.Right(lstAddEmployee.Items(i).ToString, 8) & "1" & VB.Left(lstAddEmployee.Items(i).ToString, 3) & "D99993504267198                     ")
                PrintLine(iFileNo, lstDeleteEmployee.Items(i).ToString.Substring(lstDeleteEmployee.Items(i).ToString.Length - 8) & "1" & lstDeleteEmployee.Items(i).ToString.Substring(0, 3) & "D99993504267198                     ")
            Next i
        End If

        'Close the file
        FileClose(iFileNo)

        MsgBox("File Transfer Complete", MsgBoxStyle.Information, "Export File")

        Exit Sub
cmdExportFile_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdExportFile_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub cmdFTPFile_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdFTPFile.Click
        On Error GoTo cmdFTPFile_Click_Error

        Dim retval As String
        Dim sPath As String
        Dim iFileNo As Short

        MsgBox("Make sure you are connected via VPN to the DMV.", MsgBoxStyle.Information, "DMV System")

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        'Create and open the file
        iFileNo = FreeFile
        FileOpen(iFileNo, FILE_PATH & "\DMV_PUT_ADD_DELETE.ftp", OpenMode.Output)

        'Populate the file
        retval = InputBox("Enter the FTP Password", "Password...")
        If retval <> "" Then
            PrintLine(iFileNo, "open mvs.teale.ca.gov")
            PrintLine(iFileNo, "user mvxocta")
            PrintLine(iFileNo, retval)
            PrintLine(iFileNo, "ascii")
            PrintLine(iFileNo, "put " & FILE_PATH & "\DMV_Export_Add_Delete.dat 'mv.employer.pull.r67198.in'")
            PrintLine(iFileNo, "close")
            PrintLine(iFileNo, "quit")
        End If

        FileClose(iFileNo)

        retval = CStr(Shell(FILE_PATH & "\DMV_PUT_ADD_DELETE.bat", AppWinStyle.NormalFocus))

cmdFTPFile_Click_Exit:
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Exit Sub

cmdFTPFile_Click_Error:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdFTPFile_Click" & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume cmdFTPFile_Click_Exit

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdMissingFromHR_Click
    ' DateTime  : 08/9/2007
    ' Author    : aalvidrez
    ' Purpose   : Show employees missing from HR
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdMissingFromHR_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdMissingFromHR.Click
        On Error GoTo cmdMissingFromHR_ErrorHandler

        'Clear the list
        lstEmployeeList.Items.Clear()

        sSQL = "SELECT dmv_employee_name + ' - ' + dbo.DecryptData(drivers_license_no) AS emp_name" & " From dbo.hr_dmv_employees" & " WHERE employee_id NOT IN(SELECT employee_id FROM dbo.hr_c_employees WHERE (employment_status LIKE 'A%' OR employment_status LIKE 'L%')) " & " AND employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout)" & " ORDER BY 1"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        'Populate the list
        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                lstEmployeeList.Items.Add(rs.Fields("emp_name").Value)
                rs.MoveNext()
            Loop
        Else
            lstEmployeeList.Items.Add("No Missing from HR Records exist")
        End If

        lblEmployeeList.Text = "In DMV/Not in HR"

        Exit Sub
cmdMissingFromHR_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdMissingFromHR " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdRemoveAdd_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Remove an employee from the "Add" list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdRemoveAdd_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRemoveAdd.Click
        On Error GoTo cmdRemoveAdd_Click_ErrorHandler

        'Make sure we have a current record
        If lstAddEmployee.Text <> "" Then
            lstAddEmployee.Items.RemoveAt((lstAddEmployee.SelectedIndex))
        End If

        Exit Sub
cmdRemoveAdd_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdRemoveAdd_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdRemoveAll_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Remove all employees from the "Add" list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdRemoveAll_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRemoveAll.Click
        Dim i As Object
        On Error GoTo cmdRemoveAll_Click_ErrorHandler

        'Make sure we have a current record
        For i = 0 To lstAddEmployee.Items.Count - 1
            lstAddEmployee.Items.RemoveAt(0)
        Next i

        Exit Sub
cmdRemoveAll_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdRemoveAll_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdRemoveAllFromDelete_Click
    ' DateTime  : 9/5/2007
    ' Author    : aalvidrez
    ' Purpose   : Remove all employees from the list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdRemoveAllFromDelete_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRemoveAllFromDelete.Click
        Dim i As Object
        On Error GoTo cmdRemoveAllFromDelete_Click_ErrorHandler

        'Remove all items
        For i = 0 To lstDeleteEmployee.Items.Count - 1
            lstDeleteEmployee.Items.RemoveAt(0)
        Next i

        Exit Sub
cmdRemoveAllFromDelete_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdRemoveAllFromDelete_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdRemoveDelete_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Remove and employee from the "Delete" list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdRemoveDelete_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRemoveDelete.Click
        On Error GoTo cmdRemoveDelete_Click_ErrorHandler

        'Make sure we have a current record
        If lstDeleteEmployee.Text <> "" Then
            lstDeleteEmployee.Items.RemoveAt((lstDeleteEmployee.SelectedIndex))
        End If

        Exit Sub
cmdRemoveDelete_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdRemoveDelete_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdSelectAll_Click
    ' DateTime  : 9/5/2007
    ' Author    : aalvidrez
    ' Purpose   : Add all employees to the "Add" list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdSelectAll_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSelectAll.Click
        Dim i As Object
        On Error GoTo cmdSelectAll_Click_ErrorHandler

        'Add all items
        For i = 0 To lstEmployeeList.Items.Count - 1
            'lstAddEmployee.Items.Add(VB6.GetItemString(lstEmployeeList, i))
            lstAddEmployee.Items.Add(lstEmployeeList.Items(i).ToString)
        Next i

        Exit Sub
cmdSelectAll_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdSelectAll_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdSelectAllForDelete_Click
    ' DateTime  : 9/5/2007
    ' Author    : aalvidrez
    ' Purpose   : Add all employees to the "Delete" list
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdSelectAllForDelete_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSelectAllForDelete.Click
        Dim i As Object
        On Error GoTo cmdSelectAllForDelete_Click_ErrorHandler

        'Add all items
        For i = 0 To lstEmployeeList.Items.Count - 1
            'lstDeleteEmployee.Items.Add(VB6.GetItemString(lstEmployeeList, i))
            lstDeleteEmployee.Items.Add(lstEmployeeList.Items(i).ToString)
        Next i

        Exit Sub
cmdSelectAllForDelete_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdSelectAllForDelete_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub cmdShowAll_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdShowAll.Click

        LoadEmployeeList()

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : cmdShowMissing_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the employee list with missing employees
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdShowMissing_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdShowMissing.Click
        On Error GoTo cmdShowMissing_ErrorHandler

        'Clear the list
        lstEmployeeList.Items.Clear()

        sSQL = "SELECT last_name + ', ' + first_name +' - ' + dbo.DecryptData(drivers_license) AS emp_name" & " From dbo.HR_C_EMPLOYEES" & " WHERE (employment_status LIKE 'A%' OR employment_status LIKE 'L%')" & " AND (employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_employees))" & " AND (employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout))" & " AND (last_name + ', ' + first_name +' - ' + dbo.DecryptData(drivers_license) IS NOT NULL)" & " ORDER BY 1"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        'Populate the list
        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                lstEmployeeList.Items.Add(rs.Fields("emp_name").Value)
                rs.MoveNext()
            Loop
        Else
            lstEmployeeList.Items.Add("No Missing Employee Records exist")
        End If

        lblEmployeeList.Text = "In HR/Not in DMV"

        Exit Sub
cmdShowMissing_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdShowMissing " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : Form_Load
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the form
    '---------------------------------------------------------------------------------------
    '
    Private Sub frmEmployeeAddDelete_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        On Error Resume Next

        'LoadEmployeeList

        Exit Sub
Form_Load_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: Form_Load " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : LoadEmployeeList
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the employee list
    '---------------------------------------------------------------------------------------
    '
    Public Sub LoadEmployeeList()
        On Error GoTo LoadEmployeeList_ErrorHandler

        'Clear the list
        lstEmployeeList.Items.Clear()

        sSQL = "SELECT * FROM dbo.vwEmployeeExportList"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        'Populate the list
        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                lstEmployeeList.Items.Add(rs.Fields("emp_name").Value)
                rs.MoveNext()
            Loop
        End If

        lblEmployeeList.Text = "Employee List"

        Exit Sub
LoadEmployeeList_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: LoadEmployeeList " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub lstAddEmployee_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstAddEmployee.DoubleClick

        'Make sure we have a current record
        If lstAddEmployee.Text <> "" Then
            lstAddEmployee.Items.RemoveAt((lstAddEmployee.SelectedIndex))
        End If

    End Sub

    Private Sub lstDeleteEmployee_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstDeleteEmployee.DoubleClick

        'Make sure we have a current record
        If lstDeleteEmployee.Text <> "" Then
            lstDeleteEmployee.Items.RemoveAt((lstDeleteEmployee.SelectedIndex))
        End If

    End Sub

    Private Sub lstEmployeeList_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstEmployeeList.DoubleClick

        'Make sure we have a current record
        If lstEmployeeList.Text <> "" Then
            lstAddEmployee.Items.Add(lstEmployeeList.Text)
        End If

    End Sub
End Class