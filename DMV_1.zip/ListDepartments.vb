﻿Partial Class ListDepartments
End Class
