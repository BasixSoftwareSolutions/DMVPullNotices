﻿Public Class frmViewViolatioDetails

    Public Sub LoadViolationGrid()
        On Error GoTo GetViolations_ErrorHandler

        'Clear the grid
        lblViolationDetails.Text = ""
        grdViolationDetails.Rows.Clear()
        grdViolationDetails.AutoGenerateColumns = False

        sSQL = "SELECT DISTINCT *" _
                & " FROM vwGetViolationRecords " _
                & " WHERE EMPLOYEE_ID ='" & Me.txtEmpID.Text & "'" _
                & " AND [DOCKET/FILE NO] = '" & Me.txtDocketNo.Text & "'"

        StandardResultSet()

        If rs.RecordCount = 0 Then
            Me.lblViolationDetails.Text = "No Violation Records Found"
            Exit Sub
        End If

        Dim k As Integer = 0

        rs.MoveFirst()
        While Not rs.EOF
            grdViolationDetails.Rows.Add()
            grdViolationDetails.Rows(k).Cells("ACTION_TAKEN").Value = rs.Fields("ACTION TAKEN").Value
            grdViolationDetails.Rows(k).Cells("TO_BE_RESOLVED_BY").Value = rs.Fields("TO BE RESOLVED BY").Value
            grdViolationDetails.Rows(k).Cells("RESOLVED_DATE").Value = rs.Fields("RESOLVED DATE").Value
            grdViolationDetails.Rows(k).Cells("LAST_UPDATE_BY").Value = rs.Fields("LAST UPDATE BY").Value
            grdViolationDetails.Rows(k).Cells("LAST_UPDATE").Value = rs.Fields("LAST UPDATE").Value
            grdViolationDetails.Rows(k).Cells("SEQUENCE").Value = rs.Fields("SEQUENCE").Value
            k += 1
            rs.MoveNext()
        End While

        Me.lblViolationDetails.Text = IIf(k < 1, "No", k & " Violation Records Found for Employee: " & Me.txtEmpID.Text & " / Docket: " & Me.txtDocketNo.Text & "")

        Exit Sub
GetViolations_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: GetViolations " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Exit Sub

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        Me.Close()

    End Sub
End Class