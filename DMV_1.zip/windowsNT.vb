Option Strict Off
Option Explicit On
Module windowsNT
	
	' register window's dll
	Private Declare Function WNetGetUser Lib "mpr.dll"  Alias "WNetGetUserA"(ByVal lpName As String, ByVal lpUserName As String, ByRef lpnLength As Integer) As Integer
	Function GetUser() As String
		On Error GoTo GetUser_ErrorHandler
		
		Dim sUserNameBuff As String
		sUserNameBuff = Space(255)
		Call WNetGetUser(vbNullString, sUserNameBuff, Len(sUserNameBuff))
		GetUser = Left(sUserNameBuff, InStr(sUserNameBuff, vbNullChar) - 1)
		
		Exit Function
GetUser_ErrorHandler: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: GetUser " & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
		sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
		MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
		Resume Next
		
	End Function
End Module