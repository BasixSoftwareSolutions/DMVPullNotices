﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmViewViolatioDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmViewViolatioDetails))
        Me.grdViolationDetails = New System.Windows.Forms.DataGridView()
        Me.Action_Taken = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.To_Be_Resolved_by = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Resolved_Date = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Last_Update_By = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Last_Update = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Sequence = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblViolationDetails = New System.Windows.Forms.Label()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.txtEmpID = New System.Windows.Forms.TextBox()
        Me.txtDocketNo = New System.Windows.Forms.TextBox()
        CType(Me.grdViolationDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grdViolationDetails
        '
        Me.grdViolationDetails.AllowUserToAddRows = False
        Me.grdViolationDetails.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.grdViolationDetails.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdViolationDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.grdViolationDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdViolationDetails.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Action_Taken, Me.To_Be_Resolved_by, Me.Resolved_Date, Me.Last_Update_By, Me.Last_Update, Me.Sequence})
        Me.grdViolationDetails.Location = New System.Drawing.Point(17, 30)
        Me.grdViolationDetails.MultiSelect = False
        Me.grdViolationDetails.Name = "grdViolationDetails"
        Me.grdViolationDetails.ReadOnly = True
        Me.grdViolationDetails.Size = New System.Drawing.Size(810, 222)
        Me.grdViolationDetails.TabIndex = 0
        '
        'Action_Taken
        '
        Me.Action_Taken.HeaderText = "Action Taken"
        Me.Action_Taken.Name = "Action_Taken"
        Me.Action_Taken.ReadOnly = True
        '
        'To_Be_Resolved_by
        '
        Me.To_Be_Resolved_by.HeaderText = "Resolved By"
        Me.To_Be_Resolved_by.Name = "To_Be_Resolved_by"
        Me.To_Be_Resolved_by.ReadOnly = True
        '
        'Resolved_Date
        '
        Me.Resolved_Date.HeaderText = "Resolved Date"
        Me.Resolved_Date.Name = "Resolved_Date"
        Me.Resolved_Date.ReadOnly = True
        '
        'Last_Update_By
        '
        Me.Last_Update_By.HeaderText = "Last Update By"
        Me.Last_Update_By.Name = "Last_Update_By"
        Me.Last_Update_By.ReadOnly = True
        '
        'Last_Update
        '
        Me.Last_Update.HeaderText = "Last Update"
        Me.Last_Update.Name = "Last_Update"
        Me.Last_Update.ReadOnly = True
        '
        'Sequence
        '
        Me.Sequence.HeaderText = "Sequence"
        Me.Sequence.Name = "Sequence"
        Me.Sequence.ReadOnly = True
        '
        'lblViolationDetails
        '
        Me.lblViolationDetails.AutoSize = True
        Me.lblViolationDetails.Location = New System.Drawing.Point(23, 10)
        Me.lblViolationDetails.Name = "lblViolationDetails"
        Me.lblViolationDetails.Size = New System.Drawing.Size(82, 13)
        Me.lblViolationDetails.TabIndex = 1
        Me.lblViolationDetails.Text = "Violation Details"
        '
        'cmdClose
        '
        Me.cmdClose.Location = New System.Drawing.Point(27, 264)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(99, 25)
        Me.cmdClose.TabIndex = 2
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseVisualStyleBackColor = True
        '
        'txtEmpID
        '
        Me.txtEmpID.Location = New System.Drawing.Point(624, 268)
        Me.txtEmpID.Name = "txtEmpID"
        Me.txtEmpID.Size = New System.Drawing.Size(85, 20)
        Me.txtEmpID.TabIndex = 3
        Me.txtEmpID.Visible = False
        '
        'txtDocketNo
        '
        Me.txtDocketNo.Location = New System.Drawing.Point(715, 268)
        Me.txtDocketNo.Name = "txtDocketNo"
        Me.txtDocketNo.Size = New System.Drawing.Size(85, 20)
        Me.txtDocketNo.TabIndex = 4
        Me.txtDocketNo.Visible = False
        '
        'frmViewViolatioDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(846, 303)
        Me.Controls.Add(Me.txtDocketNo)
        Me.Controls.Add(Me.txtEmpID)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.lblViolationDetails)
        Me.Controls.Add(Me.grdViolationDetails)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmViewViolatioDetails"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Violation Details"
        CType(Me.grdViolationDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grdViolationDetails As System.Windows.Forms.DataGridView
    Friend WithEvents lblViolationDetails As System.Windows.Forms.Label
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents txtEmpID As System.Windows.Forms.TextBox
    Friend WithEvents txtDocketNo As System.Windows.Forms.TextBox
    Friend WithEvents Action_Taken As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents To_Be_Resolved_by As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Resolved_Date As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Last_Update_By As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Last_Update As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Sequence As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
