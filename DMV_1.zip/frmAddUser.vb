Option Strict Off
Option Explicit On
Friend Class frmAddUser
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents cmdCancel As System.Windows.Forms.Button
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents cmdSave As System.Windows.Forms.Button
	Public WithEvents txtBadgeNo As System.Windows.Forms.TextBox
	Public WithEvents cboUserType As System.Windows.Forms.ComboBox
	Public WithEvents txtUserID As System.Windows.Forms.TextBox
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents lblUserType As System.Windows.Forms.Label
	Public WithEvents lblUserID As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAddUser))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.txtBadgeNo = New System.Windows.Forms.TextBox()
        Me.cboUserType = New System.Windows.Forms.ComboBox()
        Me.txtUserID = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblUserType = New System.Windows.Forms.Label()
        Me.lblUserID = New System.Windows.Forms.Label()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(167, 128)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(53, 21)
        Me.cmdCancel.TabIndex = 5
        Me.cmdCancel.Text = "Ca&ncel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(97, 128)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(53, 21)
        Me.cmdClose.TabIndex = 4
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSave.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSave.Location = New System.Drawing.Point(26, 128)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSave.Size = New System.Drawing.Size(53, 21)
        Me.cmdSave.TabIndex = 3
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.txtBadgeNo)
        Me.Frame1.Controls.Add(Me.cboUserType)
        Me.Frame1.Controls.Add(Me.txtUserID)
        Me.Frame1.Controls.Add(Me.Label1)
        Me.Frame1.Controls.Add(Me.lblUserType)
        Me.Frame1.Controls.Add(Me.lblUserID)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(11, 18)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(221, 98)
        Me.Frame1.TabIndex = 6
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "User Information"
        '
        'txtBadgeNo
        '
        Me.txtBadgeNo.AcceptsReturn = True
        Me.txtBadgeNo.BackColor = System.Drawing.SystemColors.Window
        Me.txtBadgeNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBadgeNo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBadgeNo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBadgeNo.Location = New System.Drawing.Point(87, 42)
        Me.txtBadgeNo.MaxLength = 0
        Me.txtBadgeNo.Name = "txtBadgeNo"
        Me.txtBadgeNo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBadgeNo.Size = New System.Drawing.Size(100, 19)
        Me.txtBadgeNo.TabIndex = 1
        '
        'cboUserType
        '
        Me.cboUserType.BackColor = System.Drawing.SystemColors.Window
        Me.cboUserType.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboUserType.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboUserType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboUserType.Items.AddRange(New Object() {"DMV", "VEHIC"})
        Me.cboUserType.Location = New System.Drawing.Point(87, 63)
        Me.cboUserType.Name = "cboUserType"
        Me.cboUserType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboUserType.Size = New System.Drawing.Size(104, 22)
        Me.cboUserType.TabIndex = 2
        '
        'txtUserID
        '
        Me.txtUserID.AcceptsReturn = True
        Me.txtUserID.BackColor = System.Drawing.SystemColors.Window
        Me.txtUserID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUserID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUserID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUserID.Location = New System.Drawing.Point(87, 19)
        Me.txtUserID.MaxLength = 0
        Me.txtUserID.Name = "txtUserID"
        Me.txtUserID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUserID.Size = New System.Drawing.Size(101, 19)
        Me.txtUserID.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(24, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(56, 14)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Badge No."
        '
        'lblUserType
        '
        Me.lblUserType.BackColor = System.Drawing.SystemColors.Control
        Me.lblUserType.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUserType.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserType.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUserType.Location = New System.Drawing.Point(24, 67)
        Me.lblUserType.Name = "lblUserType"
        Me.lblUserType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUserType.Size = New System.Drawing.Size(51, 15)
        Me.lblUserType.TabIndex = 8
        Me.lblUserType.Text = "User Type"
        '
        'lblUserID
        '
        Me.lblUserID.BackColor = System.Drawing.SystemColors.Control
        Me.lblUserID.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUserID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserID.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUserID.Location = New System.Drawing.Point(24, 21)
        Me.lblUserID.Name = "lblUserID"
        Me.lblUserID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUserID.Size = New System.Drawing.Size(46, 14)
        Me.lblUserID.TabIndex = 7
        Me.lblUserID.Text = "User ID"
        '
        'frmAddUser
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(246, 160)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.Frame1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAddUser"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add New User"
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As frmAddUser
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmAddUser
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmAddUser()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	'---------------------------------------------------------------------------------------
	' Procedure : cmdCancel_Click
	' DateTime  : 03/21/2007
	' Author    : aalvidrez
	' Purpose   :
	'---------------------------------------------------------------------------------------
	'
	Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
		On Error Resume Next
		
		Me.Close()
		
	End Sub
	
	'---------------------------------------------------------------------------------------
	' Procedure : cmdClose_Click
	' DateTime  : 03/21/2007
	' Author    : aalvidrez
	' Purpose   :
	'---------------------------------------------------------------------------------------
	'
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		On Error Resume Next
		
		Me.Close()
		
	End Sub
	
	'---------------------------------------------------------------------------------------
	' Procedure : cmdClose_Click
	' DateTime  : 03/21/2007
	' Author    : aalvidrez
	' Purpose   :
	'---------------------------------------------------------------------------------------
	'
	Private Sub cmdSave_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSave.Click
		On Error GoTo cmdSave_Click_ErrorHandler
		
		If txtUserID.Text <> "" Then
			If cboUserType.Text <> "" Then
				If txtBadgeNo.Text <> "" Then
					sSQL = ""
					sSQL = "INSERT INTO dbo.SC_DMV_RIGHTS_SYSTEMS" & "(USER_ID, TAB_ID, CREATED_BY) " & "Values('" & LCase(txtUserID.Text) & "', '" & UCase(cboUserType.Text) & "', '" & LCase(Environ("USERNAME")) & "')"
					
					cmd = New ADODB.Command
					With cmd
						.let_ActiveConnection(oConn)
						.CommandType = ADODB.CommandTypeEnum.adCmdText
						.CommandText = sSQL
					End With
					cmd.Execute()
					
					If Not (UserExist(txtBadgeNo.Text)) Then
						sSQL = ""
						sSQL = "INSERT INTO dbo.SC_USER_IDS" & "(USER_ID, EMPLOYEE_ID, CREATED_BY) " & "Values('" & LCase(txtUserID.Text) & "', '" & txtBadgeNo.Text & "', '" & LCase(Environ("USERNAME")) & "')"
						
						cmd = New ADODB.Command
						With cmd
							.let_ActiveConnection(oConn)
							.CommandType = ADODB.CommandTypeEnum.adCmdText
							.CommandText = sSQL
						End With
						cmd.Execute()
					End If
					
					MsgBox("Record Saved.", MsgBoxStyle.Information, "User Info Saved")
                    'Call frmDMVSecurity.DefInstance.GetUsers()
                Else
					MsgBox("You must enter a Badge Number", MsgBoxStyle.Information, "Badge Number")
				End If
			Else
				MsgBox("You must select a User Type.", MsgBoxStyle.Information, "User Type")
			End If
		Else
			MsgBox("You must enter a User ID.", MsgBoxStyle.Information, "User ID")
		End If
		
		Exit Sub
		
cmdSave_Click_ErrorHandler: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: frmAddUser:cmdSave_Click " & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    '---------------------------------------------------------------------------------------
    ' Procedure : UserExist
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Find out if a user exist before adding to database
    '---------------------------------------------------------------------------------------
    '
    Private Function UserExist(ByRef sBadgeNo As String) As Boolean
        On Error GoTo UserExist_ErrorHandler

        Dim rsBadge As ADODB.Recordset

        UserExist = False
        sSQL = ""
        sSQL = "SELECT EMPLOYEE_ID " & " FROM dbo.sc_user_ids " & " WHERE EMPLOYEE_ID='" & sBadgeNo & "'"

        rsBadge = New ADODB.Recordset
        rsBadge.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rsBadge.EOF And rsBadge.BOF) Then
            UserExist = True
        End If

        rsBadge.Close()

        Exit Function
UserExist_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: UserExist " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Function
End Class