Option Strict Off
Option Explicit On
Module querys
	Public Sub refreshBasicPositionData(ByRef inPosNo As String)
		On Error GoTo refreshBasicPositionData_ErrorHandler

        sSQL = "SELECT company,position_no,position_type,job_class,position_title,position_start_date,position_end_date,position_status,position_status_date,underfill_job_class,roster,bargaining_unit,confidential_ind,full_time_ind,permanency_ind,salary_range,salary_step,pay_rate_type,percent_full_time,cost_center,position_no_xref,prior_position_no,created_by,last_updated_by,creation_date,last_update_date,rest_day_1,rest_day_2,effective_date,action_1,action_2,action_3,position_description,work_begin_time,work_end_time " & "FROM dbo.pc_c_positions " & "WHERE position_no=" & inPosNo

        Exit Sub
refreshBasicPositionData_ErrorHandler: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: Queries " & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
		sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
		MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
		Resume Next
		
	End Sub
	
	ReadOnly Property getCodeDescription(ByVal inCode As String, ByVal inType As String) As String
		Get
			On Error GoTo Get_getCodeDescription_ErrorHandler
			
			sSQL = "SELECT code_description " & "FROM dbo.ct_codes " & "WHERE type='" & inType & "' " & "AND code='" & inCode & "'"
			
			Dim rsCodes As New ADODB.Recordset
			rsCodes.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenForwardOnly)
			
			If Not rsCodes.EOF Then
				getCodeDescription = rsCodes.Fields("code_description").Value
			Else
				getCodeDescription = ""
			End If

            rsCodes = Nothing

            Exit Property
Get_getCodeDescription_ErrorHandler: 
			sMsg = "Error Information..." & vbCrLf & vbCrLf
			sMsg = sMsg & "Function: Queries " & vbCrLf
			sMsg = sMsg & "Description: " & Err.Description & vbCrLf
			sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
			MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
			Resume Next
			
		End Get
	End Property
	
	ReadOnly Property getJobTitle(ByVal inJobClass As String) As String
		Get
			On Error GoTo Get_getJobTitle_ErrorHandler
			
			sSQL = "SELECT job_title " & "FROM dbo.ct_c_job_classes " & "WHERE job_class='" & inJobClass & "' "
			
			Dim rsCodes As New ADODB.Recordset
			rsCodes.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenForwardOnly)
			
			If Not rsCodes.EOF Then
				getJobTitle = rsCodes.Fields("JOB_TITLE").Value
			Else
				getJobTitle = ""
			End If

            rsCodes = Nothing

            Exit Property
Get_getJobTitle_ErrorHandler: 
			sMsg = "Error Information..." & vbCrLf & vbCrLf
			sMsg = sMsg & "Function: Queries " & vbCrLf
			sMsg = sMsg & "Description: " & Err.Description & vbCrLf
			sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
			MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
			Resume Next
			
		End Get
	End Property
	
	ReadOnly Property getCostCenterName(ByVal inCostCenter As String) As String
		Get
			On Error GoTo Get_getCostCenterName_ErrorHandler

            sSQL = "SELECT cost_center_name " & "FROM dbo.ct_cost_centers " & "WHERE cost_center='" & inCostCenter & "' "

            Dim rsCodes As New ADODB.Recordset
            rsCodes.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenForwardOnly)
			
			If Not rsCodes.EOF Then
				getCostCenterName = rsCodes.Fields("cost_center_name").Value
			Else
				getCostCenterName = ""
			End If

            rsCodes = Nothing

            Exit Property
Get_getCostCenterName_ErrorHandler: 
			sMsg = "Error Information..." & vbCrLf & vbCrLf
			sMsg = sMsg & "Function: Queries " & vbCrLf
			sMsg = sMsg & "Description: " & Err.Description & vbCrLf
			sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
			MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
			Resume Next
			
		End Get
	End Property
	
	Function listCodeDescriptions(ByRef inCode As String) As Object
		On Error GoTo listCodeDescriptions_ErrorHandler
		
		sSQL = "SELECT code,code_description " & "FROM dbo.ct_codes " & "WHERE type='" & inCode & "' "
		
		Exit Function
listCodeDescriptions_ErrorHandler: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: Queries " & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
		sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
		MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
		Resume Next
		
	End Function
	
	Function pc_incumbents_list(ByRef inPosNo As String) As Object
		On Error GoTo pc_incumbents_list_ErrorHandler
		
		sSQL = "SELECT A.employee_id,B.last_name + ', ' + B.first_name + ' ' + ISNULL(B.mid_name, '') employee_name,C.employment_status,C.status_effective_date,A.temporary_job_ind,A.begin_date,A.end_date " & " FROM dbo.hr_c_jobs A, dbo.hr_c_employees B, dbo.hr_c_employment_periods C " & " WHERE A.position_no=" & inPosNo & "" & " AND A.employee_id=B.employee_id " & " AND A.company=B.company " & " AND A.employee_id=C.employee_id " & " AND A.company=C.company " & " ORDER BY C.employment_status "
		
		Exit Function
pc_incumbents_list_ErrorHandler: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: Queries " & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
		sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
		MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
		Resume Next
		
	End Function
	
	Function pc_skills_list(ByRef inPosNo As Object) As Object
		On Error GoTo pc_skills_list_ErrorHandler

        sSQL = "SELECT A.skill_code " & "FROM dbo.pc_skills A, dbo.ct_codes B " & "WHERE A.position_no=" & inPosNo & " " & "AND A.skill_code=B.code " & "AND B.type='PC_SKILLS' " & "ORDER BY B.code_description"

        Exit Function
pc_skills_list_ErrorHandler: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: Queries " & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
		sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
		MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
		Resume Next
		
	End Function
	
	Function pc_qualifications_list(ByRef inPosNo As Object) As Object
		On Error GoTo pc_qualifications_list_ErrorHandler

        sSQL = "SELECT A.qualification_id,MONTHS_EXPERIENCE_REQUIRED " & "FROM dbo.pc_qualifications A, dbo.ct_codes B " & "WHERE A.position_no=" & inPosNo & " " & "AND A.qualification_id=B.code " & "AND B.type='PC_QUALS' " & "ORDER BY B.code_description"

        Exit Function
pc_qualifications_list_ErrorHandler: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: Queries " & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
		sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
		MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
		Resume Next
		
	End Function
	
	Function pc_fiscal_years_list(ByRef inPosNo As Object, ByRef inFiscalYear As Object) As Object
		On Error GoTo pc_fiscal_years_list_ErrorHandler

        sSQL = "SELECT * " & "FROM dbo.pc_fiscal_years " & "WHERE position_no='" & inPosNo & "' " & "AND fiscal_year='" & inFiscalYear & "'"

        Exit Function
pc_fiscal_years_list_ErrorHandler: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: Queries " & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
		sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
		MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
		Resume Next
		
	End Function
End Module