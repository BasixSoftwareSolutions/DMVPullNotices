Option Strict Off
Option Explicit On
'Imports VB = Microsoft.VisualBasic
Friend Class frmOptOut
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents cmdDelete As System.Windows.Forms.Button
	Public WithEvents cmdAdd As System.Windows.Forms.Button
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents lstOptOut As System.Windows.Forms.ListBox
	Public WithEvents lstEmployees As System.Windows.Forms.ListBox
	Public WithEvents lblCount As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOptOut))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.lstOptOut = New System.Windows.Forms.ListBox()
        Me.lstEmployees = New System.Windows.Forms.ListBox()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDelete.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDelete.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDelete.Location = New System.Drawing.Point(234, 132)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDelete.Size = New System.Drawing.Size(43, 28)
        Me.cmdDelete.TabIndex = 9
        Me.cmdDelete.Text = "<<"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAdd.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAdd.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAdd.Location = New System.Drawing.Point(234, 100)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAdd.Size = New System.Drawing.Size(43, 28)
        Me.cmdAdd.TabIndex = 8
        Me.cmdAdd.Text = ">>"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(24, 387)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(78, 24)
        Me.cmdClose.TabIndex = 6
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'lstOptOut
        '
        Me.lstOptOut.BackColor = System.Drawing.SystemColors.Window
        Me.lstOptOut.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstOptOut.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstOptOut.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstOptOut.ItemHeight = 14
        Me.lstOptOut.Location = New System.Drawing.Point(286, 24)
        Me.lstOptOut.Name = "lstOptOut"
        Me.lstOptOut.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstOptOut.Size = New System.Drawing.Size(199, 326)
        Me.lstOptOut.TabIndex = 1
        '
        'lstEmployees
        '
        Me.lstEmployees.BackColor = System.Drawing.SystemColors.Window
        Me.lstEmployees.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstEmployees.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstEmployees.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstEmployees.ItemHeight = 14
        Me.lstEmployees.Location = New System.Drawing.Point(20, 24)
        Me.lstEmployees.Name = "lstEmployees"
        Me.lstEmployees.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstEmployees.Size = New System.Drawing.Size(199, 326)
        Me.lstEmployees.TabIndex = 0
        '
        'lblCount
        '
        Me.lblCount.BackColor = System.Drawing.SystemColors.Control
        Me.lblCount.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblCount.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCount.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblCount.Location = New System.Drawing.Point(371, 9)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblCount.Size = New System.Drawing.Size(110, 13)
        Me.lblCount.TabIndex = 7
        Me.lblCount.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(287, 356)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(199, 50)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Double click on name to remove from list"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(21, 358)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(186, 17)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Double click on name to add to list."
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(286, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(98, 16)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Opt Out List"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(20, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(199, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Employee List"
        '
        'frmOptOut
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(507, 420)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdAdd)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.lstOptOut)
        Me.Controls.Add(Me.lstEmployees)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmOptOut"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DMV Opt Out"
        Me.ResumeLayout(False)

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmOptOut
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmOptOut
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmOptOut()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdCancel_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Add employee to the Opt Out side of the form
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdAdd_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAdd.Click
        On Error Resume Next

        Call lstEmployees_DoubleClick(lstEmployees, New System.EventArgs())

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdClose_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Close the form
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
        On Error Resume Next

        Me.Close()

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : cmdDelete_Click
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Remove employee from Opt Out side of form
    '---------------------------------------------------------------------------------------
    '
    Private Sub cmdDelete_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdDelete.Click
        On Error Resume Next

        Call lstOptOut_DoubleClick(lstOptOut, New System.EventArgs())

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : Form_Load
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the form
    '---------------------------------------------------------------------------------------
    '
    Private Sub frmOptOut_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        On Error Resume Next

        LoadEmployeeList() 'Load the employee list
        LoadOptOutList() 'Load the OptOut list

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : LoadOptOutList
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the OptOut List
    '---------------------------------------------------------------------------------------
    '
    Public Sub LoadOptOutList()
        On Error GoTo LoadOptOutList_ErrorHandler

        'Clear the list
        lstOptOut.Items.Clear()

        sSQL = "SELECT A.last_name + ', ' + A.first_name + ' #' + A.employee_id as emp_name, B.employee_id" & " FROM dbo.hr_c_employees A, dbo.hr_dmv_optout B" & " WHERE (A.employment_status like 'A%' or A.employment_status like 'L%')" & " AND A.employee_id = B.employee_id" & " ORDER BY 1"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        'Populate the list
        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            lblCount.Text = "Record Count = " & rs.RecordCount & ""
            rs.MoveFirst()
            Do While rs.EOF = False
                lstOptOut.Items.Add(rs.Fields("emp_name").Value)
                rs.MoveNext()
            Loop
        End If

        Exit Sub
LoadOptOutList_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: LoadOptOutList " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : LoadEmployeeList
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Load the Employee List
    '---------------------------------------------------------------------------------------
    '
    Public Sub LoadEmployeeList()
        On Error GoTo LoadEmployeeList_ErrorHandler

        'Clear the list
        lstEmployees.Items.Clear()

        sSQL = "SELECT last_name + ', ' + first_name + ' #' + employee_id as emp_name " & " FROM dbo.hr_c_employees " & " WHERE (employment_status like 'A%' or employment_status like 'L%')" & " AND (union_code = 'NONE')" & " AND (employee_id NOT IN(SELECT employee_id FROM dbo.hr_dmv_optout))" & " ORDER BY 1"

        rs = New ADODB.Recordset
        rs.Open(sSQL, oConn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        'Populate the list
        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                lstEmployees.Items.Add(rs.Fields("emp_name").Value)
                rs.MoveNext()
            Loop
        End If

        Exit Sub
LoadEmployeeList_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: LoadEmployeeList " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : lstEmployees_DblClick
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Add an employee to the OptOut List
    '---------------------------------------------------------------------------------------
    '
    Private Sub lstEmployees_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstEmployees.DoubleClick
        On Error GoTo lstEmployees_DblClick_ErrorHandler
        Dim sBadgeNumber As String

        'Make sure we have selected a valid badge number
        If Len(lstEmployees.Text) >= 4 Then
            'Get the Badge number
            sBadgeNumber = Mid(lstEmployees.Text, InStr(lstEmployees.Text, "#") + 1, 5)

            'Delete the record first just in case it already exist
            sSQL = "DELETE dbo.hr_dmv_optout WHERE employee_id=" & sBadgeNumber & ""

            cmd = New ADODB.Command
            With cmd
                .let_ActiveConnection(oConn)
                .CommandType = ADODB.CommandTypeEnum.adCmdText
                .CommandText = sSQL
            End With
            cmd.Execute()

            'Insert the new record
            sSQL = "INSERT INTO dbo.hr_dmv_optout (employee_id, created_by) VALUES (" & sBadgeNumber & ", '" & LCase(Environ("USERNAME")) & "')"

            cmd = New ADODB.Command
            With cmd
                .let_ActiveConnection(oConn)
                .CommandType = ADODB.CommandTypeEnum.adCmdText
                .CommandText = sSQL
            End With
            cmd.Execute()

            'Reload both list
            LoadOptOutList()
            LoadEmployeeList()
        Else
            MsgBox("Please select an employee from the list with a valid badge number.", MsgBoxStyle.Information, "Add user")
        End If

        Exit Sub
lstEmployees_DblClick_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: lstEmployees_DblClick " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub
    '---------------------------------------------------------------------------------------
    ' Procedure : lstOptOut_DblClick
    ' DateTime  : 03/21/2007
    ' Author    : aalvidrez
    ' Purpose   : Remove an employee from the OptOut List
    '---------------------------------------------------------------------------------------
    '
    Private Sub lstOptOut_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstOptOut.DoubleClick
        On Error GoTo lstOptOut_DblClick_ErrorHandler

        'Make sure we have a valid badge number
        If Len(lstOptOut.Text) >= 4 Then
            Dim sBadgeNumber As String
            'Get the Badge number
            sBadgeNumber = Mid(lstOptOut.Text, InStr(lstOptOut.Text, "#") + 1, 5)

            'delete the record
            sSQL = "DELETE dbo.hr_dmv_optout WHERE employee_id=" & sBadgeNumber & ""

            cmd = New ADODB.Command
            With cmd
                .let_ActiveConnection(oConn)
                .CommandType = ADODB.CommandTypeEnum.adCmdText
                .CommandText = sSQL
            End With
            cmd.Execute()
        Else
            MsgBox("Please select an employee from the list with a valid badge number.", MsgBoxStyle.Information, "Remove user")
        End If

        'Reload both lists
        LoadOptOutList()
        LoadEmployeeList()

        Exit Sub
lstOptOut_DblClick_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: lstOptOut_DblClick " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

End Class