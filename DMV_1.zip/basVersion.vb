Option Strict Off
Option Explicit On
Module basVersion
	
	Private Const APP_VERSION_BAT As String = "\\OCTANT03.OCTA.net\apps$\DMV\DMV_Version.bat"
	Private vReturn As Object
	
	Function GetAppVersion() As String
		
		On Error GoTo GetAppVersion_Error
		Dim sAppVersion As String
		
        Dim sVersion As String
        'UPGRADE_ISSUE: App property App.Revision was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2069"'
        Dim versionNumber As Version

        versionNumber = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version
        Dim sRevision As String = System.Reflection.Assembly.GetExecutingAssembly().GetName.Version.ToString
        sAppVersion = System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).FileMajorPart & "." & System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).FileMinorPart & "." & sRevision
		GetAppVersion = sAppVersion
		
GetAppVersion_Exit: 
		Exit Function
		
GetAppVersion_Error: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: GetAppVersion" & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
		sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
		MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
		Resume GetAppVersion_Exit
		
	End Function
	
	Function CheckVersion() As Object
		Dim vLocalVersion As Object
		Dim vCurrentVersion As Object
		
		On Error GoTo Err_CheckVersion

        'This function is used to check the Version properties.
        'It checks the Local version against the file version.
        'If they don't match it will ask if they want to donwload
        'the most current version. This may be disabled if they are
        'required to have the latest version.

        'Get the Current Application Version
        vCurrentVersion = ReadLatestVersion()

        'Get the Local Application Version
        vLocalVersion = GetAppVersion()

        'If they don't match, ask if they want the latest version
        If vCurrentVersion <> vLocalVersion Then
            sMsg = "You do not have the latest version of DMV. The application will shut down and get the latest version. This will only take a minute."
            MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
            vReturn = Shell(APP_VERSION_BAT, AppWinStyle.NormalFocus)
            End
        End If

CheckVersion_End: 
		
		Exit Function
		
Err_CheckVersion: 
		
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: Check Version" & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
		sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
		MsgBox(sMsg, MsgBoxStyle.Information, "Check Version")
		Resume CheckVersion_End
		
	End Function
	
	Function ReadLatestVersion() As String
		On Error GoTo ReadLatestVersion_Error
		
		'Opens the tblSystem table to get the current version
		ReadLatestVersion = RetrieveFieldFrom("value", "dbo.sc_system", "name='AppVersion'")
		
		If ReadLatestVersion = "" Then
			MsgBox("Could not determine the latest application version." & vbCrLf & vbCrLf & "Contact your Systems Administrator.", MsgBoxStyle.Critical, "DMV System")
		End If
		
ReadLatestVersion_Exit: 
		Exit Function
		
ReadLatestVersion_Error: 
		sMsg = "Error Information..." & vbCrLf & vbCrLf
		sMsg = sMsg & "Function: ReadLatestVersion" & vbCrLf
		sMsg = sMsg & "Description: " & Err.Description & vbCrLf
		sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
		MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
		Resume ReadLatestVersion_Exit
		
	End Function
End Module