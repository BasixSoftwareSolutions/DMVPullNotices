Option Strict Off
Option Explicit On
Friend Class frmDMVPasswordChange
    Inherits System.Windows.Forms.Form
    Private cmdPasswordTools() As Button
#Region "Windows Form Designer generated code "
    Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()
        cmdPasswordTools = New Button() {cmdTools1, cmdTools2}
    End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents Text2 As System.Windows.Forms.TextBox
    Public WithEvents cmdTools2 As System.Windows.Forms.Button
    Public WithEvents cmdTools1 As System.Windows.Forms.Button
    Public WithEvents Text1 As System.Windows.Forms.TextBox
    Public WithEvents _label_2 As System.Windows.Forms.Label
    Public WithEvents _label_1 As System.Windows.Forms.Label
    'Public WithEvents cmdTools As ButtonArray
    'Public WithEvents label As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    'Public WithEvents text_Renamed As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDMVPasswordChange))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Text2 = New System.Windows.Forms.TextBox()
        Me.cmdTools2 = New System.Windows.Forms.Button()
        Me.cmdTools1 = New System.Windows.Forms.Button()
        Me.Text1 = New System.Windows.Forms.TextBox()
        Me._label_2 = New System.Windows.Forms.Label()
        Me._label_1 = New System.Windows.Forms.Label()
        'Me.text_Renamed = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(Me.components)
        'CType(Me.text_Renamed, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Text2
        '
        Me.Text2.AcceptsReturn = True
        Me.Text2.BackColor = System.Drawing.SystemColors.Window
        Me.Text2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text2.ForeColor = System.Drawing.SystemColors.WindowText
        'Me.text_Renamed.SetIndex(Me.Text2, CType(1, Short))
        Me.Text2.Location = New System.Drawing.Point(130, 34)
        Me.Text2.MaxLength = 0
        Me.Text2.Name = "Text2"
        Me.Text2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Text2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text2.Size = New System.Drawing.Size(105, 20)
        Me.Text2.TabIndex = 1
        '
        'cmdTools2
        '
        Me.cmdTools2.BackColor = System.Drawing.SystemColors.Control
        Me.cmdTools2.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdTools2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdTools2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTools2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdTools2.Location = New System.Drawing.Point(242, 36)
        Me.cmdTools2.Name = "cmdTools2"
        Me.cmdTools2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdTools2.Size = New System.Drawing.Size(95, 21)
        Me.cmdTools2.TabIndex = 3
        Me.cmdTools2.Text = "Cancel"
        Me.cmdTools2.UseVisualStyleBackColor = False
        '
        'cmdTools1
        '
        Me.cmdTools1.BackColor = System.Drawing.SystemColors.Control
        Me.cmdTools1.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdTools1.Enabled = False
        Me.cmdTools1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdTools1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdTools1.Location = New System.Drawing.Point(242, 10)
        Me.cmdTools1.Name = "cmdTools1"
        Me.cmdTools1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdTools1.Size = New System.Drawing.Size(95, 21)
        Me.cmdTools1.TabIndex = 2
        Me.cmdTools1.Text = "OK"
        Me.cmdTools1.UseVisualStyleBackColor = False
        '
        'Text1
        '
        Me.Text1.AcceptsReturn = True
        Me.Text1.BackColor = System.Drawing.SystemColors.Window
        Me.Text1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text1.ForeColor = System.Drawing.SystemColors.WindowText
        'Me.text_Renamed.SetIndex(Me.Text1, CType(0, Short))
        Me.Text1.Location = New System.Drawing.Point(130, 12)
        Me.Text1.MaxLength = 0
        Me.Text1.Name = "Text1"
        Me.Text1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Text1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text1.Size = New System.Drawing.Size(105, 20)
        Me.Text1.TabIndex = 0
        '
        '_label_2
        '
        Me._label_2.AutoSize = True
        Me._label_2.BackColor = System.Drawing.SystemColors.Control
        Me._label_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._label_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._label_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._label_2.Location = New System.Drawing.Point(1, 38)
        Me._label_2.Name = "_label_2"
        Me._label_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._label_2.Size = New System.Drawing.Size(123, 14)
        Me._label_2.TabIndex = 5
        Me._label_2.Text = "Confirm New Password"
        '
        '_label_1
        '
        Me._label_1.AutoSize = True
        Me._label_1.BackColor = System.Drawing.SystemColors.Control
        Me._label_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._label_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._label_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._label_1.Location = New System.Drawing.Point(41, 16)
        Me._label_1.Name = "_label_1"
        Me._label_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._label_1.Size = New System.Drawing.Size(83, 14)
        Me._label_1.TabIndex = 4
        Me._label_1.Text = "New Password"
        '
        'text_Renamed
        '
        '
        'frmDMVPasswordChange
        '
        Me.AcceptButton = Me.cmdTools1
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 14)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.CancelButton = Me.cmdTools2
        Me.ClientSize = New System.Drawing.Size(346, 68)
        Me.ControlBox = False
        Me.Controls.Add(Me.Text2)
        Me.Controls.Add(Me.cmdTools2)
        Me.Controls.Add(Me.cmdTools1)
        Me.Controls.Add(Me.Text1)
        Me.Controls.Add(Me._label_2)
        Me.Controls.Add(Me._label_1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmDMVPasswordChange"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Change DMV Password"
        'CType(Me.text_Renamed, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmDMVPasswordChange
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmDMVPasswordChange
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmDMVPasswordChange()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region

    ' ---------------------------------------------------------------------------------------
    '  Procedure : cmdTools_Click
    '  DateTime  : 03/21/2007
    '  Author    : aalvidrez
    '  Purpose   : Validate the new password
    ' ---------------------------------------------------------------------------------------

    Private Sub cmdTools_Click(ByVal Index As Integer)
        On Error GoTo cmdTools_Click_ErrorHandler

        If Index = 0 Then
            'New password must be between 6 and 8 characters long
            If Len(Text1.Text) < 6 Or Len(Text2.Text) > 12 Then
                MsgBox("Password must be 6 to 12 characters in length.", MsgBoxStyle.Information, "Stop")
                Text1.Focus()
                Exit Sub
            End If
            SaveNewPassord()
            Me.Close()
        Else
            Me.Close()
        End If

        Exit Sub
cmdTools_Click_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: cmdTools_Click " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    ' ---------------------------------------------------------------------------------------
    '  Procedure : Form_Load
    '  DateTime  : 03/21/2007
    '  Author    : aalvidrez
    '  Purpose   : Load the form
    ' ---------------------------------------------------------------------------------------

    Private Sub frmDMVPasswordChange_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        On Error Resume Next

        'Set the forms caption
        If MDIForm1.DefInstance.GetDMVPassword = "reset" Then
            Me.Text = "Establish DMV Password"
        Else
            Me.Text = "Change DMV Password"
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub

    ' ---------------------------------------------------------------------------------------
    '  Procedure : SaveNewPassord
    '  DateTime  : 03/21/2007
    '  Author    : aalvidrez
    '  Purpose   : Save the new password
    ' ---------------------------------------------------------------------------------------

    Private Sub SaveNewPassord()
        On Error GoTo SaveNewPassord_ErrorHandler

        'Promt to save new password
        If MsgBox("Save new password?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm") = MsgBoxResult.No Then Exit Sub
        sSQL = "UPDATE sc_user_ids SET dmv_password='" & RTrim(LCase(Text2.Text)) & "' WHERE user_id='" & LCase(Environ("USERNAME")) & "'"

        cmd = New ADODB.Command

        With cmd
            .let_ActiveConnection(oConn)
            .CommandType = ADODB.CommandTypeEnum.adCmdText
            .CommandText = sSQL
        End With

        'Save the new password
        cmd.Execute()

        Exit Sub
SaveNewPassord_ErrorHandler:
        sMsg = "Error Information..." & vbCrLf & vbCrLf
        sMsg = sMsg & "Function: SaveNewPassord " & vbCrLf
        sMsg = sMsg & "Description: " & Err.Description & vbCrLf
        sMsg = sMsg & "Error #: " & Err.Number.ToString & vbCrLf
        MsgBox(sMsg, MsgBoxStyle.Information, "DMV System")
        Resume Next

    End Sub

    Private Sub cmdTools1_Click(sender As Object, e As EventArgs) Handles cmdTools1.Click

        cmdTools_Click(0)

    End Sub

    Private Sub cmdTools2_Click(sender As Object, e As EventArgs) Handles cmdTools2.Click

        cmdTools_Click(1)

    End Sub

    ' ---------------------------------------------------------------------------------------
    '  Procedure : text_GotFocus
    '  DateTime  : 03/21/2007
    '  Author    : aalvidrez
    '  Purpose   : Highlight the entire textbox when it has the focus
    ' ---------------------------------------------------------------------------------------
    Private Sub Text1_Enter(sender As Object, e As EventArgs) Handles Text1.Enter

        Text1.SelectionStart = 0
        Text1.SelectionLength = Len(Text1.Text)

    End Sub

    ' ---------------------------------------------------------------------------------------
    '  Procedure : text_GotFocus
    '  DateTime  : 03/21/2007
    '  Author    : aalvidrez
    '  Purpose   : Highlight the entire textbox when it has the focus
    ' ---------------------------------------------------------------------------------------
    Private Sub Text2_Enter(sender As Object, e As EventArgs) Handles Text2.Enter

        Text2.SelectionStart = 0
        Text2.SelectionLength = Len(Text2.Text)

    End Sub

    ' ---------------------------------------------------------------------------------------
    '  Procedure : text_Change
    '  DateTime  : 03/21/2007
    '  Author    : aalvidrez
    '  Purpose   : Validat new password
    ' ---------------------------------------------------------------------------------------
    Private Sub Text1_TextChanged(sender As Object, e As EventArgs) Handles Text1.TextChanged
        On Error Resume Next

        'Check both text boxs and make sure they match
        If LCase(Trim(Text1.Text)) = LCase(Trim(Text2.Text)) Then
            cmdTools1.Enabled = True
        Else
            cmdTools1.Enabled = False
        End If

    End Sub
    ' ---------------------------------------------------------------------------------------
    '  Procedure : text_Change
    '  DateTime  : 03/21/2007
    '  Author    : aalvidrez
    '  Purpose   : Validat new password
    ' ---------------------------------------------------------------------------------------

    Private Sub Text2_TextChanged(sender As Object, e As EventArgs) Handles Text2.TextChanged
        On Error Resume Next

        'Check both text boxs and make sure they match
        If LCase(Trim(Text1.Text)) = LCase(Trim(Text2.Text)) Then
            cmdTools1.Enabled = True
        Else
            cmdTools1.Enabled = False
        End If

    End Sub
End Class